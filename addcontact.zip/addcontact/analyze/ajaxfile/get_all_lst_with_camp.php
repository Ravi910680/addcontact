<?php





require("../../confige/camp_confige.php");


function get_all_camp_list($conn,$type,$val){


$ret_arr_tbl=array();

$sel_query='select * from camp_contact_tbl where '.$type.'="'.$val.'"';

$result = $conn->query($sel_query);


if ($result->num_rows > 0) {
  
  while($row = $result->fetch_assoc()) {
    
    array_push($ret_arr_tbl, $row);


  }
}




return $ret_arr_tbl;

}





$camp_id=$_GET['camp_id'];


print_r(json_encode(get_all_camp_list($camp_name_conn,'camp_con_id',$camp_id)));

?>