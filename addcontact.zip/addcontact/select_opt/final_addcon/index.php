<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];

require("../../../../confige/userconnect.php");

$sql = "SELECT id FROM userinfo WHERE email='$mail' and varflag='1'";


$result=$conn->query($sql);
$count = mysqli_num_rows($result);

if($count==1)
{
$_SESSION['src_of_mail']='ravi.png';
 if(isset($_SESSION['listname'])&&isset($_SESSION['src_of_mail'])){
$src_of_mail=$_SESSION['src_of_mail'];
$count_of_mail=6;
         $filename=explode("^",$_SESSION['listname']);
         $name_of_file=base64_decode($filename[1]);



?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
  <link href="./../../../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />
  <script src="https://kit.fontawesome.com/a66ec178f8.js" crossorigin="anonymous"></script>
<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(http://fonts.googleapis.com/css?family=Varela+Round);
.hover-bottom:hover{
    border-bottom:1px solid white;

}
.card-hover:hover{
    background:#f2f2f2;
  cursor: pointer;
}
.fa-add{
    padding:20px;
        font-size: 100px;
    margin: 0 auto;
}
.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;

}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: 0 auto;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}
.color-fet{
padding-left:10px;
padding-right:10px;
font-weight:600;
}
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <script src="./../../../assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <!-- Icons -->
  

 
 
  <!-- CSS Files -->
  <script>
  

  </script>

</head>
<div id="c"></div>
<body class="" style="background:#fff;">
  <div style="height:93vh">
  <nav class="navbar navbar-expand-lg navbar-light" style="border-bottom:2px solid;padding-top:20px;">
  <a class="navbar-brand" href="#">heptera|<sub>mail</sub></a>
  
  <div class=" navbar-collapse">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="./../../addsite/" >site confige </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./../../addcontact/" >Add contacts</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./../../campigns/" >Campigns</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./../../mainana/"  >Analyze mail</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./../../sellmail/" >Sell mail</a>
      </li>
    </ul>

    
  </div>
  <ul class="navbar-nav align-items-center d-none d-md-flex">
          <li class="nav-item dropdown">
            <a class=" pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="media align-items-center">
                
                <div class="media-body ml-2 d-none d-lg-block">
                  <span class="mb-0 text-sm" style="color:black"><?php echo $mail;?></span>
                </div>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
              <div class=" dropdown-header noti-title">
                <h6 class="text-overflow m-0">Welcome!</h6>
              </div>
              <a href="./examples/profile.html" class="dropdown-item">
                <i class="ni ni-single-02"></i>
                <span>My profile</span>
              </a>
              <a href="./examples/profile.html" class="dropdown-item">
                <i class="ni ni-settings-gear-65"></i>
                <span>Settings</span>
              </a>
              <a href="./examples/profile.html" class="dropdown-item">
                <i class="ni ni-calendar-grid-58"></i>
                <span>Activity</span>
              </a>
              <a href="./examples/profile.html" class="dropdown-item">
                <i class="ni ni-support-16"></i>
                <span>Support</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="#!" class="dropdown-item">
                <i class="ni ni-user-run"></i>
                <span>Logout</span>
              </a>
            </div>
          </li>
        </ul>
</nav>


<nav class="navbar navbar-dark bg-dark" style="color:white;height:7vh;padding:10px;">
<div style="width:100%"><span style="float-left"><a class=" hover-bottom" href="/main/addcontact/" style="color:white;font-weight:900;">Return to dashboard</a></span>
<div class="float-right" onclick="getdata(click_Select_con)" style="height:100%;float:right;"><i class="con-hover fa fa-circle-o-notch fa-spin" style="font-size:24px;display:none;"></i><span class='text_list' style='color:white;font-weight:900;'>Add Contact In <?php echo $name_of_file;?></span></div>
</div>

</nav>


<div class="main-content" style="">

<div class="main-con-content container" style="">
<div>
<img src='https://res.cloudinary.com/heptera/image/upload/v1581426619/hotel_yflntl.png' style='width:128px'>
<div>
Click on continue for add this<span class='color-fet' style='color:darkcyan;'> <?php echo $count_of_mail; ?></span> from<span class='color-fet' style='color:darkcyan;'> <?php echo $src_of_mail;?></span>
</div>
</div>
</div>
</div>

</div>
<nav class="navbar navbar-dark bg-dark" style="color:white;height:7vh;padding:10px;">
<div style="width:100%">
<div class="float-right click-on-opt"  style="height:100%;float:right;display:none;">

<button class="submit-form-contact" onclick="givedatatosql()" id="rr">continue</button></div>
</div>

</nav>

</body>
<div class="res">
</div>



  
  <script src="./../../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="./../../assets/js/argon-dashboard1.js"></script>
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>


  </script>
  <script>
  function getdata(path){
      
      ChangeUrl(path,"?path="+path);
      
      $(".con-hover").css("display","block");

$(".submit-form-contact").attr("id",path);
$(".main-content").load(path+".php", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success"){
      $(".con-hover").css("display","none");
      $(".click-on-opt").css("display","block");
$(".submit-form-contact").click(function(){

submitcon(path);


});

    }
    if(statusTxt == "error"){
      $(".con-hover").css("display","none");}
  });
      
      
      

  }
  function ChangeUrl(title, url) {
    if (typeof (history.pushState) != "undefined") {
        var obj = { Title: title, Url: url };
        history.pushState(obj, obj.Title, obj.Url);
    } else {
        alert("Browser does not support HTML5.");
    }
}
      </script>
  <script>


$("#subfileform").submit(function(event){
	event.preventDefault(); //prevent default action 
	var post_url = $(this).attr("action"); //get form action url
	var request_method = $(this).attr("method"); //get form GET/POST method
	var form_data = $(this).serialize(); //Encode form elements for submission
	
	$.ajax({
		url:post_url,
   method:"POST",
   data:new FormData(this),
   contentType:false,
   cache:false,
   processData:false,
   beforeSend: function () {
         $("#loadsendlink").css("display","inline-block");
      
        },
   
	}).done(function(response){ //
    if(response==1){
$("#normalres").html("<div class='card bg-warning text-white'><div class='card-body'>not able to create table</div></div>");
 $("#loadsendlink").css("display","none");
    }else if(response==2){
$("#normalres").html("<div class='card bg-warning text-white'><div class='card-body'>not enter same data sheet name</div></div>");
 $("#loadsendlink").css("display","none");
    }else if(response==3){
$("#normalres").html("<div class='card bg-warning text-white'><div class='card-body'>please select valid csv</div></div>");
 $("#loadsendlink").css("display","none");
    }else{
    $("#loadsendlink").css("display","none");
    location.reload();
        $(".modal-body").html(response);
    }
	});
});






</script>
  
  


<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>
<?php
 }
}else{








?>
<meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<script src="./../../assets/js/plugins/jquery/dist/jquery.min.js"></script>
<link href="./../../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />

<style>
.extracardcss{
     margin:auto;
margin-top:18%;
}

</style>
<body style="background:#f8f9fe;">


<div class="extracardcss card" style="width: 18rem;">
  
  <div class="card-body">
    <h5 class="card-title"><div class="navb">heptera|<sub>mail</sub></div></h5>
    <p class="card-text">For verify Your email adress please click on button and please verify your account</p>
    <input type="checkbox" id="terms" required> I accsept terms and condition.<br>
    <button id="sendlink" class="btn btn-warning" style="margin-top:25px" ><i id="loadsendlink" class="fa fa-circle-o-notch fa-spin" style="display:none"></i> send verify link</button>
  </div>
</div>
<script>
$(document).ready(function(){
  $("#sendlink").click(function(){
      var email="<?php echo $mail;?>"
      var id="<?php echo $id;?>"
      $("#loadsendlink").css("display","inline-block");
      
    $.ajax({
		url : "http://dash.heptera.me/ajaxphp/sendlink.php",
		type: "POST",
		data : "email="+email
	}).done(function(response){ //
        $("#loadsendlink").css("display","none");
		$("#sendlink").html(response);
        
	});
  });
});
</script>


<?php




}


?>
