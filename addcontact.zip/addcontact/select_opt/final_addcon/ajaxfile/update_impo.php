<?php

function up_impo_data($conn,$list_name,$mail_src,$impo_cnt){

$date_ts=date("y-m-d h:m:sa");

echo $list_name;

$insert_data_impo = "INSERT INTO data_impo (list_name, import_src, dt_ts,impo_count) VALUES ('$list_name', '$mail_src', '$date_ts','$impo_cnt')";

if ($conn->query($insert_data_impo) === TRUE) {
 

 
} else {
  echo "Error: ".$conn->error;
}

}

?>
