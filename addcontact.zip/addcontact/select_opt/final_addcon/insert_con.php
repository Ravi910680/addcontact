<?php
session_start();
require("../../confige/fileconfige.php");
require("../../confige/con_import.php");
require("./ajaxfile/sub_status_dec.php");
require("./ajaxfile/update_impo.php");


require("../../confige/camp_confige.php");


error_reporting(E_ERROR);
$lst_name=$_SESSION['listname'];

$get_camp_data="select * from camp_contact_tbl where list_id='$lst_name'";





$result = $camp_name_conn->query($get_camp_data);



$cnt_camp=$result->num_rows;






function get_email_col($list_id){

require("../../confige/fileconfige.php");

        $get_col_query="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='storefile' AND `TABLE_NAME`='".$list_id."'";

        $query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){


        $result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}



function httpGet($url)
{
    $ch = curl_init();  
 
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false); 
 
    $output=curl_exec($ch);
 
    curl_close($ch);
    return $output;
}
 

function get_gend_flg($gend_type){

if($gend_type=='male'){

return 'm';

}else{

return 'f';

}

}



$list_name=$_SESSION['listname'];
$con_data=$_SESSION['email_data'];




function isrt_str_of_db($arr_of_data,$col_name){




$val_str="(";



for($i=0;$i<count($col_name);$i++){

	if(empty($arr_of_data[$col_name[$i]]) && !isset($arr_of_data[$col_name[$i]])){


 $val_str.="'',";

	}else{

	$val_str.="'".$arr_of_data[$col_name[$i]]."',";

	}

}


return $val_str;
}


function get_isrt_dec_str_in_db($arr){

$str_ret="(";
foreach ($arr as $key => $value) {
   
$str_ret.=$value.",";


}

$str_ret=substr($str_ret, 0, -1);

return $str_ret.")";

}



if(isset($_SESSION['listname'])){

$arr=$_POST['name'];


$def_tags=$arr["tags"];


$count_of_tags=count($def_tags);
$str_of_tags="";

for($i=0;$i<$count_of_tags;$i++){



$str_of_tags.=$def_tags[$i].",";
	}


$sub_stat=sub_stat_dec($arr["select_stat"]);

$col_name_2=get_email_col($list_name);
$col_name=array_slice($col_name_2,0,count($col_name_2)-$cnt_camp-11);




$col_of_dec_isrt=array_slice($col_name_2,0,count($col_name_2)-$cnt_camp);

$get_isrt_dec_str=get_isrt_dec_str_in_db($col_of_dec_isrt);


echo $get_isrt_dec_str;


$select_count_query = "SELECT *FROM filedetails WHERE filename='$list_name'";

$get_res_count = $conn2->query($select_count_query);
$fetch_count_data = $get_res_count->fetch_assoc();

$res_all_count=$fetch_count_data['extra'];

$mail_src=$_SESSION['src_of_mail'];
$decoded_con_data=json_decode($con_data);

$status=0;

$date_add=date('Y-m-d');

if($mail_src=='admin'){


$geted_data=json_decode(json_encode($decoded_con_data), true);

        $str_of_isrt=isrt_str_of_db($geted_data,$col_name);




       $url_gend_cnt="https://gender-api.com/get?email=".$geted_data['email']."&key=ZQvPPEceXqQMGhJNCN";




$res=httpGet($url_gend_cnt);


$data_of_gender_api=json_decode($res);

$gend_data=get_gend_flg($data_of_gender_api->gender);


$res=httpGet("https://api.agify.io?name=".$data_of_gender_api->first_name);



$data_of_age=json_decode($res)->age;




$insert_query_db="INSERT INTO `".$list_name."` ".$get_isrt_dec_str." VALUE ".$str_of_isrt."'$str_of_tags','$sub_stat','$mail_src','','0','$date_add','$date_add','','$gend_data','$data_of_age','0')";


if ($conn3->query($insert_query_db) === TRUE) {


    $res_all_count+=1;


} else {

    echo $conn3->error;
    
}



}else{





for($i=0;$i<count($decoded_con_data);$i++){






$geted_data=json_decode(json_encode($decoded_con_data[$i]), true);

        $str_of_isrt=isrt_str_of_db($geted_data,$col_name);



       $url_gend_cnt="https://gender-api.com/get?email=".$geted_data['email']."&key=ZQvPPEceXqQMGhJNCN";


$res=httpGet($url_gend_cnt);


$data_of_gender_api=json_decode($res);

$gend_data=get_gend_flg($data_of_gender_api->gender);


$res=httpGet("https://api.genderize.io?name=".$data_of_gender_api->first_name);


$data_of_age=json_decode($res)->age;






$insert_query_db="INSERT INTO `".$list_name."` ".$get_isrt_dec_str." VALUE ".$str_of_isrt."'$str_of_tags','$sub_stat','$mail_src','','0','$date_add','$date_add','','$gend_data','$data_of_age','0')";




if ($conn3->query($insert_query_db) === TRUE) {
    $res_all_count+=1;
} else {
    echo "Error: " . $sql . "<br>" . $conn3->error;
}




}

}


$sql_updt_con_count = "UPDATE filedetails SET extra='$res_all_count' WHERE filename='$list_name'";

if ($conn2->query($sql_updt_con_count) === TRUE) {
	

$get_last_impo=$res_all_count-$fetch_count_data['extra'];


up_impo_data($con_impo_conn,$list_name,$mail_src,$get_last_impo);



} else {
    echo "Error updating record: " . $conn->error;
}





}else{


	$status=1;

}


$res_data['status']=$status;
$res_data['data_cnt']=$res_all_count;

echo json_encode($res_data);

?>

