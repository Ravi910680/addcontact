

<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];




require("../confige/managetag.php");
$array_of_tag = array();

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);
$result_flg=$result->num_rows;

while($row = $result->fetch_assoc()) {
        $temp_array["label"]=$row["tag"];
        $temp_array["value"]=$row["id"];

        array_push($array_of_tag,$temp_array);
    }


$geted_tag_array=json_encode($array_of_tag);












         $filename=explode("^",$_SESSION['listname']);
         $name_of_file=base64_decode($filename[1]);



?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
  <link href="./../../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css">
<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(https://fonts.googleapis.com/css?family=Varela+Round);
.hover-bottom:hover{
    border-bottom:1px solid white;

}
.card-hover:hover{
    background:#f2f2f2;
  cursor: pointer;
}
.fa-add{
    padding:20px;
        font-size: 100px;
    margin: 0 auto;
}
.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;

}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}



.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: 0 auto;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}





.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid #5a2977;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}







.select-wrapper {
        margin: auto;
        max-width: 600px;
        width: calc(100% - 40px);
      }

      .select-pure__select {
        align-items: center;
        background: white;
margin:10px;      
	border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        position: relative;
        transition: 0.2s;
        width: 40%;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 221px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

	align-items: 'center';
        background: #f2f2f2;
	border-radius: 4px;
font-size:13px;
        color:black;
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <script src="./../../assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <!-- Icons -->
  

 
 
  <!-- CSS Files -->
  <script>
  

  </script>

</head>
<div id="c"></div>
<body class="" style="background:#fff;">
  <div style="height:93vh">
  <?php require("../confige/header/header.php");?>

<nav class="navbar navbar-dark" style="background:white;height:7vh;top:8vh;border-bottom: 1px solid #ebeaeb;padding:10px;top:8vh;">
<div style="width:100%"><span style="float-left"><a class=" hover-bottom" href="/main/addcontact/" style="color:#4a154bd9;font-weight:900;">Return to dashboard</a></span>
<div class="float-right" onclick="getdata(click_Select_con)" style="height:100%;float:right;"><span class='text_list' style='color:#4a154bd9;font-weight:900;'>Give Option on  <?php echo $name_of_file;?></span></div></div>
</nav>

<style>
.text-sclt-opt{
    padding: 20px;
    width: 40%;
    font-size: 18px;
    color: rgba(36,28,21,0.65);
    font-weight: 500;
}
.btn:hover {
    box-shadow: none;
    transform: none;
}
.head-fr-any{
    padding: 20px;
    letter-spacing: -0.02rem;
    color: #241c15;
}
.sclt-opt{
    color: #241c15;
    padding: 10px;
    -webkit-font-smoothing: antialiased;
    font-family: " Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 500;
font-size: 18px;

}
.drp-btn:hover{
outline:2px solid darkcyan;
cursor:pointer;
}
.btn:hover{
transition:none;
}
.drp-btn{
    height: 50px;
    background: #f2f2f2;
    border: none;
    padding: 10px;
    font-size: 15px;
}

.boxes {
  margin: auto;
  padding: 50px;
  background: #484848;
}

/*Checkboxes styles*/
input[type="checkbox"] { display: none; }

input[type="checkbox"] + label {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 20px;
  font: 14px/20px 'Open Sans', Arial, sans-serif;
  color: #ddd;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}

input[type="checkbox"] + label:last-child { margin-bottom: 0; }

input[type="checkbox"] + label:before {
  content: '';
  display: block;
  width: 20px;
  height: 20px;
  border: 1px solid black;
  position: absolute;
  left: 0;
  top: 0;
  opacity: .6;
  -webkit-transition: all .12s, border-color .08s;
  transition: all .12s, border-color .08s;
}

input[type="checkbox"]:checked + label:before {
  width: 10px;
  top: -5px;
  left: 5px;
  border-radius: 0;
  opacity: 1;
  border-top-color: transparent;
  border-left-color: transparent;
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
}
.dropdown-menu .dropdown-item{
color:black !important;
}
.dropdown-menu .dropdown-item:hover{


cursor:pointer;



}



.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
	cursor: pointer;
}


.card{
border:1px solid rgba(0, 0, 0, 0.15);
}
a.card-link.once_edt {
    font-size: 15px;
}
.card-text{
    margin: 10px;
}
</style>
<div class="main-content" style="height:77vh;overflow-y:scroll;top:8vh;">

<div class="main-con-content container" id='select_opt_tab' style="">
<h1 class='head-fr-any'>Select contact Option For More convinient</h1>
<p class='text-sclt-opt'>Select different tags or option for differetn cluster and use with convinient with your campign.</p>
      

      <h3 class='sclt-opt'>Select Tag</h3>
      <span class="autocomplete-select"></span>

<h3 class='sclt-opt'>Choose subscription Status</h3>


<div class="dropdown" style='margin:10px;'>
    <button type="button" id='drp-stat' class="btn drp-btn btn-primary dropdown-toggle" data-toggle="dropdown">subscribe</button>
    <div class="dropdown-menu" style='border: 1px solid rgba(0, 0, 0, 0.15);box-shadow:none;'>
      <a class="dropdown-item status-sub" id='subscribe'>subscribe</a>
      <a class="dropdown-item status-sub" id='un-subscribe'>un-subscribe</a>
      <a class="dropdown-item status-sub" id='none-subscribe'>none-subscribe</a>
<a class="dropdown-item status-sub" id='bounced' >bounced</a>
    </div>
  </div>


<style>
.card{
border:1px solid rgba(0, 0, 0, 0.15);
}
</style>

<h3 class='sclt-opt'>Update Existing contact</h3>
 <input type="checkbox" id="box-3"  style='margin:10px;'>
  <label for="box-3" style='color:black;margin:10px;width:40%'>Select this option for  contact details if new contact found in this list automatically update.</label>

</div>
<div class="main-con-content container" id='final_end' style="text-align:center;display:none;">
<img style='padding:40px;' src='https://res.cloudinary.com/heptera/image/upload/v1581668463/icons8-survey-100_dornp4.png'>
<h2 class='head-fr-any' style='padding:10px;'>review your Contact Configuration</h2>
<div style='padding:50px;' class='row'>
<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">Selected Tag</h5>
    <h6 class="card-subtitle mb-2 text-muted">Verify your contact tag</h6>
    <div class="card-text" id='tag_ver_con'></div>
    <a href="#" class="card-link once_edt">edit tag</a>
    
  </div>
</div>
<div class="card" style="width: 18rem;margin:0px auto;">
  <div class="card-body">
    <h5 class="card-title">Subscribed status</h5>
    <h6 class="card-subtitle mb-2 text-muted">verify contact status</h6>
    <div class="card-text" id='once_stat' style='text-align:center;color:black;font-size:20px;font-weight:500;'></div>
    <a href="#" class="card-link once_edt">edit status</a>
    
  </div>
</div>
<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">Update User info</h5>
    <h6 class="card-subtitle mb-2 text-muted">Verify update Checked or not</h6>
    <div class="card-text" id='once_update' style='text-align:center;color:black;font-size:20px;font-weight:500;'></div>
    <a href="#" class="card-link once_edt">edit details</a>
  </div>
</div>
</div>

</div>



</div>







<nav class="navbar navbar-dark" style="background:white;top:8vh;border-top:1px solid #c3c0c3;height:8vh;padding:10px;">
<div style="width:100%">
<div class="float-right click-on-opt" style="height:100%;width:50%;float:right;">

<button type="submit" class="bottom-btn" id="cont_for_validate" style="background:#4a154bd9"><div class="row"><div style="margin:0px 10px;">Countinue to Store</div></div></button></div>
</div>

</nav>
</body>
<div id="res">
</div>



  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  <!--   Optional JS   -->
  <script src="./jsfile/bundel.min.js"></script>
  <!--   Argon JS   -->
  <script>

seted_opt={"tags":"","select_stat":"","update_pro":""};
get_status="";
$(document).on("click",".status-sub",function(){

 get_status=$(this).attr("id");

$("#drp-stat").html(get_status);

});




$(document).on("click","#insert_con_db",function(){


	$("#insert_con_db").children(".row").append("<div class='lds-ring'  style=''><div></div><div></div><div></div><div></div></div>");
	$.post("./final_addcon/insert_con.php",
  {
    name: seted_opt,
    city: "Duckburg"
  },
  function(data, status){

   
console.log(data);

//window.location ='./../mngc/#mngc#vc';

  });
});





$(document).on("click",".once_edt",function(){
$("#tag_ver_con").empty();
$("#final_end").css("display","none");
$("#select_opt_tab").css("display","block");
$("#insert_con_db").attr("id","cont_for_validate");
});


var data = '<?php echo $geted_tag_array; ?>';
    var json = JSON.parse(data);     

var autocomplete = new SelectPure(".autocomplete-select", {
        options: json,
        value: [],
        multiple: true,
        autocomplete: true,
        icon: "fa fa-times",
        onChange: value => { tag_get=value; },
        classNames: {
          select: "select-pure__select",
          dropdownShown: "select-pure__select--opened",
          multiselect: "select-pure__select--multiple",
          label: "select-pure__label",
          placeholder: "select-pure__placeholder",
          dropdown: "select-pure__options",
          option: "select-pure__option",
          autocompleteInput: "select-pure__autocomplete",
          selectedLabel: "select-pure__selected-label",
          selectedOption: "select-pure__option--selected",
          placeholderHidden: "select-pure__placeholder--hidden",
          optionHidden: "select-pure__option--hidden",
        }
      });


$(document).on( 'click', '#cont_for_validate', function(){
var update_pro_data=$("#box-3").prop('checked');
seted_opt.tags=tag_get;
seted_opt.select_stat=$("#drp-stat").html();
seted_opt.update_pro=update_pro_data;
console.log(seted_opt);
$("#select_opt_tab").css("display","none");
$("#final_end").css("display","block");

tag_get.forEach(append_tag);
$("#once_stat").html(seted_opt.select_stat);
$("#once_update").html(seted_opt.update_pro);
$(this).attr("id","insert_con_db");

});

function append_tag(item, index){
	let op = json.filter(e=> e.value == item);
	
$("#tag_ver_con").append("<span class='select-pure__selected-label'>"+op[0]['label']+"</span>");


}








  </script>
	 
	 
	 
	 
	 
	 
	 
	 
	 <script>
  function getdata(path){
      
      ChangeUrl(path,"?path="+path);
      
      $(".con-hover").css("display","block");

$(".submit-form-contact").attr("id",path);
$(".main-content").load(path+".php", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success"){
      $(".con-hover").css("display","none");
      $(".click-on-opt").css("display","block");
$(".submit-form-contact").click(function(){

submitcon(path);


});

    }
    if(statusTxt == "error"){
      $(".con-hover").css("display","none");}
  });
      
      
      

  }
  function ChangeUrl(title, url) {
    if (typeof (history.pushState) != "undefined") {
        var obj = { Title: title, Url: url };
        history.pushState(obj, obj.Title, obj.Url);
    } else {
        alert("Browser does not support HTML5.");
    }
}
      </script>
  <script>


$("#subfileform").submit(function(event){
	event.preventDefault(); //prevent default action 
	var post_url = $(this).attr("action"); //get form action url
	var request_method = $(this).attr("method"); //get form GET/POST method
	var form_data = $(this).serialize(); //Encode form elements for submission
	
	$.ajax({
		url:post_url,
   method:"POST",
   data:new FormData(this),
   contentType:false,
   cache:false,
   processData:false,
   beforeSend: function () {
         $("#loadsendlink").css("display","inline-block");
      
        },
   
	}).done(function(response){ //
    if(response==1){
$("#normalres").html("<div class='card bg-warning text-white'><div class='card-body'>not able to create table</div></div>");
 $("#loadsendlink").css("display","none");
    }else if(response==2){
$("#normalres").html("<div class='card bg-warning text-white'><div class='card-body'>not enter same data sheet name</div></div>");
 $("#loadsendlink").css("display","none");
    }else if(response==3){
$("#normalres").html("<div class='card bg-warning text-white'><div class='card-body'>please select valid csv</div></div>");
 $("#loadsendlink").css("display","none");
    }else{
    $("#loadsendlink").css("display","none");
    location.reload();
        $(".modal-body").html(response);
    }
	});
});






</script>
  
  


<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>

