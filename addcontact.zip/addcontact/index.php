



<?php
session_start();
require("./confige/fileconfige.php");


    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];
if(isset($_SESSION["email"])){
require("./confige/userconnect.php");
$sql = "SELECT id FROM userinfo WHERE email='$mail' and varflag='1'";


$result=$conn->query($sql);
$count = mysqli_num_rows($result);

if($count==1)
{

if (isset($_GET["path"])){



}




?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">

<link href="../fa-fold/css/all.css" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

  <link href="./../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />

  <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">
<script src="https://kit.fontawesome.com/a66ec178f8.js" crossorigin="anonymous"></script>
<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(http://fonts.googleapis.com/css?family=Varela+Round);
.tablediv{
    padding:10%;
}
tr{

border:1px solid #dedddc;
}


.con-of-tbl{
background:white;
border-radius:4px;
}

.col-header th{
padding-top:1rem !important;
padding-bottom:1rem !important;
}
.col-header{


color: white;
    font-size: 20px !important;
    background: darkcyan;
    font-weight: 700 !important;


}
.first-col{

display: block;
    
    width: 95%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


























.head-dash{
  font-family: 'Karla', sans-serif;
  font-size: 23px;
  color: #000000e0;
  width:50%;
}
body{
	
}

.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}

.row{
	width:100%;
	margin-left:0px;
	margin-right: 0px;
}
.head-con-rw{
	padding-top: 20px;
	padding-bottom: 20px;
}
.btn-con-top{
	width: 50%;
}

.bottom-btn:hover{
	cursor: pointer;
}







body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{
border-radius:4px;
border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#085861;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}








.con-of-dash-data{
	width:25%;
	margin: 0px auto;


}
.con-ch-dast-data{
text-align: center;
	border-radius: 5px;
	background:white;
	margin: 20px;

}

.icon-data-con{

	padding-top: 20px;
    padding-bottom: 20px;
}



.ico-fa-data{

	display: table-cell;
	vertical-align: middle;

    font-size: 30px;

    height: 60px;
    width:60px;
}




.con-ico-data{


    width: fit-content;
    margin: 0px auto;
    border-radius: 50%;
    height: 60px;
    width:60px;
}

.data-info-text{
  color: black;
  font-size: 37px;
  font-weight: bolder;
  padding-top: 10px;
    padding-bottom: 10px;
}

.data-head-line{
  padding-top: 10px;
    padding-bottom: 20px;
  color: #04040485;
    font-weight: 600;
}


.head-of-over{
  font-family: 'Karla', sans-serif;
  font-size: 20px;
  color: #000000e0;
  padding-top: 20px;
}



.table{
margin-bottom:0px;
}











.data-tbl-db{
 
  background: white;
  border-radius: 5px;
  
}

.data-belo-line{

    width: 500px;
    overflow: scroll;
    font-weight: 600;
    color: #0000006b;
}

.tbl-main-head{
  color: #000000cc;
    font-weight: bolder;
width: 200px;
    overflow-x: scroll;
}
.tbl-main-head::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE and Edge */
.tbl-main-head {
  -ms-overflow-style: none;
}

.tbl-link-clr{
  color: blue;
transition:.2s;



}


.tbl-link-clr:hover{
color:black;

}











.not-fd-data{
  text-align: center;
background:white;
border-radius:4px;

padding:20px;





}








.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

















@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);


.nav-link:hover{
    cursor:pointer;
}

ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;

}
.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}


td{
vertical-align: middle;

}

html{
background;#f0f8ffcf;
}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.con-of-tbl{
background:white;
border-radius:4px;
}
















button.btn_hover_clr {
    margin-top: 10px;

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }



.table td, .table th {
    font-size: 16px;
    white-space: nowrap;

  }












.tooltip2 .tooltiptext {
    visibility: hidden;
    width: 120px;
    font-size: 13px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    margin-left: -60px;
    margin-top: 20px;
    font-family: 'IBM Plex Sans', sans-serif;
    font-weight: 500;
  }
.tooltip2:hover .tooltiptext {
  visibility: visible;
}













.lds-color div{

border: 2px solid #4a154bd9;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-large div{
  width: 40px;
  height: 40px;
  border: 4px solid;

}



.lds-large {
    margin: auto;
    
    width: 40px;
    height: 40px;

  }

.main-content {
  height: 92vh;
  overflow: scroll;
}

   .lds-main-large{
top: 300px;
    left: 50%;

  }







i:hover{

  cursor: pointer;

}






.card{
  height: min-content;
  width: 30rem;
  border: 1px solid rgb(0 0 0 / 18%);

  
}

.head-cons-desg{
  padding: 50px 0px;
}

.card-img-top{

    padding: 40px;


}

.card-body{
  text-align: center;
}

.card-text{
  font-weight: 500;
  color: black;
}

.card-title {
    margin-bottom: 1.25rem;
    font-size: 20px;
color: black;
    }

    a.crt-api-btn {
    color: #3368fa;
    background-color: #fff;
    border-color: #3368fa;
    font-family: Colfax-Bold,Helvetica,Arial,sans-serif;
    font-style: normal;
    font-weight: 600;
    display: inline-block;
    padding: 12px 32px;
    font-size: 16px;
    line-height: normal;
    text-align: center;
    border: 2px solid transparent;
    border-radius: 3px;
    outline: 0;
    box-shadow: 0 2px 4px 0 #c8d7ee;
    transition: all .2s ease-in-out;
    border: 2px solid;

  }



.container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px 36px;
    border-bottom: 1px solid #dedddc;
  }

.container-2GnNH span{

font-size: 13px;

}









.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
  position: relative;
  display: flex;
}
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}




.full-mdl-con-lrg {
    width: 100%;
    height: 60vh;
    background: white;
border-radius: 10px;
  }

  .tw-rw-mdl-con {
    width: 49.7%;
    height: 60vh;
    display: inline-block;
    overflow: scroll;
    padding: 40px;
  }
  p.mdl-lrg-notc-txt {
    font-size: 13px;
    color: #565454;
    font-weight: 500;
    }


.tbl-link-clr:hover{
  cursor: pointer;
}







.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
  
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}



</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->

</head>

<body class="" style="">
  
<?php require("./confige/header/header.php");?>





<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>





<div id='main-content'>

  <div class='container' style="padding-top:100px;">



  	<div class='row head-con-rw'>

<div class='head-dash'>

</div>

<div class='btn-con-top' style='text-align:right'>
	<button  class="btn_hover_clr" data-modal-trigger='btn-of-mdl-crt-lst' id='btn-of-mdl-crt-lst-trg' style="float:none"><i class="fas fa-plus" style='padding-right:10px;'></i>create list</button>

	</div>

  	</div>


</div>




<div class='container'>
<?php require("./ajaxfile/ravi.php");?>

</div>




<div class="container row" style='margin:auto;margin-bottom:20px;'>

  <div class="card">
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1606639944/addcontact/12_Devices_a7jm8h.svg" alt="Card image cap" style="padding:0px;">
  <div class="card-body">
    <h3 class="card-title">Managment API</h3>
    <p class="card-text">Management API Is used for manage contact of contact list. <b>show,delete,add</b> contact from contact list</p>
   
<button  class="btn_hover_clr" style="float:none">Go To Console <i class="fal fa-external-link"></i></button>
  </div>
</div>



<div class="card" style="margin-left: auto;">
  
  <div class="container-2GnNH"><img src="https://res.cloudinary.com/heptera/image/upload/v1592640812/google-contacts_ywkv2b.png" alt="" role="presentation" class="icon-1sM2z" style="
    width: 60px;
    margin-right: 20px;
"><span><a href="/account/connected-sites/app-selection/">Connect your Google account <i class="fal fa-external-link"></i></a> Add contact that present in personal contact directly from Google Contact in list.</span>
</div>






<div class="container-2GnNH"><img src="https://res.cloudinary.com/heptera/image/upload/v1592640972/iconfinder_38_939833_jgcojl.png" alt="" role="presentation" class="icon-1sM2z" style="
    width: 60px;
    margin-right: 20px;
"><span><a href="/account/connected-sites/app-selection/">Connect your DropBox <i class="fal fa-external-link"></i></a> Import Contact from File store in DropBox and saved image present in DropBox.</span>
</div>







<div class="container-2GnNH"><img src="https://res.cloudinary.com/heptera/image/upload/v1592640737/google-drive_hxuzbw.png" alt="" role="presentation" class="icon-1sM2z" style="
    width: 60px;
    margin-right: 20px;
"><span><a href="/account/connected-sites/app-selection/">Connect your Google Drive <i class="fal fa-external-link"></i></a> For a import contact in list directly from drive CSV/XLS file.</span>
</div>



</div>


</div>







</div>






<div class="modal-2" data-modal="btn-of-mdl-crt-lst" id='btn-of-mdl-crt-lst'>
  <div class="modal-dialog modal-dialog-centered" style="max-width:70%;" role="document">
    <div class="modal-content" style="">

      
      
<div class="full-mdl-con-lrg">
    
        <div class="tw-rw-mdl-con" style="padding:0px;">

    <img src="https://res.cloudinary.com/heptera/image/upload/v1606578712/addcontact/3_Creative_design_dugtkh.svg" style="width: 100%;margin-top: auto;height: 100%;">
    
</div>
        <div class="tw-rw-mdl-con">

<button class="close" style="width:fit-content;"><i class="fal fa-times-circle"></i></button>
    
    <div style="width:100%;text-align:center;overflow: scroll;">

<div class="" style="text-align:left">
<h2 style="color:black;font-size:20px">Create new Template</h2>
<p class="mdl-lrg-notc-txt">Enter Valid email template name for your sutable audiance well design Template give high response.</p>
<div style="padding:20px 3px;">


<form id='crtnewlistsub' action='./ajaxfile/crtnewlist.php' method='post'>
<label style="font-weight:450;color:black;letter-spacing:0.6px;">Create Template</label>
       

<input class="ip-by-def-dsg"  id='nameofnewlist' name='nameofnewlist' type='text' style='padding-left:10px;height:40px;width:100%;min-width:100%;' required/>

<div style="color:red;font-weight:500;" class="res"></div>

          
         
<div style="padding-top:40px;text-align:center">
<button class="btn-theme-dsg" id="click_to_con" type="submit" style="
    float: none;
">Get Template<i class="fal fa-long-arrow-right" style="padding-left:10px;"></i></button>
</div>       

</div>

</form>
</div>
</div>
    
    

</div>
        
    
    
    </div>
      
    
    </div>
  </div>
</div>


</div>




<div class="modal-2" data-modal="del_lst_modal" id="del_lst_modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delet Template</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><i class="fal fa-times-circle"></i></span>
        </button>
      </div>
      <div class="modal-body">
        <label style="padding-top:10px;font-weight:450;color:black;letter-spacing:0.6px;">Whish To Delet Conatct List</label>
 <div id='del_list_name' style='color:red;font-weight:700;'></div>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn-theme-dsg" id='del_list_fin'>Confirm To Delete</button>
      </div>
    </div>
  </div>
</div>









  <script src="./../assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="./../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="./../assets/js/argon-dashboard1.js"></script>
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>
del_list=''; 
$(document).on("click",".del_list_name",function(){
del_list=$(this).attr("id");

$("#del_list_name").html(atob(del_list.split("^")[1]));

});

$(document).on("click","#del_list_fin",function(){


append_load_in_all_btn("#del_list_fin");


$.ajax({
  type: "POST",
  url: "./ajaxfile/del_list.php",
  data: {list_old_name:del_list}
}).done(function(response1) {


append_txt_of_lds("#del_list_fin");

        if(response1==1){
location.reload();

        }else{



err_msg_data(response1);


}
   
    
   
});




});

      </script>
  <script>


$("#crtnewlistsub").submit(function(event){
	event.preventDefault(); //prevent default action 
	var post_url = $(this).attr("action"); //get form action url
	var request_method = $(this).attr("method"); //get form GET/POST method
	var form_data = $(this).serialize(); //Encode form elements for submission
	
	$.ajax({
		url:post_url,
   method:"POST",
   data:new FormData(this),
   contentType:false,
   cache:false,
   processData:false,
   beforeSend: function () {
         
         append_load_in_all_btn("#click_to_con");
      
        },
   
	}).done(function(response){ //
	


append_txt_of_lds("#del_list_fin");


		if(response==1){

window.location = "./contact/";

		}else{


err_msg_data(response);


		}
	});
});




$(document).on("click",".opt_on_list",function(){
var type_opr=$(this).attr("id");
var define_opt1 = $(this).attr("class");
var define_opt=define_opt1.split(" ");
var final_opr=define_opt[1];  
  
      append_load_main_large("#main-content");


      $("#loadsendlink").css("display","inline-block");

    $.ajax({
                url : "./ajaxfile/crtseslist.php",
                type: "POST",
                data : "requestoflist="+type_opr
        }).done(function(response){ 
$("#res").html(response);
        if(response==1){

window.location = "./"+final_opr+"/#"+final_opr;


      }

        });
  
});





$(document).on('click','.del-mdl-cls-btn',function(){


modalEvent(this);



});




















function append_load_main_large(ele){

$(ele).html("<div class='lds-ring lds-color lds-large lds-main-large' id='lds-for-all-temp' style=''><div></div><div></div><div></div><div></div></div>");

}



$(document).on('click','#btn-of-mdl-crt-lst-trg',function(){


modalEvent(this);

})


function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');

    console.log(trigger)
    const modal = document.querySelector(`[data-modal=${trigger}]`);
    const contentWrapper = modal.querySelector('.content-wrapper');
    const close = modal.querySelector('.close');

    close.addEventListener('click', () => modal.classList.remove('open'));
    

    modal.classList.toggle('open');
  
}






append_txt_that_get_clck="";



function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}




function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}



$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})








</script>
  
  
</body>

<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>

<?php }else{
?>
<meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<script src="./../assets/js/plugins/jquery/dist/jquery.min.js"></script>
<link href="./../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />

<style>
.extracardcss{
     margin:auto;
margin-top:18%;
}

</style>
<body style="background:#f8f9fe;">


<div class="extracardcss card" style="width: 18rem;">
  
  <div class="card-body">
    <h5 class="card-title"><div class="navb">heptera|<sub>mail</sub></div></h5>
    <p class="card-text">For verify Your email adress please click on button and please verify your account</p>
    <input type="checkbox" id="terms" required> I accsept terms and condition.<br>
    <button id="sendlink" class="btn btn-warning" style="margin-top:25px" ><i id="loadsendlink" class="fa fa-circle-o-notch fa-spin" style="display:none"></i> send verify link</button>
  </div>
</div>













<script>
$(document).ready(function(){
  $("#sendlink").click(function(){
      var email="<?php echo $mail;?>"
      var id="<?php echo $id;?>"
      $("#loadsendlink").css("display","inline-block");
      
    $.ajax({
		url : "http://dash.heptera.me/ajaxphp/sendlink.php",
		type: "POST",
		data : "email="+email
	}).done(function(response){ //
        $("#loadsendlink").css("display","none");
		$("#sendlink").html(response);
        
	});
  });
});





</script>


<?php

}}else{
    header("location:http://heptera.me/login.php");
}
?>
