<?php


function get_email_col($list_id){
require("../../../confige/fileconfige.php");


	$get_col_query="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='storefile' AND `TABLE_NAME`='".$list_id."'";	

	$query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){
    

	$result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}





       







function get_col_type($list_id,$col_get){
require("../../../confige/fileconfige.php");

$columnArr=array();

$i=0;


while(count($col_get)>$i){
     



      $get_col_query="SELECT `DATA_TYPE` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE  `TABLE_NAME`='".$list_id."' AND COLUMN_NAME ='".$col_get[$i]."'";
        $query = $conn3->query($get_col_query);
      
while($row = $query->fetch_assoc()){
$data_type=$row['DATA_TYPE'];

  if($data_type=='varchar'){

                $dt_tp='text';
        }else if($data_type=='date'){
                $dt_tp='date';
        }else if ($data_type=='bigint' || $data_type=='int'){
                $dt_tp='int';
        }









array_push($columnArr,$dt_tp);
}

$i+=1;

}


return $columnArr;

}





?>
