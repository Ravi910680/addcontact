
$(document).ready(function(){
   

    id_now_path= window.location.href.split('#');
    console.log(id_now_path.length);
    for(i=0;i<id_now_path.length-1;i++){

          if(i==0){
            $("#"+id_now_path[i+1]).addClass("txt-of-opt-active");
            }else{
                    $("#"+id_now_path[i+1]).addClass("txt-of-opt-active");
                    $("#"+id_now_path[i+1]).css("border-bottom","none");
            }

    }
});



