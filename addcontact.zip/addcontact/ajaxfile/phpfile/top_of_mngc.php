

<?php


function url_origin( $s, $use_forwarded_host = false )
{
    $ssl      = ( ! empty( $s['HTTPS'] ) && $s['HTTPS'] == 'on' );
    $sp       = strtolower( $s['SERVER_PROTOCOL'] );
    $protocol = substr( $sp, 0, strpos( $sp, '/' ) ) . ( ( $ssl ) ? 's' : '' );
    $port     = $s['SERVER_PORT'];
    $port     = ( ( ! $ssl && $port=='80' ) || ( $ssl && $port=='443' ) ) ? '' : ':'.$port;
    $host     = ( $use_forwarded_host && isset( $s['HTTP_X_FORWARDED_HOST'] ) ) ? $s['HTTP_X_FORWARDED_HOST'] : ( isset( $s['HTTP_HOST'] ) ? $s['HTTP_HOST'] : null );
    $host     = isset( $host ) ? $host : $s['SERVER_NAME'] . $port;
    return $protocol . '://' . $host;
}

function full_url( $s, $use_forwarded_host = false )
{
    return url_origin( $s, $use_forwarded_host ) . $s['REQUEST_URI'];
}

$absolute_url = full_url( $_SERVER );




?>

<style> 
.upper-dir{
font-weight: 600;
    color:#104b7b;

width:100%;
position:fixed;
top:8vh;
z-index:10000000;

color:#104b7b;
}
.upper-dir span:hover{
cursor:pointer;
text-decoration:underline;
}

.row.lst-con-of-opt {
    margin-left: 0px;
    margin-right: 0px;

}
.txt-of-opt:hover {
    color: #104b7b;
    cursor: pointer;
    
}

.txt-of-opt {
    font-size: 14px;
    transition: .2s;
    padding: 13px;
    margin-right: 15px;
    color: black;
    font-weight: 400;
    font-smooth: auto;
    -webkit-font-smoothing: subpixel-antialiased;
    -moz-osx-font-smoothing: grayscale;
    font-weight: 500;

}
.txt-of-opt-active {
font-weight: 600 !important;
border-bottom:1px solid #104b7b;
color:#104b7b !important;


}

.dropdown-item:hover, .dropdown-item:focus{
    background: transparent;
}
.dp-con-opt{
margin-top:0px;
}
.dp-z-idx{
z-index:1000000000;


}
a.dropdown-item.dp-opt-lst {
    font-size: 12px;
}

.dropdown-item {
    font-weight: 500;
    color: #212529ad;
}

.navbar {
  
}
.dropdown-item:hover {
    background: #0d66d6 !important;
    color: white !important;
}

.txt-without-hover {
    font-size: 14px;
    transition: .2s;
    padding: 13px;
    margin-right: 15px;
    color: #4a154b;
    font-weight: 400;
    font-smooth: auto;
    -webkit-font-smoothing: subpixel-antialiased;
    -moz-osx-font-smoothing: grayscale;
    font-weight: 500;

}





button.btn_hover_clr {
    margin-top: 10px;

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }




.navbar-light .navbar-nav .nav-link {
    color: white;
    font-size: 1rem;
    font-weight: 500;


}

.dropdown-menu.show {
    border-radius: 10px !important;

}




.tooltip2 .tooltiptext {
    visibility: hidden;
    width: 120px;
    font-size: 13px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    margin-left: -60px;
    margin-top: 20px;
    font-family: 'IBM Plex Sans', sans-serif;
    font-weight: 500;
  }
.tooltip2:hover .tooltiptext {
  visibility: visible;
}




.txt-of-opt-active {
    background: #0d66d6;
    color: white !important;
}

.dropdown-item:hover, .dropdown-item:focus{

   
}









#main-loader-containre-act{


   
    
  }

.main-loader-containre-act{

    text-align: center !important;padding-top: 41vh !important;height: 84vh !important;display: block !important;
  
}













</style>

<div class="row upper-dir" style="margin-left: 0px;margin-right: 0px;background: white;border-bottom: 1px solid #ebeaeb;">
    <div class="left-top-loc" style="width: 20%;">
<div class="txt-without-hover com-for-lnk"  data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/">
    <i class="fal fa-long-arrow-alt-left" style="
    padding-right: 10px;
"></i><span>Return to Contact List</span>
    </div>
    </div>
<div class="opt-on-list" style="width: 60%;">

    <div class="row lst-con-of-opt">
<div class="txt-of-opt">Overview</div>

<div class="dropdown">

<div class="txt-of-opt" id='mngc' data-toggle="dropdown" aria-expanded="false">Manage Contact<span style="padding:5px;"> <span class="dropdown-caret"></span></span></div>

  <div class="dp-z-idx dp-con-opt dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 24px, 0px);">
    <a class="dropdown-item dp-opt-lst com-for-lnk" id='vc' href="#"    data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/mngc/#mngc#vc#vc2#<?php echo $lst_name;?>" id='vc' >View Contact</a>
    <a class="dropdown-item dp-opt-lst com-for-lnk"  id="arch_show" href="#" data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/mngc/#mngc#arch_show#<?php echo $lst_name;?>">View Archived Contact</a>
    <a class="dropdown-item dp-opt-lst com-for-lnk" id="unsub_add" href="#"   data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/mngc/#mngc#unsub_add#<?php echo $lst_name;?>">Unsubscribe Address</a>
<a class="dropdown-item dp-opt-lst com-for-lnk"  data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/segment/#mngc#seg#<?php echo $lst_name;?>"  id="seg">Sagment</a>
<a class="dropdown-item dp-opt-lst com-for-lnk"  data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/tags/#mngc#tg#<?php echo $lst_name;?>" id="tg">Tags</a>
<a class="dropdown-item dp-opt-lst com-for-lnk"  data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/import_data/#mngc#imp_dt#<?php echo $lst_name;?>" id="imp_dt">Import History</a>
<a class="dropdown-item dp-opt-lst com-for-lnk" href="#"    data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/mngc/#mngc#vc#arch_all#<?php echo $lst_name;?>">Archived All Contact</a>
<a class="dropdown-item dp-opt-lst" href="#" data-toggle="modal" data-target=".bd-example-modal-lg">Contact Export</a>

  </div>
</div>


        <div class="dropdown">

<div class="txt-of-opt" id='ac' data-toggle="dropdown" aria-expanded="false">Add Contact<span style="padding:5px;"> <span class="dropdown-caret"></span></span></div>

  <div class="dp-z-idx dp-con-opt dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 24px, 0px);">
    <a class="dropdown-item dp-opt-lst com-for-lnk" data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/contact/" href="#">Import Contact</a>
    <a class="dropdown-item dp-opt-lst com-for-lnk" id='as' data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/add_sub/#ac#as#<?php echo $lst_name;?>"  href="#">Add Contact</a>
    <a class="dropdown-item dp-opt-lst com-for-lnk" data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/emb/"  href="#">Import From Cloud</a>

</div>
</div>
        <div class="txt-of-opt com-for-lnk"   data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/fields/#fs#<?php echo $lst_name;?>" id='fs'>Field Setting</div>
        <div class="txt-of-opt com-for-lnk"  data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/list/analysis/#la#<?php echo $lst_name;?>" id='la'>List Analysis</div>


 </div>

    </div>


<div class="dropdown float-right" style="
  
    width: 20%;
">


<button class="btn_hover_clr" data-toggle="dropdown" aria-expanded="false" style="
    float: right;
    margin-top: 3px;
    margin-right: 20px;
">Change list<i class="fal fa-long-arrow-alt-down" aria-hidden="true" style="
    padding-left: 10px;
"></i></button>

        <div class="dropdown-menu" style="margin-top:0px;border:1px solid #bdbbb9">


<?php






$selectsite="SELECT * FROM filedetails WHERE id='$id'";
$selectedurl = $conn2->query($selectsite);


if ($selectedurl->num_rows > 0) {
        while($row = $selectedurl->fetch_assoc()) {
                $filename=explode("^",$row['filename']);
         $name_of_file=base64_decode($filename[1]);

?>

<a class="  dropdown-item com-for-lnk" id="<?php echo $row['filename'];?>" data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/ajaxfile/phpfile/ajaxfile/ses_of_chg_lst.php?requestoflist=<?php echo $row['filename'];?>&red_data=<?php echo $absolute_url."#".$row['filename'];?>"  style=""><?php echo $name_of_file;?></a>
<?php
}


}
        ?>
      <a class="dropdown-item" style="color:black;font-weight:700;border-top:1px solid #bdbbb9" href="../../addsite/">Creat new list</a>
    </div>
  </div>






</div>





<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" id="choose_img_in_fold" style=" padding-left: 0px;z-index: 107200000;" aria-modal="true">
  <div class="modal-dialog modal-lg" style="
  margin: 0px;
    
    margin-left: auto;
    
    height: 100vh;
    width: 40%;
    transform: none;
">
    <div class="modal-content" style="height: 100vh;border-radius: 0px;">
    <div class="modal-header" style="border-bottom:1px solid #dedddc;">
        <h4 class="modal-title">Export Contact</h4>
        <button type="button" class="close" data-dismiss="modal"><i class="fal fa-times-circle"></i></button>
      </div>
      


      <div class="modal-body" style="border-bottom:1px solid #dedddc;padding:0px;">


    <div class="export_con_mdl">
    
        <div class="main-img-con" style="
    text-align: center;
    padding: 40px;
">
        
            <img src="https://res.cloudinary.com/heptera/image/upload/v1606025794/addcontact/Container_ship-bro_clajdc.svg" style="
    height: 300px;
">
        
        </div>
    
    
    
    
    
    <div class="btn-for-exp-trg" style="
    width: 100%;
    text-align: center;
">
    
    <button class="btn-theme-dsg com-for-lnk" id="click_to_con" data-for-serv="0"  data-target-link="http://localhost/html/dash/main/addcontact/export/fin_export.php?src_req=normal" type="submit" style="
    float: none;
    width: 60%;
    margin:auto;
"><span>Click To Export</span><i class="fal fa-long-arrow-right" style="padding-left:10px;"></i></button>
    
    </div>
    
    
    </div>


      </div>
      
    </div>
  </div>
</div>


<script type="text/javascript">


$(document).ready(function(){






id_now_path= window.location.href.split('#');
    console.log(id_now_path.length);
    for(i=0;i<id_now_path.length-1;i++){
            if(i==0){
            $("#"+$.escapeSelector(id_now_path[i+1])).addClass("txt-of-opt-active");
            }else{


                
                    $("#"+$.escapeSelector(id_now_path[i+1])).addClass("txt-of-opt-active");





                    $("#"+$.escapeSelector(id_now_path[i+1])).css("border-bottom","none");
            }

    }


})




</script>





