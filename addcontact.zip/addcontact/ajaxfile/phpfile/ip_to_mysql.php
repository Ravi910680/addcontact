<?php


function get_txt_dt_tp($txt_val){


if($txt_val=="text"){

return "VARCHAR(255)";


}else if($txt_val=="date"){

return "DATE";


}else if($txt_val=="int"){

return "INT(10)";

}




}








?>
