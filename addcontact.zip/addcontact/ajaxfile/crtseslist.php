<?php

session_start();

if(isset($_SESSION['id'])){

$_SESSION['listname']=$_POST['requestoflist'];

echo 1;

}



?>
