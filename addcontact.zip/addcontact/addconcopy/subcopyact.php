<?php




$content = $_POST['copycontent'];

$rows = explode("\n", $content);
foreach($rows as $idx => $row)
{
    $row = explode( "\t", $row );
    foreach( $row as $field )
    {
        $arrayCode[$idx][] = $field;
    }
}
print_r( $arrayCode );

?>