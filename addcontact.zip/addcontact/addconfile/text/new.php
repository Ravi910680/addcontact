<?php




$file_data = fopen('./filee.csv', 'r');
$row = fgetcsv($file_data);

print_r($row);




?>
