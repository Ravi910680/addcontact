<?php
session_start();




function get_str_of_opt($var_of_tp){

$arr_of_tp=array("text","date","int");

$str_of_rt="<select id='stat_of_tp' class='ip-by-def-dsg' style='max-width:100%;width:100%;'>";

foreach ($arr_of_tp as $value) {
  
if($value==$var_of_tp){
  $flg_of_stat="Selected";
}else{

$flg_of_stat="";

}


$str_of_rt.="<option value='".$value."'".$flg_of_stat." >".$value."</option>";


}

$str_of_rt.="</select>";

return $str_of_rt;
}













require("../confige/fileconfige.php");
require("../ajaxfile/phpfile/get_tbl_col.php");


require("../ajaxfile/phpfile/mysql_to_ip.php");

require("../confige/camp_confige.php");




$lst_name=$_SESSION['listname'];
$get_camp_data="select * from camp_contact_tbl where list_id='$lst_name'";





$result = $camp_name_conn->query($get_camp_data);



$cnt_camp=$result->num_rows;





$get_col=get_email_col($_SESSION['listname']);



$get_col=array_slice($get_col,0,count($get_col)-$cnt_camp-11);



$mail=$_SESSION["email"];



?>




<html>
<head>


<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">

<!-- Latest compiled JavaScript -->



<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">


<style type="text/css">












.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid #fff;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #fff transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}





















#new_fld_tp select{
height: 40px;
    margin: 20px 0px;
    width: 20%;
}























.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;










}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}












.dlt_trg_icn{
font-size:20px !important;
text-align:center;
}




















body{

        background: #7a71ea0a;
}

.head_add_sub {
   color:#000000e0; 
    padding-bottom: 20px;
    font-size: 20px;
    font-weight: 600;
}

input[type="checkbox"] { display: none; }

input[type="checkbox"] + label {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 20px;
  font: 14px/20px 'Open Sans', Arial, sans-serif;
  color: #ddd;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}

input[type="checkbox"] + label:last-child { margin-bottom: 0; }

input[type="checkbox"] + label:before {
  content: '';
  display: block;
  width: 20px;
  height: 20px;
  border: 1px solid black;
  position: absolute;
  left: 0;
  top: 0;
  opacity: .6;
  -webkit-transition: all .12s, border-color .08s;
  transition: all .12s, border-color .08s;
}

input[type="checkbox"]:checked + label:before {
  width: 10px;
  top: -5px;
  left: 5px;
  border-radius: 0;
  opacity: 1;
  border-top-color: transparent;
  border-left-color: transparent;
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
}

.head-fr-any {
    padding: 20px 0px;
    letter-spacing: -0.02rem;
    color: #000000e0;
}
.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
                   float: right;
    padding-left: 20px;
    padding-right: 20px;
}
.bottom-btn:hover{
        cursor: pointer;
}

.fld_name_sty{
height: 40px;
    border-radius: 5px;
    border: 1px solid #f2f2f2;
    width: 200px;
    font-size: 15px;
    padding: 10px;
}
.mrg-tag-sty {
    font-size: 16px;
    font-weight: 700;
    height: 40px;
}




















.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
    position: relative;
    display: flex;
    text-align: center;
    color: #504b4b;
  }
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}






#main-loader-containre-act{


    text-align: none !important;
    
  }

.main-loader-containre-act{
  text-align: center !important;padding-top: 41vh;height: 84vh;
}





</style>
</head>
<body>
<?php require("../confige/header/header.php");?>



<?php require("../ajaxfile/phpfile/top_of_mngc.php");?>


<div id="main-loader-containre">



<div class='form_sub_data container' style='width:80%;padding-top:100px;'>




<div class='head_add_sub' style='padding:20px 0px;'>Table Field</div>




<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Field name</th>
      <th scope="col">Type</th>
      <th scope="col">Merge Tag</th>
      <th scope="col"></th>
    </tr>
  </thead>

<tbody>
   



<?php



for($i=0;$i<count($get_col);$i++){


$get_col_query="SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '".$lst_name."' AND COLUMN_NAME = '".$get_col[$i]."'";
$query = $conn3->query($get_col_query);


       $dt_of_colm=$query->fetch_assoc();

if($i!=0){
$org_ip_dt=get_mysql_to_ip($dt_of_colm['DATA_TYPE']);
}else{
$org_ip_dt='email';
}
    
?>

 <tr>
      <th scope="row"><?php echo $i;?></th>
      <td><input  class='get_val_data fld_name_sty' id='<?php echo $get_col[$i];?>' type='text' value='<?php echo $get_col[$i];?>' <?php  if($org_ip_dt=="email"){echo "disabled";}?>/>   </td>
      <td id='<?php echo $get_col[$i];?>dt_tp'><?php  if($org_ip_dt!=="email"){ echo  '<select id="stat_of_tp" class="ip-by-def-dsg" style="max-width: 100px;width:100%;height: 40px;margin: 0px;"><option value="text" selected="">text</option><option value="date">date</option><option value="int">int</option></select>';}else{echo "<select id='stat_of_tp' class='ip-by-def-dsg' style='max-width: 100px;width:100%;height: 40px;margin: 0px;'><option value='emai'>email</option></select>";}?></td>
      <td><div class="mrg-tag-sty">:<?php echo $get_col[$i];?>:</div></td>
       <td class=''><div class='dlt_trg_icn' data-modal-trigger="mdl_del_fld" id='<?php echo $get_col[$i];?>'><i class="far fa-trash-alt"></i></div></td>
    </tr>
<?php





}





?>


</tbody>
</table>

<div class='btn_end_con' style="margin-bottom:20px;">

  <button type="submit" class="bottom-btn sb_frm_dt" id='click_to_add' style="float:none;" ><div class="row"><div class="lds-ring" id='ld_for_sch' style='display:none'><div></div><div></div><div></div><div></div></div><div style='margin:0px 10px;'>Save Changes</div></div></button>

<button type="submit" class="bottom-btn crt_new_fld_mdl"  data-modal-trigger="crt_new_fld_in_tbl"  style='float:none;margin-left:20px;background:yellowgreen;'>Add Field</button>
</div>
</div>





</div>



<div class="modal-2" data-modal="mdl_del_fld" id='mdl_del_fld'>
  <article class="content-wrapper">
     
    
    

<div class="head-line-of-mdl">
    <h4>Delete Your Field In List</h4>

</div>

    <div class="content" style="
">
   <p style="
    font-weight: 400;
    font-size: 13px;
">Delete Your Field that you created in this selected list.</p>
   </div>


<div class="btn-con-del-camp" style="
    width: 100%;
">

    <button class="btn-theme-dsg " id="del_fld_fin" style="">Yes,Delete Campign</button>
    
    <button class="btn-theme-dsg  del_mdl_cls" mdl-cls-tp="mdl_del_fld"  style="background:white;color:#350835;border:1px solid #350835;">Cancel,Keep It Campign</button>

    
</div>


   
 
  </article>
</div>




<div class="modal-2" data-modal="crt_new_fld_in_tbl" id='crt_new_fld_in_tbl'>
  <article class="content-wrapper">
     
    
    

<div class="head-line-of-mdl" style="
    margin-right: auto;
    color:black;
">
    <h4>Create New Field</h4>

</div>

   


<div class="btn-con-del-camp" style="
    width: 100%;
">

   <input class="ip-by-def-dsg" id="fld_name" name="nameofnewlist" type="text" style="max-width:100%;" required="">
    
   <div class='' id='new_fld_tp'>

<?php
echo get_str_of_opt("all");

?>


</div>
    
</div>


    <button class="btn-theme-dsg " id="sb_frm_nw_fld" style="">Create New Field</button>
 

 <button class="btn-theme-dsg  del_mdl_cls" mdl-cls-tp="crt_new_fld_in_tbl"  style="background:white;color:#350835;border:1px solid #350835;">Cancel,Keep It Campign</button>


  </article>
</div>












</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>


<script>





























$(document).on("click",".sb_frm_dt",function(){
$("#ld_for_sch").css("display","inline-block");
  arr_of_json_obj=[];

$(".get_val_data").map(function(){

name_ext_val=$(this).attr("id");

new_name_val=$(this).val();
console.log(new_name_val);
get_tp_of_col=$("#"+name_ext_val+"dt_tp").children("#stat_of_tp").val();
loc_arr=[];

loc_arr[0]=name_ext_val;
loc_arr[1]=new_name_val;
loc_arr[2]=get_tp_of_col;

arr_of_json_obj.push(loc_arr);


});




myDataObject = new Object;
	myDataObject.Vehicles =arr_of_json_obj;;
	
str_json_dt= JSON.stringify(myDataObject);





$.ajax({
  type: "POST",
      
      url: "./ajaxfile/sb_frm_of_alter_col.php",
      data:{json_str:str_json_dt}
}).done(function(response1) {
	$("#ld_for_sch").css("display","none");

});


})

























function array1dToJson(a, p) {
      var i, s = '';
      for (i = 0; i < a.length; ++i) {
        if (typeof a[i] == 'string') {
          s += '"' + a[i] + '"';
        }
        else { // assume number type
          s += a[i];
        }
        if (i < a.length - 1) {
          s += ':';
        }
      }
      s += '';
      if (p) {
        return '{"' + p + '":' + s + '}';
      }
      return s;
    }












function array2dToJson(a, p, nl) {
      var i, j, s = '[{"' + p + '":{';
      nl = nl || '';
      for (i = 0; i < a.length; ++i) {
        s += nl + array1dToJson(a[i]);
        if (i < a.length - 1) {
          s += ',';
        }
      }
      s += nl + '}}]';
      return s;
    }







function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');
    const modal = document.querySelector(`[data-modal=${trigger}]`);
   
    
    
    
    

    modal.classList.toggle('open');
  
  
}



$(document).on('click',".del_mdl_cls",function(){


tp_of_mdl=$(this).attr("mdl-cls-tp");

$("#"+tp_of_mdl).removeClass("open");


})






del_fld='';


$(document).on("click",".dlt_trg_icn",function(){
del_fld=$(this).attr("id");

if(del_fld=="email"){

console.log("ravi");

}else{


modalEvent(this);


}

});

$(document).on("click","#del_fld_fin",function(){



ld_app_in_btn("#del_fld_fin");



$.ajax({
  type: "POST",
  url: "./ajaxfile/del_fld.php",
  data: {fld_old_name:del_fld}
}).done(function(response1) {

        if(response1==1){
location.reload();

        }else{

  
$("#del_load").css("display","none");
        }



});




});
















$(document).on("click","#sb_frm_nw_fld",function(){
 


ld_app_in_btn("#sb_frm_nw_fld");

var fld_new_name=$("#fld_name").val();

var fld_new_tp=$("#new_fld_tp").children("#stat_of_tp").val();




$.ajax({
  type: "POST",
      
      url: "./ajaxfile/sb_frm_new_fld.php",
      data:{fld_name:fld_new_name,fld_tp:fld_new_tp}
}).done(function(response1) {
  

app_txt_btn("#sb_frm_nw_fld");

   if(response1==1){
location.reload();

        }
});





});


btn_con="";

function ld_app_in_btn(id_sel){


btn_con=$(id_sel).html();

$(id_sel).prop('disabled', true);


$(id_sel).html('<div class="cp-spinner cp-round"></div>');



}



function app_txt_btn(id_sel){

  $(id_sel).html(btn_con);


}

$(document).on("click",".crt_new_fld_mdl",function(){

modalEvent(this);


})


</script>


</html>


       
