<?php
  
require("../../confige/fileconfige.php");
$del_fld= $_POST['fld_old_name'];


session_start();

$lst_name=$_SESSION['listname'];


$chg_dt_tp="ALTER TABLE `".$lst_name."` DROP COLUMN ".$del_fld;


if ($conn3->query($chg_dt_tp) === TRUE) {
  echo 1;
} else {
  echo 0;
}










          
         
          
         
        

?>     
