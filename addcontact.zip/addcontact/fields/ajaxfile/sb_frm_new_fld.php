<?php
session_start();
require("../../confige/fileconfige.php");

require("../../ajaxfile/phpfile/ip_to_mysql.php");



error_reporting(E_ERROR);


function get_email_col($list_id){
require("../../confige/fileconfige.php");


        $get_col_query="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='storefile' AND `TABLE_NAME`='".$list_id."'";

        $query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){


        $result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}
require("../../confige/camp_confige.php");
$lst_name=$_SESSION['listname'];
$get_camp_data="select * from camp_data where id LIKE '%".$lst_name."%'";

$result = $camp_name_conn->query($get_camp_data);

$cnt_camp=$result->num_rows;


$get_col=get_email_col($lst_name);

$get_col=array_slice($get_col,0,count($get_col)-$cnt_camp-11);



$fld_name=$_POST['fld_name'];
$fld_tp=$_POST['fld_tp'];




$get_txt_tp=get_txt_dt_tp($fld_tp);



$chg_dt_tp="ALTER TABLE `".$lst_name."` ADD ".$fld_name." ".$get_txt_tp." after ".end($get_col);
if ($conn3->query($chg_dt_tp) === TRUE) {
  echo 1;
} else {
  echo 0;
}











          
         
          
         
        

?>
