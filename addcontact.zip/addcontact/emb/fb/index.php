<?php
session_start();
require("../../../../confige/userconnect.php");

 $mail=$_SESSION["email"];
    $id=$_SESSION["id"];


$sql_soc_stat = "SELECT * FROM userinfo WHERE email='$mail' and fb='empty'";


$result=$conn->query($sql_soc_stat);

$count = mysqli_num_rows($result);




?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<style type="text/css">

.con-fb-connect {
    padding-top: 10%;
    height: 100vh;
    overflow: scroll;
}
.card-img-top{

  margin: auto;
  height: 64px;
  width: 64px;
}


.card{
padding-top: 20px;
    padding-bottom: 20px;

  }
  img.list-img-right {
    height: 36px;
    padding-right: 30px;
  }





.bottom-btn{
  text-align: center;
    height: 40px;
    background: #4a154bd9;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border:1px solid  #4a154bd9;
   width:100%;
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
  cursor: pointer;
}


</style>
<script type="text/javascript">





</script>

<div class='con-fb-connect'>

<div class="card" style="width: 30rem;margin:auto;">
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1592641066/facebook_2_lw3ko8.png"  alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Connect FaceBook Account</h5>
    <p class="card-text">FaceBook Connect is helpfull to sheduled post for your account.</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Not, used your personal data.</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Sheduled post on Your Time.</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Connect Multiple Account with multiple pages</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">social media analysis.</li>
  </ul>
  <div class="card-body">
  <fb:login-button scope='public_profile,email' onlogin='checkLoginState();'>Connect Facebook</fb:login-button> </div></div>

</div>



<script>


tok_flg='<?php echo $count;?>';


  function statusChangeCallback(response) {  // Called with the results from FB.getLoginStatus().
                     // The current login status of the person.
    if (response.status === 'connected') { 



	    clientId="531342854255918";
	    clientSecret="74e28ea363558063e444e99b16d654dd";

	    let userAccessToken = response.authResponse.accessToken;




console.log(userAccessToken);
            $.get(`https://graph.facebook.com/oauth/access_token?client_id=${clientId}&client_secret=${clientSecret}&grant_type=fb_exchange_token&fb_exchange_token=${userAccessToken}`)
            .then((response) => {
               

	    if(tok_flg==1){



		    up_fb_tok(response.access_token,'fb');

up_fb_tok('get_tok','ig');

	    }else{
 multi_acc(response.access_token,'fb');

	    }
















             });







     


    } else {                                 // Not logged into your webpage or we are unable to tell.
      document.getElementById('status').innerHTML = 'Please log ' +
        'into this webpage.';
    }
  }


function multi_acc(access_token_new,app_id_t){

$.ajax({
                url : "../ajaxfile/multi_acc.php",
                type: "POST",
                data : {access_token:access_token_new,app_id:app_id_t}
        }).done(function(response){ 
console.log(response);
if(response==1){
window.location.href="../../emb/";
}


});

}





function up_fb_tok(res_tok,tok_tp){

$.ajax({
                url : "../ajaxfile/sub_acc_token.php",
                type: "POST",
                data : {access_tok:res_tok,access_tp:tok_tp}
        }).done(function(response){ 
console.log(response);
if(response){
	
window.location.href="../../emb/";
	
	}
        });


}






  function checkLoginState() {               // Called when a person is finished with the Login Button.
    FB.getLoginStatus(function(response) {

       // See the onlogin handler
      statusChangeCallback(response);
    });
  }


  window.fbAsyncInit = function() {
    FB.init({
      appId      : '531342854255918',
      cookie     : true,                     // Enable cookies to allow the server to access the session.
      xfbml      : true,                     // Parse social plugins on this webpage.
      version    : 'v6.0'           // Use this Graph API version for this call.
    });


    
  };

  
  (function(d, s, id) {                      // Load the SDK asynchronously
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));

 
  





 </script>




