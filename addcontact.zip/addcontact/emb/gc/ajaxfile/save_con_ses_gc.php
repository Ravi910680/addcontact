<?php
session_start();

$_SESSION['src_of_mail']="google contact";
$_SESSION['email_data']=$_POST['json_str'];
echo 1;

?>
