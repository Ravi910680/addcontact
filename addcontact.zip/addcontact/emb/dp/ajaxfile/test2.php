<?php




$data=shell_exec('curl -X POST https://content.dropboxapi.com/2/files/download --header "Authorization: Bearer z2HtsEaLdFAAAAAAAAAAexEgg2z2pcQdN7bmjU9FY6ZrpOsyP4sMKfwjXneBQbhG" \--header "Dropbox-API-Arg: {\"path\": \"/5^dw5kzwzpbmu=^0.jpeg\"}" \-o "./Prime_Numbers.jpg"');
echo $data;

?>
