    <style>
.button-select-file{
    
}




.fad {
    color: orange;


}


i.fad.fa-file-csv {
    color: darkblue;

}

#custom-button {
  width:10%;
  color: black;
  background-color: #f2f2f2;
  
  
  cursor: pointer;
}

#custom-button:hover {
  background-color: f;
}

#content-name {
   
    width:40%;
    border:1px solid rgba(36,28,21,0.3);
  margin-left: 10px;
  font-family: sans-serif;
  letter-spacing:0.5px;
  color: #aaa;
  padding:10px;
}


    </style>    

<script>



</script>




















<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];
if(isset($_SESSION["email"])){
require("../../../confige/userconnect.php");

$sql = "SELECT * FROM userinfo WHERE email='$mail' and varflag='1'";


$result=$conn->query($sql);
$count = mysqli_num_rows($result);

if($count==1)
{


if(isset($_SESSION['img_insta'])){


$insta_url=$_SESSION['img_insta'];
}else {


$insta_url="https://res.cloudinary.com/heptera/image/upload/v1592641126/instagram-sketched_wza9vp.png";

}

require("../../../confige/fileconfige.php");


$append_in_not_add_str="";


$selectsite="SELECT * FROM filedetails WHERE id='$id'";
$selectedurl = $conn2->query($selectsite);

$str_of_lable="";
if ($selectedurl->num_rows > 0) {
        while($row = $selectedurl->fetch_assoc()) {
                $filename=explode("^",$row['filename']);
         $name_of_file=base64_decode($filename[1]);



$str_of_lable.="<option class='opt_on_list mngc dropdown-item' value='".$row['filename']."'  style=''>".$name_of_file."</option>";



}


}




while($row = $result->fetch_assoc()) {


$data_user=$row;

}


$_SESSION['tw_token']=$data_user['tw'];






require("../../../confige/conn_part.php");

$sql_for_part = "SELECT * FROM part_lst";
$result_part = $conn_part->query($sql_for_part);
$loc_rw=array();
$append_in_add_str="";


$flg_fr_con=0;
  // output data of each row
  while($row = $result_part->fetch_assoc()) {


$loc_rw[$row['part_id']]=$row;	


$head_str="<div class='rem_api_token' style='text-align: right;'><i data-toggle='modal' id='".$row['part_id']."' data-target='#del_app_from_part' class='fal fa-times rem_api_token_ico' aria-hidden='true'></i></div>";

        if($row['part_id']=="fb" || $row['part_id']=="tw"){

$head_str="<div class='rem_api_token row' style='text-align: right;'><div class='main_emb_para click_to_go_con' id='".$row['part_id']."' style='width: 50%;text-align: left;'>Add Onther Account</div><div style='width: 50%;'><i data-toggle='modal' id='".$row['part_id']."' data-target='#del_app_from_part' class='fal fa-times rem_api_token_ico' aria-hidden='true'></i></div></div>";
        }



if($data_user[$row['part_id']]=="empty"){


$append_in_add_str.="<div class='main_con_of_emb'><div class='row'><div class='main_ico_emb'><img src='https://res.cloudinary.com/heptera/image/upload/".$row['part_logo']."' height='64'></div><div class='main_txt_emb'><h3>".$row['part_name']."</h3><p class='main_emb_para'>".$row['part_desc']."</p></div></div><button class='bottom-btn click_to_go_con'  id='".$row['part_id']."'    >Connect</button></div>";
    
  


}else{
$flg_fr_con=1;
	$append_in_not_add_str.="<div class='main_con_of_emb'>".$head_str."<div class='row'><div class='main_ico_emb'><img src='https://res.cloudinary.com/heptera/image/upload/".$row['part_logo']."' height='72'></div><div class='main_txt_emb'><h3>".$row['part_name']."</h3><p class='main_emb_para'>".$row['part_desc']."</p></div></div><button class='bottom-btn use_it_app' id='".$row['part_id']."' style='background:#4a154bd9;color:white;' data-toggle='modal'  data-target='#use_it_app_mod'>Use It ".$row['part_name']."</button></div>";

if($row['part_id']=="dp"){
 echo "<script src='https://cdn.jsdelivr.net/npm/promise-polyfill@7/dist/polyfill.min.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/fetch/2.0.3/fetch.js'></script><script src='https://unpkg.com/dropbox/dist/Dropbox-sdk.min.js'></script>";
}



}







  }

$json_part_arr=json_encode($loc_rw);














if (isset($_GET["path"])){



}




?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
  <link href="./../../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />
  <script src="https://kit.fontawesome.com/a66ec178f8.js" crossorigin="anonymous"></script>
<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(http://fonts.googleapis.com/css?family=Varela+Round);
.hover-bottom:hover{
    border-bottom:1px solid white;

}
.card-hover:hover{
    background:#f2f2f2;
  cursor: pointer;
}


.rem_api_token {
    text-align: center;
color: #c7c2c2;


}
.rem_api_token_ico:hover{
cursor: pointer;
color: #6f6d6d;
}







.follo span {
    padding-right: 6px;
    color: black;
    font-weight: 700;
    padding-left: 10px;
}



.follo {
    padding: 10px;
    color: #8c7c7c;
    padding-top: 0px;
    font-weight: 500;


}














.fa-add{
    padding:20px;
        font-size: 100px;
    margin: 0 auto;
}

i.fas.fa-flag-alt {
    font-size: 20px;
    padding: 10px;
    color: orange;

}


.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;

}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: 0 auto;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.unique-name:focus{
    border:2px solid;
}

.file-upload{display:block;text-align:center;font-family: Helvetica, Arial, sans-serif;font-size: 12px;}
.file-upload .file-select{display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select .file-select-button{background:#dce4ec;font-weight:900;font-size:15px;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
.file-upload .file-select:hover{border-color:#34495e;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select:hover .file-select-button{background:#34495e;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select{border-color:#3fa46a;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select .file-select-button{background:#3fa46a;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select input[type=file]{z-index:100;cursor:pointer;position:absolute;height:100%;width:100%;top:0;left:0;opacity:0;filter:alpha(opacity=0);}
.file-upload .file-select.file-select-disabled{opacity:0.65;}
.file-upload .file-select.file-select-disabled:hover{cursor:default;display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;margin-top:5px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select.file-select-disabled:hover .file-select-button{background:#dce4ec;color:#666666;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select.file-select-disabled:hover .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
.emb_con:hover{
border-color:#007c89 !important;
}
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
 
<link href="../../fa-fold/css/all.css" rel="stylesheet">


<script type="text/javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
  <!-- Icons -->
  

 
 
  <!-- CSS Files -->


</head>
<div id="c"></div>
<body class="" style="background:#fff;">
  <div style="height:93vh">
  <?php require("../confige/header/header.php");?>

<nav class="navbar navbar-dark" style="background:white;height:7vh;top:8vh;border-bottom: 1px solid #ebeaeb;padding:10px;top:8vh;">
<div style="width:100%"><span style="float-left"><a class=" hover-bottom" href="/main/addcontact/" style="color:#4a154bd9;font-weight:900;">Return to dashboard</a></span>
</div></nav>

<style>
.main_con_of_emb{
margin-right: auto;
    margin-top: 20px;
  padding:10px;
  width:364px;
  border: 1px solid #c3c0c3;
    border-radius: 10px;
}
.main_ico_emb{
  width:fit-content;
  padding:10px;
}
.row{
margin:0px;
}





.lds-color div{

border: 2px solid #4a154bd9 !important;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

i.fad.fa-at {
    color: blueviolet;

}


.bottom-btn i{

padding-left:10px;

}



.file_data_hand.row {
    padding: 10px;
    border-bottom: 1px solid #ebeaeb;
    color: #5f285a;
    font-weight: 500;
    }

    .logo_fl_con {
    padding: 3px;
    width: 10%;

    }

    .cont_of_fl_name {
    width: 60%;
    font-weight: 500;
    font-size: 14px;
    color: #8c7c7c;
    text-align: left;
    padding: 3px;

    }

    .opt_of_work {
    width: 30%;

    }

















.head_mod{
width:50%;
padding:10px;

}






.bottom-btn{
  text-align: center;
    height: 40px;
    background: white;
    color: #4a154bd9;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border:1px solid  #4a154bd9;
   width:100%; 
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
	cursor: pointer;
}
.main_emb_para{
font-size: 0.8rem;
    font-weight: 500;
    color: #8c7c7c;
    margin-bottom: 0px;
}

.main_txt_emb{
width:250px;

color:black;
 padding:10px; 
}

.mod_ico_data_part {
    width: 50%;
}


.select_lst_data {
    width: 50%;

}

.sel_main_app{


color: black !important;
    border: 1px solid #868686;
    font-weight: 600;

}
.sel_main_app:focus{

border:1px solid #868686;

box-shadow: rgb(18, 90, 163) 0px 0px 0px 1px, rgba(29, 155, 209, 0.3) 0px 0px 0px 5px;

}

.modal_res_connect {
    padding: 20px 0px;

}

.main_txt_emb h3{
color:black;

}
</style>



<?php


if($flg_fr_con){
?>
<div class="main-content row" style="margin:40px;top:8vh;">
<p class="main_emb_para" style="width: 100%;
    "
>Installed App</p><br>


<?php echo $append_in_not_add_str;?>


      
    </div> 




<?php

}
?>


















<div class="main-content row" style="margin:40px;top:8vh;">
<p class="main_emb_para" style="width: 100%;
    "
>Reccomended App</p><br>


<?php echo $append_in_add_str;?>


      
    </div>        
</body>
<div class="res">
</div>


<div id="del_app_from_part" class="modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalCenterTitle" style="
    color: #4a154bd9;
">Disconnect App</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><i  class="fal fa-times" ></i></span>
        </button>
      </div>
      <div class="modal-body" style="text-align:center;">
        

<div class="mod_des_val" style="
    width: 50%;
    margin: auto;
">
          
          <img src="" class="img_rem_mod" height="72">
          
    <h3 class="rem_mod_name"></h3>

<p class="main_emb_para rem_mod_desc"></p>

      
    
    
          </div>




<button class="bottom-btn rem_mod_sub_btn" style="width:fit-content;margin: 20px 0px;background: #4a154bd9;color: white;"><div class="row">Disconnect App</div></button>

      </div>
      

    </div>
  </div>
</div>














<div id="use_it_app_mod" class="modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display:none; padding-left: 0px;" aria-modal="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="
    min-width: 700px;
">
    <div class="modal-content" style="
    min-height: 600px;
">
      <div class="modal-header" style="height:70px";>
        <h3 class="modal-title" id="exampleModalCenterTitle" style="
    color: #4a154bd9;
">Disconnect App</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><i class="fal fa-times" aria-hidden="true"></i></span>
        </button>
      </div>
     


      <div class="modal-body" style="height: 530px;text-align:center;">

    <div class="mod_act_head row" style="
    text-align: left;
    padding: 20px;
height:88px;
">
    <div class="mod_ico_data_part">
    <img src="https://res.cloudinary.com/heptera/image/upload/v1592640972/iconfinder_38_939833_jgcojl.png" class="img_mod_data_app" height="48" style="
    display: inline-block;
"><h3 style="
    display: inline-block;
    padding: 0px 10px;
" class="app_name_mod">DropBox</h3>
        

    </div>
    
    
    <div class="select_lst_data">
    
         <select class="form-control sel_main_app" id="exampleFormControlSelect1" style="
    height: 40px;
   
   ">
      <?php echo $str_of_lable;?>
    </select>
    
    </div>
    </div>

<div class="head_of_act_mod" style="height:50px;"></div>

<div class="modal_res_connect" style="height:312px;overflow: scroll;"></div>
      
     <div class="not_of_data" style="padding:10px;height:40px;"><p class="main_emb_para"><i class="fad fa-sticky-note" style="
    color: red;
    padding-right: 10px;
"></i>If You Added Contact From Cloud Please Select List Above.</p></div> 
</div>
    </div>
  </div>
</div>


<style>

.form-check-input{
width: 15px;
    height: 15px;
}
img.insta_pro_pic {
    border-radius: 50%;
  
}

</style>




 
  <script src="./../../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="./../../assets/js/argon-dashboard1.js"></script>
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>


  </script>
<script>

part_js_data='<?php echo $json_part_arr;?>';

json_dec_part=JSON.parse(part_js_data);




id_usr="<?php echo $id;?>";






















$(document).on("change",".sel_main_app",function(){
type_opr=$(this).val();

  
      
     console.log(type_opr);
    $.ajax({
                url : "../ajaxfile/crtseslist.php",
                type: "POST",
                data : "requestoflist="+type_opr
        }).done(function(response){ 
        

        });
  
});


























access_gc_token="";














$(document).on("click",".use_it_app",function(){


$(".head_of_act_mod").empty();
$(".modal_res_connect").html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");



get_id_use=$(this).attr("id");
init_head_mod_data(get_id_use);
if(get_id_use=="dp"){
	
init_dropbox_data_mod();

}else if(get_id_use=="gc"){





init_google_c_mod();














}else if(get_id_use=="fb"){




init_fb_in_mod();



}else if(get_id_use=="ig"){


init_insta_account_mod();


}else if(get_id_use=="tw"){



	tw_init_mod_data();


}

})






function init_head_mod_data(app_id){
    

$(".img_mod_data_app").attr("src","https://res.cloudinary.com/heptera/image/upload/"+json_dec_part[app_id]['part_logo']);

$(".app_name_mod").html(json_dec_part[app_id]['part_name']);


}














function init_google_c_mod(){

access_gc_token='<?php echo $data_user['gc'];?>';


 $.get("https://www.google.com/m8/feeds/contacts/default/thin?alt=json&access_token=" +access_gc_token + "&max-results=500&v=3.0",
                function(response){
			//process the response here
			//
			//
			//



                  console.log(response.feed.entry[0].gd$email[0]);
	       
	init_gc_mod_con(response.feed.entry);
	
	
		}).fail(function() {






not_found_data("gc");

});
}



obj_ml_lst_all=[];
str_of_gc_dt=""

function init_gc_mod_con(get_data_con){
console.log(get_data_con);

	$(".head_of_act_mod").html("<div class='data_email_act row' style='height: 50px;'><div class='cont_of_fl_name head_mod'><button class='bottom-btn add_sel_con_gc' style='text-align: left;height: auto;border: none;width:auto;' >Add Selected Contact<i class='fad fa-long-arrow-right' aria-hidden='true'></i></button></div><div class='cont_of_fl_name head_mod'><button class='bottom-btn add_all_con_gc' style='text-align: right;height: auto;border: none;width:auto;float:right;' >Add All Contact<i class='fad fa-long-arrow-right' aria-hidden='true'></i></button></div></div>");
	for ( j = 0; j < get_data_con.length; j++) {


try{



loc_arr={};

loc_arr['email']=get_data_con[j].gd$email[0].address;
obj_ml_lst_all.push(loc_arr);

str_of_gc_dt+="<div class='file_data_hand row'><div class='logo_fl_con'><i class='fad fa-at'></i></div><div class='cont_of_fl_name'>"+get_data_con[j].gd$email[0].address+"</div><div class='opt_of_work'><div class='form-check'><input class='form-check-input stat_up_main_dt' type='checkbox' id='"+get_data_con[j].gd$email[0].address+"'></div></div></div>";

}catch (err){



}




	};


json_str_all_st=JSON.stringify(obj_ml_lst_all);

console.log(json_str_all_st);

$(".modal_res_connect").html(str_of_gc_dt);


str_of_gc_dt=""

}





$(document).on("click",".add_all_con_gc",function(){


	$(this).html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");
    
send_req_gc_ses(json_str_all_st);

});








function not_found_data(app_id){
    
$(".modal_res_connect").html("<button class='bottom-btn click_to_go_con' style='width:fit-content;margin: 20px 0px;background: #4a154bd9;color: white;' id='"+app_id+"'>Connect Once Again</button>");


}

















arr_of_mail_gc_dt=[];

$(document).on("click",".stat_up_main_dt",function(){



if($(this).hasClass("add_in_lst_ml") != true){
    
$(this).addClass("add_in_lst_ml");

}else{

$(this).removeClass("add_in_lst_ml");

}



});

$(document).on("click",".add_sel_con_gc",function(){

$(this).html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");
i=0;
$(".add_in_lst_ml").map(function(){

	loc_arr={};

loc_arr['email']=$(this).attr("id");

arr_of_mail_gc_dt.push(loc_arr);

i++;
});

json_str_dt=JSON.stringify(arr_of_mail_gc_dt);

send_req_gc_ses(json_str_dt);




});



















function send_req_gc_ses(json_dt){



$.ajax({
  type: "POST",
  url: "./gc/ajaxfile/save_con_ses_gc.php",
  data: {json_str:json_dt}
}).done(function(response1) {

      window.location ='./../select_opt/';
    
  



});




}














access_dp_token="";




function init_dropbox_data_mod(){

file_arr_data=[];

$(".head_of_act_mod").html("");

access_dp_token='<?php echo $data_user['dp'];?>';

var dbx = new Dropbox.Dropbox({ accessToken: access_dp_token });
      dbx.filesListFolder({path: ''})
        .then(function(response) {



		console.log(response.entries);
		for(i=0;i<response.entries.length;i++){
loc_data_arr=[];
			if(response.entries[i].path_lower.match(/.(jpg|jpeg|png|gif)$/i)){

				loc_data_arr[0]=response.entries[i].name;
				loc_data_arr[1]="image";
 loc_data_arr[2]=response.entries[i].id;
 loc_data_arr[3]=response.entries[i].path_lower;
file_arr_data.push(loc_data_arr);
			}else if(response.entries[i].path_lower.match(/.(csv)$/i)){

loc_data_arr[0]=response.entries[i].name;
                                loc_data_arr[1]="csv";
loc_data_arr[2]=response.entries[i].id;

loc_data_arr[3]=response.entries[i].path_lower;


file_arr_data.push(loc_data_arr);



			}








		}


         console.log(file_arr_data);

file_init_img_db_data(file_arr_data);


	})
        .catch(function(error) {
          console.error(error);
        });

}









str_of_ing_dt="";

function file_init_img_db_data(arr_of_data){
	
for(i=0;i<arr_of_data.length;i++){
	console.log(arr_of_data[1]); 
if(arr_of_data[i][1]=="image"){
str_of_ing_dt+="<div class='file_data_hand row'><div class='logo_fl_con'><i class='fad fa-images'></i></div><div class='cont_of_fl_name'>"+arr_of_data[i][0]+"</div><div class='opt_of_work'><button class='bottom-btn down_ld_dp_fl' style='height: auto;border: none;' data-name='"+arr_of_data[i][0]+"' data-path='"+arr_of_data[i][3]+"' >Add to Studio<i class='fad fa-long-arrow-right' aria-hidden='true'></i></button> </div></div>";

}else{


str_of_ing_dt+="<div class='file_data_hand row'><div class='logo_fl_con'><i class='fad fa-file-csv'></i></div><div class='cont_of_fl_name'>"+arr_of_data[i][0]+"</div><div class='opt_of_work'><button class='bottom-btn down_csv_fl_ld' style='height: auto;border: none;' data-name='"+arr_of_data[i][0]+"' data-path='"+arr_of_data[i][3]+"' >Add to Contact<i class='fad fa-long-arrow-right' aria-hidden='true'></i></button> </div></div>";

}


}
console.log(str_of_ing_dt);

$(".modal_res_connect").html(str_of_ing_dt);
str_of_ing_dt="";
}










$(document).on("click",".down_ld_dp_fl",function(){


$(this).html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");






path_dt=$(this).attr("data-path");
path_name=$(this).attr("data-name");

$(this).attr("data-path","none");


$(this).attr("data-name","none");


console.log("fl_path-"+path_dt);

console.log("path_name-"+path_name);

console.log("acc_tok-"+access_dp_token);

$.ajax({
  type: "GET",
  url: "https://img.sycista.com/save_dp_fl.php",
  data: {fl_path:path_dt,fl_name:path_name,acc_tok:access_dp_token,id:id_usr}
}).done(function(response1) {

       console.log(response1); 
	if(response1==1){



	}	
    
  



});


$(this).html("<i class='fad fa-check' style='color:#82c91e'></i>"); ;


});





$(document).on("click",".down_csv_fl_ld",function(){
$(this).html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");	

path_dt=$(this).attr("data-path");


$.ajax({
  type: "POST",
  url: "./dp/ajaxfile/dl_csv_fl.php",
  data: {fl_path:path_dt,acc_tok:access_dp_token}
}).done(function(response1) {

        


$.ajax({
  type: "POST",
  url: "../addconfile/subfileact.php",
  data: {frm:"dp"}
}).done(function(response1) {

console.log(response1);
if(response1==0){
	
window.location ='./../select_opt/';
}



   
   
});




    
 
});


})










$(document).on("click",".click_to_go_con",function(){


id_dis_tp=$(this).attr("id");

window.location.href="./"+id_dis_tp+"/";

      

        });









//twitter api
//
//
//




access_gc_token='<?php echo $data_user['tw']  ?>';


function tw_init_mod_data(){

$.ajax({
                url : "./tw/get_pro_det.php",
                type: "POST",
                data : "tw_token="+access_gc_token
        }).done(function(response){
jsn_tw_data=JSON.parse(response);

$(".modal_res_connect").html("<img src='"+jsn_tw_data.pro_pic_tw+"' height='64' class='insta_pro_pic'/><br><h3 style='color:black;padding:10px;'>"+jsn_tw_data.tw_name+"</h3><div class='follo'><span>"+jsn_tw_data.flw+"</span> following <span>"+jsn_tw_data.flr+"</span> followers</div><button class='bottom-btn send_for_post' style='width:fit-content;background: #4a154bd9;color: white;' >Create Post</button>");

console.log(jsn_tw_data);
        });




}




//twitter end






























//facebook api 


access_fb_token='<?php echo $data_user['fb'];?>';

access_ig_token='<?php echo $data_user['ig'];?>';



page_fb_data=[];





function init_fb_in_mod(){

$.get(`https://graph.facebook.com/v7.0/me?fields=id&access_token=${access_fb_token}`)
            .then((response) => {

	    console.log(response.id);




init_fb_in_page_mod(response.id);



            })



}


function init_fb_in_page_mod(id_acc){

$.get(`https://graph.facebook.com/v7.0/${id_acc}/accounts?access_token=${access_fb_token}`)
            .then((response) => {

	   page_fb_data=response.data;
	  init_modal_fb_page_pub(response.data);



            })



}


function init_modal_fb_page_pub(data_page){
	str_of_app="";
$(".head_of_act_mod").html("<div class='row' style='height: 50px;'><div class='cont_of_fl_name head_mod' style='width: 100%;'><button class='bottom-btn add_insta_acc' style='text-align: right;height: auto;border: none;width:auto;float:right;background: #4a154bd9;color: white;padding: 6px;'><i class='fab fa-instagram' style='color:white;padding-right:10px;'></i>Connect Instagram</button></div></div>");
	if(data_page.length>0){
 for(k=0;k<data_page.length;k++){
	 pg_name=data_page[k].name;
	 cat_of_page=data_page[k].category;
                   
str_of_app+="<div class='file_data_hand row'><div class='logo_fl_con'><i class='fas fa-flag-alt'></i></div><div class='cont_of_fl_name' style='color: black;font-weight: 800;'>"+pg_name+"<br><p class='main_emb_para'>"+cat_of_page+"</p></div><div class='opt_of_work'><button class='bottom-btn send_for_post'   style='height: auto;border: none;padding: 10px;' >Sheduled Post<i class='fad fa-long-arrow-right' aria-hidden='true'></i></button> </div></div>";


 }
$(".modal_res_connect").html(str_of_app);
 }else{






$(".modal_res_connect").html("<a href='https://facebook.com/'><button class='bottom-btn' style='width:fit-content;margin: 20px 0px;background: #4a154bd9;color: white;' >Connect Once Again</button><a>");




 }




}






$(document).on("click",".add_insta_acc",function(){
append_load("add_insta_acc");	
insta_connect_face();

});





function insta_connect_face(){
	



for(k=0;k<page_fb_data.length;k++){

page_id=page_fb_data[k].id;

$.get("https://graph.facebook.com/v7.0/"+page_id+"?fields=instagram_business_account&access_token="+access_fb_token)
            .then((response) => {


insta_id=response.instagram_business_account.id;

if(insta_id.length>0){

$.get("https://graph.facebook.com/v7.0/"+insta_id+"?fields=username,profile_picture_url&access_token="+access_fb_token)
            .then((response) => {

console.log(response);




insta_pro=response.profile_picture_url;

$.ajax({
                url : "./ajaxfile/crt_ses_img.php",
                type: "POST",
                data : {insta_img:insta_pro}
        }).done(function(response){
console.log(response);

        });









set_data_of_emb(response.username,'ig');

            })

}

            })



}


}


function init_insta_account_mod(){

str_app="<img src='<?php echo $insta_url;?>' height='64' class='insta_pro_pic'/><br><h3 style='color:black;padding:10px;'>"+access_ig_token+"</h3><button class='bottom-btn' style='width:fit-content;background: #4a154bd9;color: white;' >Create Post</button>";



$(".modal_res_connect").html(str_app);


}


function set_data_of_emb(token,app_name){

$.ajax({
                url : "./ajaxfile/sub_acc_token.php",
                type: "POST",
                data : {access_tok:token,access_tp:app_name}
        }).done(function(response){ 
console.log(response);
if(response){


window.location.href="../emb/";

}else{


}
        });

}













$(document).on("click",".send_for_post",function(){

window.location.href="../../social/";

})



















//fb api end



$(document).on("click",".rem_api_token_ico",function(){


id_part=$(this).attr("id");

$(".img_rem_mod").attr("src","https://res.cloudinary.com/heptera/image/upload/"+json_dec_part[id_part]['part_logo']);
$(".rem_mod_name").html(json_dec_part[id_part]['part_name']);
$(".rem_mod_desc").html(json_dec_part[id_part]['part_desc']);
$(".rem_mod_sub_btn").attr("id",id_part);



});

function append_load(get_date){

$("."+get_date).children(".row").append("<div class='lds-ring'  style=''><div></div><div></div><div></div><div></div></div>");

    }


        $(document).on("click",".rem_mod_sub_btn",function(){

append_load("rem_mod_sub_btn");
id_dis_tp=$(this).attr("id");
$.ajax({
                url : "./ajaxfile/sub_acc_token.php",
                type: "POST",
                data : {access_tok:"empty",access_tp:id_dis_tp}
        }).done(function(response){ 
console.log(response);
if(response){
window.location.href="../emb/";
}else{


}
        });
      

        });





  $('#chooseFile').change(function () {
  var filename = $("#chooseFile").val();
 
  if (/^\s*$/.test(filename)) {
    $(".file-upload").removeClass('active');
    $("#noFile").text("No file chosen..."); 
  }
  else {
    $(".file-upload").addClass('active');
    $("#noFile").text(filename.replace("C:\\fakepath\\", "")); 
  }
});


  </script>
  <script>
  function getdata(path){
      
      ChangeUrl(path,"?path="+path);
      
      $(".con-hover").css("display","block");

$(".submit-form-contact").attr("id",path);
$(".main-content").load(path+".php", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success"){
      $(".con-hover").css("display","none");
      $(".click-on-opt").css("display","block");
$(".submit-form-contact").click(function(){

submitcon(path);


});

    }
    if(statusTxt == "error"){
      $(".con-hover").css("display","none");}
  });
      
      
      

  }
  function ChangeUrl(title, url) {
    if (typeof (history.pushState) != "undefined") {
        var obj = { Title: title, Url: url };
        history.pushState(obj, obj.Title, obj.Url);
    } else {
        alert("Browser does not support HTML5.");
    }
}
      </script>
  <script>


$("#subfileform").submit(function(event){
	event.preventDefault(); //prevent default action 
	var post_url = $(this).attr("action"); //get form action url
	var request_method = $(this).attr("method"); //get form GET/POST method
	var form_data = $(this).serialize(); //Encode form elements for submission
	
	$.ajax({
		url:post_url,
   method:"POST",
   data:new FormData(this),
   contentType:false,
   cache:false,
   processData:false,
   beforeSend: function () {
         $("#loadsendlink").css("display","inline-block");
      
        },
   
	}).done(function(response){ //
  $(".res").html(response);
	});
});






</script>
  
  


<script type="text/javascript" src="../../jsfile/stickyheader4.js">

</script>



</html>

<?php }else{
?>
<meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<script src="./../../assets/js/plugins/jquery/dist/jquery.min.js"></script>
<link href="./../../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />

<style>
.extracardcss{
     margin:auto;
margin-top:18%;
}

</style>
<body style="background:#f8f9fe;">


<div class="extracardcss card" style="width: 18rem;">
  
  <div class="card-body">
    <h5 class="card-title"><div class="navb">heptera|<sub>mail</sub></div></h5>
    <p class="card-text">For verify Your email adress please click on button and please verify your account</p>
    <input type="checkbox" id="terms" required> I accsept terms and condition.<br>
    <button id="sendlink" class="btn btn-warning" style="margin-top:25px" ><i id="loadsendlink" class="fa fa-circle-o-notch fa-spin" style="display:none"></i> send verify link</button>
  </div>
</div>













<script>
$(document).ready(function(){
  $("#sendlink").click(function(){
      var email="<?php echo $mail;?>"
      var id="<?php echo $id;?>"
      $("#loadsendlink").css("display","inline-block");
      
    $.ajax({
		url : "http://dash.heptera.me/ajaxphp/sendlink.php",
		type: "POST",
		data : "email="+email
	}).done(function(response){ //
        $("#loadsendlink").css("display","none");
		$("#sendlink").html(response);
        
	});
  });
});





</script>


<?php

}}else{
    header("location:http://heptera.me/login.php");
}
?>
