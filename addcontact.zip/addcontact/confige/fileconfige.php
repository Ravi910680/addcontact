<?php
$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$dbname = "storefile";
$dbname2="filemail";
$conn3 = mysqli_connect($servername, $username, $password,$dbname);

$conn2 = mysqli_connect($servername, $username, $password,$dbname2);
?>
