<?php

session_start();
$array_jsn=array();

foreach ($_POST as $key => $value){
 


	$array_jsn[$key]=$value;




}


$_SESSION['email_data']=json_encode($array_jsn);
$_SESSION['src_of_mail']='admin';



echo 0;



?>
