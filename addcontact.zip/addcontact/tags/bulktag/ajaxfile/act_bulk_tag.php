<?php



$array_res_data=array();

if(!empty($_FILES['file']['name']))
{


$filename = explode(".", $_FILES['file']['name']);
  if($filename[1] == 'csv')
  {


 $file_data = fopen($_FILES['file']['tmp_name'], 'r');
      $row = fgetcsv($file_data);
      $collom=count($row);
       

       while($row = fgetcsv($file_data)){


for ($x = 0; $x < $collom; $x++){
           if (filter_var($row[$x], FILTER_VALIDATE_EMAIL)) {

             
           array_push($array_res_data, $row[$x]);

           break;	

           }

       }


       }



}




}

$json_arr=json_encode($array_res_data);
echo $json_arr;


?>
