


<?php
session_start();
require("../../../confige/fileconfige.php");
require("../ajaxfile/phpfile/get_tbl_col.php");


require("../ajaxfile/phpfile/mysql_to_ip.php");

$lst_name=$_SESSION['listname'];

$get_col=get_email_col($_SESSION['listname']);
if($_GET['src_req']=='normal'){
$query="select * from `".$lst_name."` where arch=0";
}else{
$query="select * from `".$lst_name."` where tag LIKE '%".$_GET['tag_send']."%' and arch=0";



}

header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, $get_col);  
     
      $result = $conn3->query($query);

if ($result->num_rows > 0) {
  
  while($row = $result->fetch_assoc()) {
    fputcsv($output, $row); 
  }


fclose($output); 

} else {
  echo "0 row";
}
      


echo "<script>window.close();</script>";


      ?>
