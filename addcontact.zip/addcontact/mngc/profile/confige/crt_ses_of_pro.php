<?php
session_start();

$_SESSION['pro_email']=$_GET['pro_email_req'];
$_SESSION['pro_id']=$_GET['pro_id'];

header("location: http://localhost/html/dash/main/addcontact/mngc/profile/#mngc");



?>