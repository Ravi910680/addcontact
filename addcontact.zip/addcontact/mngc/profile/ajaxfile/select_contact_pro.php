<?php
session_start();

require("../../../../../confige/fileconfige.php");





$id=$_SESSION['id'];


$lst_name=$_SESSION['listname'];

$email_pro=$_SESSION['pro_email'];

$sel_query="select * from `".$lst_name."` where email='$email_pro'";


$result=$conn3->query($sel_query);


$row = $result->fetch_assoc();




print_r(json_encode($row));



?>