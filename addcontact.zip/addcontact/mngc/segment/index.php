



<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];
if(isset($_SESSION["email"])){
require("../../../confige/userconnect.php");
require("../../../confige/fileconfige.php");
require("../../../confige/managetag.php");

require("../../../confige/camp_confige.php");
$lst_name=$_SESSION['listname'];
$get_camp_data="select * from camp_data where id LIKE '%".$lst_name."%'";

$result = $camp_con->query($get_camp_data);

$cnt_camp=$result->num_rows;



$array_of_tag = array();

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);


while($row = $result->fetch_assoc()) {
        $temp_array["label"]=$row["tag"];
        $temp_array["value"]=$row["id"];

        array_push($array_of_tag,$temp_array);
    }


$geted_tag_array=json_encode($array_of_tag);






require("../ajaxfile/phpfile/get_tbl_col.php");


$get_col=get_email_col($_SESSION['listname']);

$get_col=array_slice($get_col,0,count($get_col)-$cnt_camp);


$sql = "SELECT id FROM userinfo WHERE email='$mail' and varflag='1'";


$result=$conn->query($sql);
$count = mysqli_num_rows($result);

if($count==1){

	if(isset($_SESSION['listname'])){




?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
<script src="https://kit.fontawesome.com/a66ec178f8.js" crossorigin="anonymous"></script> 
<link rel="stylesheet" type="text/css" href="css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="css/demo.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
 <link href="./../../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />
<style>







.select_new_sty{
  width: 200px !important;
}
.container{
  padding: 50px;
}
.con_fr_que{
margin: 0px;
margin-top: 20px;
    padding: 40px;
    border: 2px solid #f2f2f2;
    border-radius: 5px;

}

.desgn_ele_sel:focus{

 border: 2px solid #80bdff !important;

}

.desgn_ele_sel {


    margin: 0px !important;
   
    margin-left: 30px !important;
    margin-right: 30px !important;
    border: 2px solid #f2f2f2 !important;
    height: 40px !important;
    width: 250px !important;
    }



















.cbx {
  margin: auto;
  -webkit-user-select: none;
  user-select: none;
  cursor: pointer;
}
.cbx span {
  display: inline-block;
  vertical-align: middle;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child {
  position: relative;
  width: 18px;
  height: 18px;
  border-radius: 3px;
  transform: scale(1);
  vertical-align: middle;
  border: 1px solid #9098A9;
  transition: all 0.2s ease;
}
.cbx span:first-child svg {
  position: absolute;
  top: 3px;
  left: 2px;
  fill: none;
  stroke: #FFFFFF;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 16px;
  stroke-dashoffset: 16px;
  transition: all 0.3s ease;
  transition-delay: 0.1s;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child:before {
  content: "";
  width: 100%;
  height: 100%;
  background: #506EEC;
  display: block;
  transform: scale(0);
  opacity: 1;
  border-radius: 50%;
}
.cbx span:last-child {
  padding-left: 8px;
}
.cbx:hover span:first-child {
  border-color: #506EEC;
}

.inp-cbx:checked + .cbx span:first-child {
  background: #506EEC;
  border-color: #506EEC;
  animation: wave 0.4s ease;
}
.inp-cbx:checked + .cbx span:first-child svg {
  stroke-dashoffset: 0;
}
.inp-cbx:checked + .cbx span:first-child:before {
  transform: scale(3.5);
  opacity: 0;
  transition: all 0.6s ease;
}

@keyframes wave {
  50% {
    transform: scale(0.9);
  }
}



















@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(https://fonts.googleapis.com/css?family=Dosis);
.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
.upper-dir{



}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->

</head>
<div id="c"></div>
<body class="" style="background:#fff">


<style>


.dropdown-menu{
    border-radius:0px;
    box-shadow:none;
    
    border:1px solid #dedddc;
overflow-y:scroll;   
}
.below-tit{
font-weight: 400;
    font-size: 18px;
    padding-top: 20px;
    color: #000000c7;
    font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    letter-spacing: 1px;
}
.color-fet{
padding-left:10px;
padding-right:10px;
font-weight:600;
}

</style>

<?php require("../../../confige/header/header.html");?>

<?php require("../ajaxfile/phpfile/top_of_mngc.php");?>






<div class="container" style="border-bottom:1px solid;width:100%;">

<div class="cont-head-con" style="padding:30px;">
<div style="width:100%">
<span style="font-weight:1000;letter-spacing:2px;font-size:30px;"><span style='color:#5a2977bd;'><?php

$filename=explode("^",$_SESSION['listname']);
         $name_of_file=base64_decode($filename[1]);
echo $name_of_file;
         ?></span></span>
</div>

<div class='below-tit'>
<span>segment in <span style="color:#5a2977bd;"><?php echo $name_of_file;?></span></span>
</div>


</div>

</div>
<style>







.select-wrapper {
        margin: auto;
        max-width: 600px;
        width: calc(100% - 40px);
      }

      .select-pure__select {
        align-items: center;
        background: white;
margin:10px;      
	border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        position: absolute;
        transition: 0.2s;
        width: 300px;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 220px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

	align-items: 'center';
       
	border-radius: 4px;
font-size:13px;
        color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }
























.con-of-data {
 max-width:80%;
  max-height: 20em;
  overflow: scroll;
  position: relative;
}

table {
    
  position: relative;
  border-collapse: collapse;
}
tr{
    outline: 1px solid rgb(222, 221, 220);
}
td,
th {
  padding: 0.25em;
}

thead th {
    
    
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  top: 0;
background: #ededf5ed;
    color: #090942;
 

 z-index: 100000;
}

thead th:first-child {
outline: 1px solid rgb(222, 221, 220); 
  left: 0;
  z-index: 1000000000;
}

tbody th {
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  left: 0;
  background: #FFF;
  
}
tbody tr th{
  outline:  1px solid rgb(222, 221, 220); 
    z-index: 1000;
    background: white;
}
.con-data{
min-width: 150px;
max-width: 200px;
overflow: scroll;
padding: 12px 24px;
height:49px;
}
th .email-con{


color:black;


}
.email-con{
overflow-x:scroll;
    width:200px;
 padding-left: 20px;
    margin-right: 20px;   
  
}
.email-con::-webkit-scrollbar {
  display: none;
}
.con-of-data{
margin:0px auto;

margin-bottom:60px;
  color: #090942; 
    outline: 1px solid rgb(222, 221, 220); 

font-size:15px;
}

th.email-con:hover {
    cursor: pointer;
}


.con-data::-webkit-scrollbar {
  display: none;
}



.row.con_of_opt {



transition: all 0.5s ease 0s;

    background: #5a297708;
    margin: 60px auto 0px auto;
    max-width: 80%;
    max-height: 20em;
    position: relative;
    font-weight: 900;
    color: #5a2977;
}


.main_con_opt{
padding:20px;
}

</style>



<div class='con-of-data '>
  <table class='table-data-con'>
    <thead>

      <tr>


<th style='z-index:1000000;background: #5a2977;' > <div class='email-con' style='color:white;'>email</div> </th>

<?php

for($i=1;$i<count($get_col);$i++){


?>
        
        <th><div class='con-data'><?php echo $get_col[$i];?></div></th>
       	
       
<?php

}
?>
      </tr>

    </thead>
    <tbody>
      
    </tbody>
  </table>
</div>




<div class="container" id="con_of_opt">

</div>








<button class="bottom-btn" id="add_ele_to_seg"> add</button>

<button class="bottom-btn" id="save_data">save</button>







<style>









.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid #fff;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #fff transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}


.tag_ext_con {
    height: 220px;
    margin-top: 58px;
padding:10px;
}

















.tag_filt_con{
margin:3px;
}
.tag_con_act{


color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
}






.dropdown1 {
  position: relative;
  display: inline-block;
}

.dropdown1-content {
display:none;
height:350px;
  position: absolute;
  background-color: white;

border-radius: 0px 0px 10px 10px;
  min-width: 352px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 10000000;


}


.main_con_opt:hover{
cursor:pointer;
}


.row.tag_link_con {
    margin: 0px;
  height:50px;
}
.link_hr {
    width: 50%;
    font-size: 17px;
    padding:10px 0px;
    color: #5a2977;
}

.dropdown1:hover .dropdown1-content{
 
}
.btn-link:hover{
color:#5a2977;
background:rgba(90, 41, 119, 0.11);

}

.btn-link{
padding:5px;
border-radius:5px;
background: transparent;
    font-weight: 600;
    box-shadow: none;
transition:0.1s; 
   border: none;
}

</style>






<div class="site-footer" style="width:100%;background:#f1f3f4">


<div class="d-inline-flex" style="margin-left:10%;margin-right:10%;margin-top:5%;padding-bottom:4%;border-bottom:2px solid #f2f2f2">


<div class="navbar-brand" >heptera|<sub>mail</sub></div>


<div style="font-size:14px;line-height:1.8;max-width:50%">
<div> A heptera|<sub>mail</sub> is a initiative of heptera group. heptera is a web service based company and we provide different type of web service like SEO,Mail marketing ,data analytics or site data analysis</div>
<div>This plateform provide you to send bulk mail and also sell your mail with your niche branch.</div>
</div>





</div>
<div class="d-inline-flex" style="margin-left:10%;margin-right:10%;margin-top:5%;padding-bottom:4%;border-bottom:2px solid #f2f2f2;font-size:14px">
<div style="font-size:30px;font-weight:bold" >heptera</div>
<div class="bottomic" style="padding:15px">
<a class="bottomicon" href="">SEO / <a>
<a class="bottomicon" href="">DATA ANALITICS / <a>
<a class="bottomicon" href="">MAIL MARKETING / <a>
<a class="bottomicon" href="">WEB SERVICE / <a>
<a class="bottomicon" href="">SITE ANALISIS / <a>
</div>
</div>
</div>


<div id='res4'></div>



  <script src="./../../assets/js/plugins/jquery/dist/jquery.min.js"></script>
 
 <script src="../select_opt/jsfile/bundel.min.js"></script>
<script>
  //      $(document).ready(function(){
    //     jQuery.get('ravi.html', function(data) {
//		$("#tbl-con").append(data);
//	 });
//jQuery.get('ravi1.html', function(data) {
  //              $(".sticky-wrap").append(data);
    //     });
	//	
//
//
//







obj_data={};


obj_data.text=["is match","start with","find","not contain"];
obj_data.int=["is equal to","is greater","is less","is not equal to"];
obj_data.date=["before date","after date","before 2 day","before 5 day"];
obj_data.flg_camp=["opened","click","was sent","did not open","did not click","was not sent"];
obj_data.flg_camp2=["any of 5 campign","in last 7 day","in last 1 month","in last 3 month"];
obj_data.flg_conv=["is replied","no replied"];
obj_data.flg_conv2=["any of 5 campign","in last 7 day","in last 1 month","in last 3 month"];
obj_data.flg_cli=["is","is not"];
obj_data.flg_cli2=["gmail","yahoo","outlook","hotmail","AOL"];
obj_data.flg_src=["was","was not"];
obj_data.flg_src2=["By admin","API","File","cloud"];
obj_data.flg_sub=["is","is not"];
obj_data.flg_sub2=["subscribe","bounced","un-subscribe","none-subscribe","VIP"];
obj_data.flg_tag=["is","is not"];
obj_data.flg_tag2=["newsletter","exit"];



arry_of_fld={fld_name:["email","firstname","lastname","address","phone","birthdate"],fld_type:["text","text","text","text","text","date"]};


arry_of_fld_hy={fld_name:["add_date","last_chg","eml_cli"],fld_type:["date","date","flg_cli"],fld_name_sh:["added date","last change Info","email client"]};


arry_of_fld_req_res={fld_name:["camp_act","con_rat","source","substatus","tag"],fld_type:["flg_camp","int","flg_src","flg_sub","flg_tag"],fld_name_sh:["campign activity","contact rating","source of contact","subscriber status","by tag"]};


add_field_seg();


function add_field_seg(){
str_for_app="<div class='row con_fr_que'><select class='desgn_ele_sel form-control form-control-sm mx-sm-3 mb-2 select_new_sty sel_data' data-next='1-3'>";


str_for_app+="<optgroup label='Admin Field'>";
for (var i = 0; i < arry_of_fld["fld_name"].length; i++) {
  str_for_app+="<option value='"+arry_of_fld["fld_name"][i]+"^1^"+arry_of_fld["fld_type"][i]+"'>"+arry_of_fld["fld_name"][i]+"</option>";
};

str_for_app+="</optgroup>";



str_for_app+="<optgroup label='Emain History'>";
for (var i = 0; i < arry_of_fld_hy["fld_name"].length; i++) {
  
str_for_app+="<option value='"+arry_of_fld_hy["fld_name"][i]+"^1^"+arry_of_fld_hy["fld_type"][i]+"'>"+arry_of_fld_hy["fld_name_sh"][i]+"</option>";

};

str_for_app+="</optgroup>";


str_for_app+="<optgroup label='Campign Monitoring'>";
for (var i = 0; i < arry_of_fld_req_res["fld_name"].length; i++) {
  str_for_app+="<option value='"+arry_of_fld_req_res["fld_name"][i]+"^1^"+arry_of_fld_req_res["fld_type"][i]+"'>"+arry_of_fld_req_res["fld_name_sh"][i]+"</option>";
};

str_for_app+="</optgroup>";

str_for_app+="</select></div>";

$("#con_of_opt").append(str_for_app);

}


$(document).on("click","#add_ele_to_seg",function(){

console.log(save_data_json_form());

if(save_data_json_form()==0){

console.log("please select req Field");
}else{

add_field_seg();
}
});



function get_flg_str_data(rem_data_2,rem_data_1,cnt_loc,type_data,data_flg){


if(rem_data_2==rem_data_1){


str_for_app+=get_init_str(cnt_loc,type_data+"2",data_flg,2);


}else{

str_for_app+=get_init_str(cnt_loc,type_data,data_flg);


str_for_app+="</select>";


rem_data_1+=1;

data_flg=rem_data_1+"-"+rem_data_2;

str_for_app+=get_init_str(cnt_loc,type_data+"2",data_flg,2);


}

}







function get_init_str(cnt_loc,type_data,data_flg,flg_stat){

console.log(type_data);



str_for_app="";

if(flg_stat==2){
str_for_app+="<select class='desgn_ele_sel form-control form-control-sm mx-sm-3 mb-2 select_new_sty' data-next="+data_flg+">";
}else{

str_for_app+="<select class='desgn_ele_sel form-control form-control-sm mx-sm-3 mb-2 select_new_sty sel_data' data-next="+data_flg+">";

}
for (var i = 0; i < obj_data[type_data].length; i++) {
  str_for_app+="<option value='"+obj_data[type_data][i]+"^"+cnt_loc+"^"+type_data+"'>"+obj_data[type_data][i]+"</option>";
}

return str_for_app;
}



function append_select_data(count_dt,type_data,data_flg){
str_for_app="";

count_dt=parseInt(count_dt);

rem_data_1=parseInt(data_flg[0])+1;
rem_data_2=parseInt(data_flg[1]);

data_flg=rem_data_1+"-"+rem_data_2;
cnt_loc=count_dt-1;

if(type_data=="text"){


if(rem_data_2==rem_data_1){


str_for_app+="<input class='form-control desgn_ele_sel' type='text' data-next="+data_flg+">";


}else{

str_for_app+=get_init_str(cnt_loc,type_data,data_flg);


str_for_app+="</select>";

rem_data_1+=1;

data_flg=rem_data_1+"-"+rem_data_2;

str_for_app+="<input class='form-control desgn_ele_sel' type='text' data-next="+data_flg+">";
}


}else if(type_data=="int"){


if(rem_data_2==rem_data_1){


str_for_app+="<input class='form-control desgn_ele_sel' type='number' data-next="+data_flg+">";


}else{

str_for_app+=get_init_str(cnt_loc,type_data,data_flg);


str_for_app+="</select>";




rem_data_1+=1;

data_flg=rem_data_1+"-"+rem_data_2;

str_for_app+="<input class='form-control desgn_ele_sel' type='number' data-next="+data_flg+">";

}






}else if(type_data=="date"){


if(rem_data_2==rem_data_1){


str_for_app+="<input class='form-control desgn_ele_sel' type='date' data-next="+data_flg+">";


}else{

str_for_app+=get_init_str(cnt_loc,type_data,data_flg);


str_for_app+="</select>";




rem_data_1+=1;

data_flg=rem_data_1+"-"+rem_data_2;

str_for_app+="<input class='form-control desgn_ele_sel' type='date' data-next="+data_flg+">";




}



}else if(type_data.slice(0,3)=="flg"){






get_flg_str_data(rem_data_2,rem_data_1,cnt_loc,type_data,data_flg,2);





}














return str_for_app;







}





$(document).on("change",".sel_data",function(){


 
var get_val_of_fld=$(this).val().split("^");

var data_flg=$(this).attr("data-next").split("-");
rem_flg_1=parseInt(data_flg[0])+1;
rem_flg_2=parseInt(data_flg[1]);

rem_dt=rem_flg_1+"-"+rem_flg_2;
 $(this).parent().children('select[data-next='+rem_dt+']').remove();

$(this).parent().children('input[data-next='+rem_dt+']').remove();

rem_flg_1+=1;
rem_dt=rem_flg_1+"-"+rem_flg_2;

console.log(rem_dt);
$(this).parent().children('select[data-next='+rem_dt+']').remove();
$(this).parent().children('input[data-next='+rem_dt+']').remove();

str_for_app=append_select_data(get_val_of_fld[1],get_val_of_fld[2],data_flg);


$(str_for_app).insertAfter(this);


});



last_json_obj=[];

function save_data_json_form(){
flg=0;
array_of_loc_data=[];
$('.con_fr_que').map(function() {
    
    rem_data_1=1;
    rem_data_2=3;
    rem_dt=rem_data_1+"-"+rem_data_2;
    
var data1=$(this).children('select[data-next='+rem_dt+']').val();


rem_data_1+=1;
rem_dt=rem_data_1+"-"+rem_data_2;

var data2=$(this).children('select[data-next='+rem_dt+']').val();

rem_data_1+=1;
rem_dt=rem_data_1+"-"+rem_data_2;


var data4=$(this).children('select[data-next='+rem_dt+']').val();


if(data4==null){

var data4=$(this).children('input[data-next='+rem_dt+']').val();
}



if((data1==null) || ( (data2==null)  )){

console.log("rabi");

flg=1;


}else{



array_of_loc_data.push([data1,data2,data4]);

}






});

if(flg==1){

 return 0; 
}


last_json_obj=array_of_loc_data;



}

json_obj={};


$(document).on("click","#save_data",function(){

 if(save_data_json_form()==0){

 }else{

json_obj.data_link=last_json_obj;

send_json=JSON.stringify(json_obj);

 console.log(send_json);

$.ajax({
  type: "POST",
  url: "./ajaxfile/sage_res.php",
  data: {sended_data:send_json}
}).done(function(response1) {

      
console.log(response1);


   
    
   
});
}


});





















crt_data_ver=[];
get_email_api="<?php echo $filename_of_enco;?>";


















function json_req_for_tag(data_json){


$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_json+"&get_stat_act=tag"
        }).done(function(response){ 

init_tbl_data();                
console.log(response);

        });





}





















flg_for_filt=0;

dp_dw_stat="";

tag_get=[];





































ary=[];

























var data = '<?php echo $geted_tag_array; ?>';































deco_data=[];












arr_of_data=[];






















































function sub_stat_enco(sub_flg){

if(sub_flg==1){
                return "subscribe";
        }else if(sub_flg==2){
                return "un-subscribe";
        }else if(sub_flg==3){

                return "none-subscribe";
        }else if(sub_flg==4){
                return "bounced";

	}else if(sub_flg==5){
		return "VIP";
	}



}


function get_tag_html(geted_data){


get_res_tag="";
	
for(k=0;k<geted_data.length;k++){
get_res_tag+="<span class='badge badge-primary' style='margin:3px;'>"+geted_data[k]+"</span>";

}

return get_res_tag;

}






function get_tbl_enbl(geted_data){
str_tbl_enbl="";
        crt_data_ver=JSON.parse(geted_data);
        length_of_array=crt_data_ver.length;


var js_array = [<?php echo '"'.implode('","', $get_col).'"' ?>];

console.log(crt_data_ver);


        for(i=0;i<length_of_array;i++){
        str_tbl_enbl+="<tr><th class='email-con'><div class='row' style='width:280px;'><div><input class='inp-cbx' id='email_stat"+i.toString()+"'   value='true' type='checkbox' style='display: none' /><label class='cbx' for='email_stat"+i.toString()+"'><span class='select_mail_lst' id='"+crt_data_ver[i]["email"]+"^"+i.toString()+"'><svg width='12px' height='10px' viewbox='0 0 12 10'><polyline points='1.5 6 4.5 9 10.5 1'></polyline></svg></span><span> </span></label></div><div class='email-con'>"+crt_data_ver[i]["email"]+"</div></div></th>"
for (j=1;j<js_array.length-3;j++){

	console.log(crt_data_ver[i][js_array[j]]);
str_tbl_enbl+="<td><div class='con-data'>"+crt_data_ver[i][js_array[j]]+"</div></td>";



}
get_res_tag=get_tag_html(crt_data_ver[i][js_array[j]]);


str_tbl_enbl+="<td><div class='con-data' style='min-width:300px;'>"+get_res_tag+"</div></td>";
j+=1;

var get_sub_stat=sub_stat_enco(crt_data_ver[i][js_array[j]]);
str_tbl_enbl+="<td><div class='con-data sub_stat_con'><span class='badge badge-pill badge-success'>"+get_sub_stat+"</span></div></td>";
i
j+=1;
str_tbl_enbl+="<td><div class='con-data'>"+crt_data_ver[i][js_array[j]]+"</div></td>";






str_tbl_enbl+="</tr>";




dp_dw_stat="";

tag_get=[];
arr_of_data=[];


        }
$("#res4").html("klkl");
$(".table-data-con").children("tbody").append(str_tbl_enbl);



}





        </script>

<div id='res4'></div>

 <script src="./../../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="./../../assets/js/argon-dashboard1.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-throttle-debounce/1.1/jquery.ba-throttle-debounce.min.js"></script>
            
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>
  function getdata(path){
      $(".navlinksub").removeClass("active");
      ChangeUrl(path,"?path="+path);
      
      $("#loader").css("display","block");


$(".main-content").load(path+".php", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
      $("#loader").css("display","none");
    if(statusTxt == "error")
      $("#loader").css("display","none");
  });
      
      
      

  }
  function ChangeUrl(title, url) {
    if (typeof (history.pushState) != "undefined") {
        var obj = { Title: title, Url: url };
        history.pushState(obj, obj.Title, obj.Url);
    } else {
        alert("Browser does not support HTML5.");
    }
}
      </script>
  <script>


$(document).on("click",".opt_on_list",function(){
var type_opr=$(this).attr("id");
var define_opt1 = $(this).attr("class");
var define_opt=define_opt1.split(" ");
var final_opr=define_opt[1];  
  
      
      $("#loadsendlink").css("display","inline-block");

    $.ajax({
                url : "./../ajaxfile/crtseslist.php",
                type: "POST",
                data : "requestoflist="+type_opr
        }).done(function(response){ 
$("#res").html(response);
        if(response==1){

window.location = "./../"+final_opr+"/";


      }

        });
  
});



</script>
  
  
</body>

<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>

<?php 
	
	
	}
	}else{
?>
<meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<script src="./../assets/js/plugins/jquery/dist/jquery.min.js"></script>
<link href="./../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />

<style>
.extracardcss{
     margin:auto;
margin-top:18%;
}

</style>
<body style="background:#f8f9fe;">


<div class="extracardcss card" style="width: 18rem;">
  
  <div class="card-body">
    <h5 class="card-title"><div class="navb">heptera|<sub>mail</sub></div></h5>
    <p class="card-text">For verify Your email adress please click on button and please verify your account</p>
    <input type="checkbox" id="terms" required> I accsept terms and condition.<br>
    <button id="sendlink" class="btn btn-warning" style="margin-top:25px" ><i id="loadsendlink" class="fa fa-circle-o-notch fa-spin" style="display:none"></i> send verify link</button>
  </div>
</div>













<script>
$(document).ready(function(){
  $("#sendlink").click(function(){
      var email="<?php echo $mail;?>"
      var id="<?php echo $id;?>"
      $("#loadsendlink").css("display","inline-block");
      
    $.ajax({
		url : "http://dash.heptera.me/ajaxphp/sendlink.php",
		type: "POST",
		data : "email="+email
	}).done(function(response){ //
        $("#loadsendlink").css("display","none");
		$("#sendlink").html(response);
        
	});
  });
});



$(document).on("submit","#click_to_add",function(){


e.preventDefault(); // avoid to execute the actual submit of the form.

    var form = $(this);
    var url = form.attr('action');

    $.ajax({
           type: "POST",
           url: url,
           data: form.serialize(), // serializes the form's elements.
           success: function(data)
           {
               alert(data); // show response from the php script.
           }
         });




});







</script>


<?php

}}else{
    header("location:http://heptera.me/login.php");
}
?>


