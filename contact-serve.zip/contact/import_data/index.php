<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];

require("../confige/fileconfige.php");

require("../confige/con_import.php");

$lst_name=$_SESSION['listname'];


$select_impo_data="select * from data_impo where list_name='".$lst_name."'";

$data_arr=$con_impo_conn->query($select_impo_data);

?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">


<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 

 <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />


 <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">
<style type="text/css">
.not-fd-data{
  text-align: center;
padding: 40px;
    background: white;
    border-radius: 4px;

}




.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

body{
background: #7a71ea0a;
}
.bottom-btn{
  text-align: center;
    height: 40px;
 background: #dea77f47;
    color: #e83105b0;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;

    padding-left: 20px;
    padding-right: 20px;
}
.bottom-btn:hover{
  cursor: pointer;
}

.name_con{
width:70%;
}
.chk_con{
width: 10%;
}
.table th, .table td{
border-top:none;
}

span.badge {
    font-size: 10px;
}







button.btn_hover_clr {
   

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }

a.hr-tag-con {
    color: #4a154b;
    font-size: 15px;
  }

  .main-con {
    padding: 20px 0px 70px 0px;
  }


.cnt-add-email-data{
  text-align: right;
}


</style>


<?php require("../confige/header/header.php");?>

<?php require("../ajaxfile/phpfile/top_of_mngc.php");?>


<div id="main-loader-containre">

<div class="container" style="width:100%;padding-top:120px;">



<div class="main-con">
    
        <div class="">
            <a class="hr-tag-con" href="../../addcontact/"><i class="fal fa-chevron-left" aria-hidden="true" style="
    padding-right: 10px;
"></i>Back To Manage List</a>
        
        </div>
    
    </div>


</div>
<div class="container">
<div class="row" style="padding: 20px 0px;margin:0px;">

<div class="" style="width:50%;font-size: 20px;font-weight: 700;color: #5a2977f2;">
Import History
</div>

<div class="" style="width:50%;text-align:right;">

<button class="btn_hover_clr" data-toggle="modal" onclick="window.location.href='../contact/'" style="float:none;">Import Now<i class="fal fa-file-import" style="
    padding-left: 10px;
" aria-hidden="true"></i></button></div> </div>
</div>
<table class="container table" style="margin-top: 60px;">
  

  <tbody>
<?php

if ($data_arr->num_rows > 0) {

 while($row = $data_arr->fetch_assoc()) {


if($row['impo_count']==0){

$img_data="<img height='40' src='https://image.flaticon.com/icons/png/512/179/179429.png'>";
}else{


$img_data="<img height='40' src='https://image.flaticon.com/icons/png/512/758/758930.png'>";

}


?>
    <tr>

    	<td class="btn_con_tag">

      	<?php echo $img_data;?>


      </td>
      
      <td class="name_con"><span class="badge badge-primary"><?php echo $row['import_src'] ?></span><br><div class="crt_tag_con" style="padding-top:10px;color:black;">Imported
<?php echo $row['dt_ts'] ?></div>
      </td>
      
      <td class='cnt-add-email-data'>

      	<span class="badge badge-pill badge-success">
<?php echo $row['impo_count'];?>
  contact added</span>
      </td>


    </tr>
   
<?php

 }

}else{



?>



<div class="container not-fd-data" style="margin-top:100px;
">

<img src="https://image.flaticon.com/icons/png/512/2879/2879478.png" height="64" style="
">
<div class="txt-not-fd">
You hnot Imported Any Contact.for Start Import contact Click Button.
  </div>

<button class="bottom-btn" data-toggle="modal" onclick="window.location.href='../contact/'" style="float:none;"><i class="fas fa-file-import" style="
    padding-right: 10px;
"></i>Import Now</button>
</div>












<?php

}



?>
 

	 </tbody>
</table>








</div>


























<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>

<script src="../ajaxfile/phpfile/head_mngc.js"></script>





