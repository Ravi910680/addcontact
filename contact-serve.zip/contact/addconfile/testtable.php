  
  <?php
   require("../../../confige/fileconfige.php");
   $filename="5^RAVI";
  $sql = "CREATE TABLE `".$filename."`(
      email VARCHAR(50) NOT NULL,id INT(2)  PRIMARY KEY, 
        fname VARCHAR(30),
        lname VARCHAR(30),
        addr VARCHAR(255),
        phonr bigint(12),
        bday DATE,
        tag INT(5),
        substatus BOOLEAN,source INT(2)

        
        )";

if ($conn3->query($sql) === TRUE) {
    echo "Table employees created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}


    ?>