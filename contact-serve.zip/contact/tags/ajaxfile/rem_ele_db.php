<?php
session_start();
require("../../confige/managetag.php");

$id=$_SESSION['id'];
$id_of_del_tag=$_POST["tag_id"];
$sql = "DELETE FROM tag".$id." WHERE id=".$id_of_del_tag;


if ($mngtag->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}



?>
