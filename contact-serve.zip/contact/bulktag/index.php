<?php
session_start();
$id=$_SESSION["id"];
require("../../../confige/managetag.php");
require("../../../confige/fileconfige.php");

$array_of_tag = array();


$mail=$_SESSION['email'];

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);

$result_flg=$result->num_rows;

while($row = $result->fetch_assoc()) {
        $temp_array["label"]=$row["tag"];
        $temp_array["value"]=$row["id"];

        array_push($array_of_tag,$temp_array);
    }


$geted_tag_array=json_encode($array_of_tag);





?>
<script src="../select_opt/jsfile/bundel.min.js"></script>

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



 <link href="./../../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />

<style type="text/css">






.head-con-rw{
  padding-top: 20px;
  padding-bottom: 20px;
}

.con-of-dash-data{
  width:25%;
  margin: 0px auto;


}
.con-ch-dast-data{
text-align: center;
  border-radius: 5px;
  background:white;
  margin: 20px;

}

.icon-data-con{

  padding-top: 20px;
    padding-bottom: 20px;
}



.ico-fa-data{

  display: table-cell;
  vertical-align: middle;

    font-size: 30px;

    height: 60px;
    width:60px;
}




.con-ico-data{


    width: fit-content;
    margin: 0px auto;
    border-radius: 50%;
    height: 60px;
    width:60px;
}
.data-info-text{
  color: black;
  font-size: 37px;
  font-weight: bolder;
  padding-top: 10px;
    padding-bottom: 10px;
}

.data-head-line{
  padding-top: 10px;
    padding-bottom: 20px;
  color: #04040485;
    font-weight: 600;
}









.main-con {
    padding: 20px 0px 70px 0px;

    }

    a.hr-tag-con {
    color: #4a154b;
    font-size: 15px;

  }


















.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    
    padding-left: 20px;
    padding-right: 20px;
}

.bottom-btn:hover{
  cursor: pointer;
}




body{

}


.select-wrapper {
        margin: auto;
        max-width: 600px;
        width: calc(100% - 40px);
      }

      .select-pure__select {
        align-items: center;
        background: white;
margin: 20px 0px; 
	border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        position: relative;
        transition: 0.2s;
        width: 40%;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 221px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

	align-items: 'center';
        background: #f2f2f2;
	border-radius: 4px;
font-size:13px;
        color:black;
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }



.container.con_main_for_blk_tag {
    
    padding: 50px;
   
    border-radius: 5px;
}




.list-group-item.active{

background-color: #4a154b;


}



.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid #5a2977;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #5a2977 transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}











.file-upload{display:block;text-align:center;font-family: Helvetica, Arial, sans-serif;font-size: 12px;}
.file-upload .file-select{display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select .file-select-button{background:#dce4ec;font-weight:900;font-size:15px;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}
.file-upload .file-select:hover{border-color:#34495e;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select:hover .file-select-button{background:#34495e;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select{border-color:#3fa46a;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload.active .file-select .file-select-button{background:#3fa46a;color:#FFFFFF;transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;}
.file-upload .file-select input[type=file]{z-index:100;cursor:pointer;position:absolute;height:100%;width:100%;top:0;left:0;opacity:0;filter:alpha(opacity=0);}
.file-upload .file-select.file-select-disabled{opacity:0.65;}
.file-upload .file-select.file-select-disabled:hover{cursor:default;display:block;border: 2px solid #dce4ec;color: #34495e;cursor:pointer;height:40px;line-height:40px;margin-top:5px;text-align:left;background:#FFFFFF;overflow:hidden;position:relative;}
.file-upload .file-select.file-select-disabled:hover .file-select-button{background:#dce4ec;color:#666666;padding:0 10px;display:inline-block;height:40px;line-height:40px;}
.file-upload .file-select.file-select-disabled:hover .file-select-name{line-height:40px;display:inline-block;padding:0 10px;}














button.btn_hover_clr {
    margin-top: 0px;
        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }





.main-functional-con {
    width: 50%;
    background: #dea90a1c;
  }



.navbar{
  position: relative !important;
}

.upper-dir{
  position: relative !important;
  top: 0vh !important;
}

.row{
  margin: 0px;
}











button.btn_hover_clr {
   

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }

.btn-con-sub{
  text-align: right;
}


</style>






<?php require("../confige/header/header.php");?>

<?php require("../ajaxfile/phpfile/top_of_mngc.php");?>


<div class="full-cont-of-blck-tag row">


<div class='main-functional-con'>
<div class="container" style="width:100%;">




<div class="main-con">
    
        <div class="" style='padding:50px;'>
            <a class="hr-tag-con" href="../../addcontact/"><i class="fal fa-chevron-left" aria-hidden="true" style="
    padding-right: 10px;
"></i>Back To Manage List</a>

<a class="hr-tag-con" href="../../addcontact/" style="
    float: right;
">Create tag<i class="fal fa-chevron-right" aria-hidden="true" style="
    padding-left: 10px;
"></i></a>
        
        </div>
    
    </div>




</div>


<div class="container con_main_for_blk_tag">

<div class="con-for_sel_file" style="display:block;">
<span class="autocomplete-select"></span>






<form method="POST" action="../tags/bulktag/ajaxfile/act_bulk_tag.php" id="subfileform"  enctype="multipart/form-data">
<div class="ip_fl_con" style="width;100%;">
    <input type="file" name="file" id="chooseFile" required="" style="font-weight:500;">
  </div>

<div class='btn-con-sub'>

<button  type="submit" class="btn_hover_clr" style="">Continue to store</button>

</div>
</form>
</div>
<div class="con_for_stt"  style="display:none;">
<div class="row head-con-rw">


<div class="con-of-dash-data">
  <div class="con-ch-dast-data">

<div class="icon-data-con"> 
  <div class="con-ico-data" style="background: #ff000047;color:red;"><div class="ico-fa-data fas fa-poll-h" aria-hidden="true"></div></div>
</div>
<div class="data-info-text" id="email_lst_cnt">
  

<div class='lds-ring'  style=''><div></div><div></div><div></div><div></div></div>

</div>
<div class="data-head-line">

  Geted Email From File
</div>

  </div>
</div>


<div class="con-of-dash-data">
  <div class="con-ch-dast-data">


<div class="icon-data-con"> 
  <div class="con-ico-data" style="background:#0000ff4a;color: blue;"><div class="ico-fa-data fas fa-sticky-note" aria-hidden="true"></div></div>
</div>
<div class="data-info-text"  id="val_lst_cnt">
<div class='lds-ring'  style=''><div></div><div></div><div></div><div></div></div>
  </div>
<div class="data-head-line">

  Find Valid Email In List
</div>


  </div>
</div>





<div class="con-of-dash-data">
  <div class="con-ch-dast-data">


<div class="icon-data-con"> 
  <div class="con-ico-data" style="background:#00000045;color:black;"><div class="ico-fa-data fas fa-poll-h" aria-hidden="true"></div></div>
</div>
<div class="data-info-text" id="val_email_lst">
<div class='lds-ring'  style=''><div></div><div></div><div></div><div></div></div>
  </div>
<div class="data-head-line">

  Status
</div>

  </div>



</div>


    </div>

</div>




</div>
</div>

 <div class="img-con" style="
    text-align: center;
    width: 50%;
    overflow: scroll;
    height: 86vh;
">
    
    <div class="only-img-con" style="
    height: 43vh;
"><img src="https://res.cloudinary.com/heptera/image/upload/v1601185710/addcontact/friend-request_ejzazg.png" style="
    height: 43vh;
"></div>

<div class="more-opt-for-act" style="
    width: 50%;
    margin: auto;
">

    <ul class="list-group">
  <li class="list-group-item active">Cras justo odio</li>
  <li class="list-group-item">Dapibus ac facilisis in</li>
  <li class="list-group-item">Morbi leo risus</li>
  <li class="list-group-item">Porta ac consectetur ac</li>
  <li class="list-group-item">Vestibulum at eros</li>
</ul>

</div>
    
    </div>
    
    
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
<script type="text/javascript">



var data = '<?php echo $geted_tag_array; ?>';
  







json = JSON.parse(data);     

value2=[];
var autocomplete = new SelectPure(".autocomplete-select", {
        options: json,
        value: [],
        multiple: true,
        autocomplete: true,
        icon: "fa fa-times",
        onChange: value => { value2=[];value2.push(value); },
        classNames: {
          select: "select-pure__select",
          dropdownShown: "select-pure__select--opened",
         multiselect: "select-pure__select--multiple",
          label: "select-pure__label",
          placeholder: "select-pure__placeholder",
          dropdown: "select-pure__options",
          option: "select-pure__option",
          autocompleteInput: "select-pure__autocomplete",
          selectedLabel: "select-pure__selected-label",
          selectedOption: "select-pure__option--selected",
          placeholderHidden: "select-pure__placeholder--hidden",
          optionHidden: "select-pure__option--hidden",
        }
      });


function append_tag(item, index){
	let op = json.filter(e=> e.value == item);


}






$("#subfileform").submit(function(event){
	event.preventDefault(); //prevent default action 
	var post_url = $(this).attr("action"); //get form action url
	var request_method = $(this).attr("method"); //get form GET/POST method
	var form_data = $(this).serialize(); //Encode form elements for submission
	$(".con-for_sel_file").css("display","none");
		$(".con_for_stt").css("display","block");
	$.ajax({
		url:post_url,
   method:"POST",
   data:new FormData(this),
   contentType:false,
   cache:false,
   processData:false,
   beforeSend: function () {
        
      
        },
   
	}).done(function(response){ //

		json_arr=JSON.parse(response);
		console.log(json_arr.length);
$("#email_lst_cnt").html(json_arr.length);
tag_get=JSON.stringify(value2);

$.ajax({
                url : "../tags/bulktag/ajaxfile/get_all_user_tag.php",
                type: "POST",
                data : "mail_list="+response+"&tag_list="+tag_get
        }).done(function(response2){ 


update_tag_into_db(response2);

        });



	});
});






function update_tag_into_db(data_json_tag){

$.ajax({
                url : "../mngc/ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_json_tag+"&get_stat_act="+"tag"
        }).done(function(response){

window.location = "../mngc/#mngc#vc";

	});


}




</script>

