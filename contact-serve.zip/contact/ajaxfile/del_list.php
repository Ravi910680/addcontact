<?php

require("../../../confige/fileconfige.php");

$list_name_act=$_POST['list_old_name'];

$sql_delet_rw = "DELETE FROM filedetails WHERE filename='$list_name_act'";

if ($conn2->query($sql_delet_rw) === TRUE) {
    
$sql_drop_tbl = "DROP TABLE `".$list_name_act."`";

if ($conn3->query($sql_drop_tbl)===TRUE) {


	echo 1;
} else {
	
	echo "Not Able To Delete";
   
}




} else {

	echo "Not Able To Delete";
    
}




















?>
