<?php

session_start();

if(isset($_SESSION['id'])){

$_SESSION['listname']=$_GET['requestoflist'];


header("Location: ".$_GET['red_url']);

}



?>
