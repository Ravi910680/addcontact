<?php
session_start();



function get_email_col($list_id){
require("../confige/fileconfige.php");


	$get_col_query="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='storefile' AND `TABLE_NAME`='".$list_id."'";	

	$query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){
    

	$result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}





       







function get_col_type($list_id,$col_get){
require("../confige/fileconfige.php");

$columnArr=array();

$i=0;


while(count($col_get)>$i){
     



      $get_col_query="SELECT `DATA_TYPE` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE  `TABLE_NAME`='".$list_id."' AND COLUMN_NAME ='".$col_get[$i]."'";
        $query = $conn3->query($get_col_query);
      
while($row = $query->fetch_assoc()){
$data_type=$row['DATA_TYPE'];

  if($data_type=='varchar'){

                $dt_tp='text';
        }else if($data_type=='date'){
                $dt_tp='date';
        }else if ($data_type=='bigint' || $data_type=='int'){
                $dt_tp='int';
        }









array_push($columnArr,$dt_tp);
}

$i+=1;

}


return $columnArr;

}









require("../confige/fileconfige.php");


require("../ajaxfile/phpfile/mysql_to_ip.php");
require("../confige/camp_confige.php");
$lst_name=$_SESSION['listname'];
$get_camp_data="select * from camp_contact_tbl where list_id='$lst_name'";


$id=$_SESSION['id'];


$result = $camp_name_conn->query($get_camp_data);



$cnt_camp=$result->num_rows;



$get_col=get_email_col($_SESSION['listname']);
$lst_name=$_SESSION['listname'];
$get_col=array_slice($get_col,0,count($get_col)-$cnt_camp);

$mail=$_SESSION["email"];



?>




<html>
<head>


<!-- Latest compiled JavaScript -->


<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 


<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">


<style type="text/css">

body{

	
}

.head_add_sub {
   color:#000000e0; 
    padding-bottom: 20px;
    font-size: 20px;
    font-weight: 600;
}




input[type="checkbox"] { display: none; }

input[type="checkbox"] + label {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 20px;
  font: 14px/20px 'Open Sans', Arial, sans-serif;
  color: #ddd;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}

input[type="checkbox"] + label:last-child { margin-bottom: 0; }

input[type="checkbox"] + label:before {
  content: '';
  display: block;
  width: 20px;
  height: 20px;
  border: 1px solid black;
  position: absolute;
  left: 0;
  top: 0;
  opacity: .6;
  -webkit-transition: all .12s, border-color .08s;
  transition: all .12s, border-color .08s;
}

input[type="checkbox"]:checked + label:before {
  width: 10px;
  top: -5px;
  left: 5px;
  border-radius: 0;
  opacity: 1;
  border-top-color: transparent;
  border-left-color: transparent;
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
}

.head-fr-any {
    padding: 20px 0px;
    letter-spacing: -0.02rem;
    color: #000000e0;
}
.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}
.bottom-btn:hover{
	cursor: pointer;
}









button.btn_hover_clr {
    margin-top: 0px;
        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }





.main-functional-con {
    width: 50%;
    background: #f2f2f242;
  }



.navbar{
  position: relative !important;
}

.upper-dir{
  position: relative !important;
  top: 0vh !important;
}

.row{
  margin: 0px;
}




.form_sub_data{
  background: #dea90a1c;
}






button.btn_hover_clr {
   

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }

.btn-con-sub{
  text-align: right;
}



.form_sub_data{
width: 50%;
height: 86vh;
overflow: scroll;
padding: 0px 60px ;
padding-bottom: 100px;
}




.list-group-item.active{

background-color: #4a154b;


}


.form_sub_data::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.form_sub_data {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}




#main-loader-containre-act{


    text-align: center !important;
    
  }

.main-loader-containre-act{
  text-align: center !important;padding-top: 41vh;height: 84vh;
}



.ip-by-def-dsg{
  max-width: 100% !important;
}
</style>
</head>
<body>
<?php require("../confige/header/header.php");?>



<?php require("../ajaxfile/phpfile/top_of_mngc.php");?>


<div class="full-cont-of-blck-tag row" id='main-loader-containre'>


<div class='form_sub_data container' style=''>

<h1 class="head-fr-any">Add Subscriber</h1>

<form id='frm_data' action='./ajaxfile/add_sub_ent.php' >



<div class='head_add_sub'>Table Field</div>








<?php


for($i=0;$i<count($get_col)-11;$i++){

$get_col_query="SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '".$lst_name."' AND COLUMN_NAME = '".$get_col[$i]."'";
$query = $conn3->query($get_col_query);


       $dt_of_colm=$query->fetch_assoc();

if($i!=0){
$org_ip_dt=get_mysql_to_ip($dt_of_colm['DATA_TYPE']);
}else{
$org_ip_dt='email';
}

echo "<div class='form-group ' style='padding:0px;'><label for='inputPassword4'>".$get_col[$i]."</label><input type='".$org_ip_dt."' name='".$get_col[$i]."' class='form-control ip-by-def-dsg'  placeholder='".$get_col[$i]."'></div>";




}





?>




<input type="checkbox" id="box-3" style="margin:10px;">
<label for="box-3" style="color:black;margin:10px;width:60%">This Person Give Permission To Use This Email For There convinency and admin Use This mail For Good Purpose.</label>

<input type="checkbox" id="box-4" style="margin:10px;">
<label for="box-4" style="color:black;margin:10px;width:60%">Select this option for  contact details if new contact found in this list automatically update.</label>
  <button type="submit" class="btn_hover_clr" id='click_to_add'  style='float:right;'>Click To Add<i class="fal fa-long-arrow-alt-right" style='padding-left:10px;'></i></button>
</form>



</div>







<div class="img-con" style="
    text-align: center;
    width: 50%;
    overflow: scroll;
    height: 86vh;
">
    
    <div class="only-img-con" style="
    height: 43vh;
"><img src="https://res.cloudinary.com/heptera/image/upload/v1601185279/addcontact/project-manager_gatxbx.png" style="
    height: 43vh;
"></div>

<div class="more-opt-for-act" style="
    width: 50%;
    margin: auto;
">

    <ul class="list-group">
  <li class="list-group-item active">Way TO Add Subscriber</li>
  <li class="list-group-item">From CLoud Files</li>
  <li class="list-group-item">From Local File</li>
  <li class="list-group-item">Manually Added</li>
  <li class="list-group-item">Landing Page & Survey</li>
</ul>

</div>
    
    </div>

  </div>






</body>


<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>


<script>


$("#frm_data").submit(function(e) {

    e.preventDefault(); // avoid to execute the actual submit of the form.

    var form = $(this);
    var url = form.attr('action');

    $.ajax({
           type: "POST",
           url: url,
           data: form.serialize(), // serializes the form's elements.
           success: function(data)
           {
               

window.location ='./../select_opt/';

           }
         });


});


</script>


</html>

