<?php


require("../../confige/managetag.php");
$array_of_tag = array();

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);


while($row = $result->fetch_assoc()) {
        $temp_array["label"]=$row["tag"];
        $temp_array["value"]=$row["tag"];
        
        array_push($array_of_tag,$temp_array);
    }


$geted_tag_array=json_encode($array_of_tag);






?>
