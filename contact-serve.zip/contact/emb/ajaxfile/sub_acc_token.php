<?php

session_start();


 $mail=$_SESSION["email"];
    $id=$_SESSION["id"];
if(isset($_SESSION["email"])){
require("../../confige/userconnect.php");



$token_acc=$_POST['access_tok'];
$acc_type=$_POST['access_tp'];

$sql = "UPDATE userinfo SET ".$acc_type."='".$token_acc."' where id='".$id."'";


$result=$conn->query($sql);

print_r($result);


}






?>
