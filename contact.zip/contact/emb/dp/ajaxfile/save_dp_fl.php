<?php

header('Access-Control-Allow-Origin: *');



function dbx_get_file($token, $in_filepath, $out_filepath)
    {
    $out_fp = fopen($out_filepath, 'w+');
    if ($out_fp === FALSE)
        {
        echo "fopen error; can't open $out_filepath\n";
        return (NULL);
        }

    $url = 'https://content.dropboxapi.com/2/files/download';

    $header_array = array(
        'Authorization: Bearer ' . $token,
        'Content-Type:',
        'Dropbox-API-Arg: {"path":"' . $in_filepath . '"}'
    );

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header_array);
    curl_setopt($ch, CURLOPT_FILE, $out_fp);

    $metadata = null;
    curl_setopt($ch, CURLOPT_HEADERFUNCTION, function ($ch, $header) use (&$metadata)
        {
        $prefix = 'dropbox-api-result:';
        if (strtolower(substr($header, 0, strlen($prefix))) === $prefix)
            {
		    $metadata = json_decode(substr($header, strlen($prefix)), true);
		   $metadata['flg']=1; 
            }
        return strlen($header);
        }
    );

    $output = curl_exec($ch);

    if ($output === FALSE)
        {
        echo "curl error: " . curl_error($ch);
        }

    curl_close($ch);
    fclose($out_fp);

    return($metadata);
    } // dbx_get_file()









$fl_path=$_POST['fl_path'];
$fl_name=$_POST['fl_name'];
$acc_tok=$_POST['acc_tok'];




session_start();









$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";


$dbname = "imagedir";

$imagedir = mysqli_connect($servername, $username, $password,$dbname);



$dbname = "imagesave";

$imagesave = mysqli_connect($servername, $username, $password,$dbname);








$id='16';


    $dir_name= $id."^Y2xvdWRfY29kZQ==";



$image_dir_select="SELECT * FROM imagedirname WHERE dir='$dir_name'";

$result = $imagedir->query($image_dir_select);
$row = $result->fetch_assoc();

$count_saved=$row['count'];
$all_count=$row["allcount"];
$targetFilePath="images/";
$path_parts = pathinfo($fl_path);

$file_ext=$path_parts['extension'];
$image_db_name=$dir_name."^".$all_count.".".$file_ext;










$metadata = dbx_get_file($acc_tok, $fl_path, $targetFilePath.$image_db_name);



if($metadata['flg']==1){

$image_info = getimagesize($targetFilePath.$image_db_name);
$width=$image_info[0];
$height=$image_info[1];
                $insert_img_data = "INSERT INTO `".$dir_name."`  VALUES ('$image_db_name', '$width', '$height','jk','$fl_name')";
                if($imagesave->query($insert_img_data)==TRUE){

$all_count=$all_count+1;
$count_saved=$count_saved+1;

echo 1;
                }

}


             

$count_update = "UPDATE imagedirname SET count='$count_saved',allcount='$all_count' WHERE dir='$dir_name'";

if($imagedir->query($count_update)=='true'){
	$flg_for_res=1;
}







echo $flg_for_res;



?>
