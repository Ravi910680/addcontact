


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<style type="text/css">

.con-fb-connect {
    padding-top: 10%;
    height: 100vh;
    overflow: scroll;
}
.card-img-top{

  margin: auto;
  height: 64px;
  width: 64px;
}


.card{
padding-top: 20px;
    padding-bottom: 20px;

  }
  img.list-img-right {
    height: 36px;
    padding-right: 30px;
  }





.bottom-btn{
  text-align: center;
    height: 40px;
    background: #4a154bd9;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border:1px solid  #4a154bd9;
   width:100%;
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
  cursor: pointer;
}


</style>
<script type="text/javascript">





</script>

<div class='con-fb-connect'>

<div class="card" style="width: 30rem;margin:auto;">
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1592640972/iconfinder_38_939833_jgcojl.png"  alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Connect DropBox Account</h5>
    <p class="card-text">DropBox connect Use for get file from dropbox easily.</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Get All file List on heptera</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Select file option that use</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Add Contact Directly From File</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Add Image In heptera</li>
  </ul>
  <div class="card-body">
  <fb:login-button  onlogin='checkLoginState();'>Connect Instagram</fb:login-button> </div></div>

</div>

<a href="#" onclick="fb_login();"><img src="images/fb_login_awesome.jpg" border="0" alt="">connect</a>
<div id="fb-root"></div>
<script>

  window.fbAsyncInit = function() {
    FB.init({
        appId   : '531342854255918',
        oauth   : true,
        status  : true, // check login status
        cookie  : true, // enable cookies to allow the server to access the session
        xfbml   : true // parse XFBML
    });

  };




  function fb_login(){
    FB.login(function(response) {

        if (response.authResponse) {
            console.log('Welcome!  Fetching your information.... ');
            //console.log(response); // dump complete info
            access_token = response.authResponse.accessToken; //get access token
            user_id = response.authResponse.userID; //get FB UID

            FB.api('/me', function(response) {
                user_email = response.email; //get user email
          // you can store this data into your database
            });

        } else {
            //user hit cancel button
            console.log('User cancelled login or did not fully authorize.');

        }
    }, {
        scope: 'id,email'
    });
}



 

(function(d, s, id) {                      // Load the SDK asynchronously
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));



 </script>





