<?php
$servername = "database-1.ckv23lvefwmm.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="list_details";

$seg_conn = mysqli_connect($servername, $username, $password,$db);



?>

