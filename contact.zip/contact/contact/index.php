



<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];


	 $filename=explode("^",$_SESSION['listname']);
         $name_of_file=base64_decode($filename[1]);




?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
  
  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">

<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(http://fonts.googleapis.com/css?family=Varela+Round);
.hover-bottom:hover{
    border-bottom:1px solid white;

}
.card-hover:hover{
    background:#f2f2f2;
  cursor: pointer;
}
.fa-add{
    padding:20px;
        font-size: 100px;
    margin: 0 auto;
}
.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;

}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: 0 auto;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  
  <!-- Icons -->
  

 
 
  <!-- CSS Files -->
  <script>
  

  </script>

</head>
<div id="c"></div>
<body class="" style="background:#fff;">
  <div style="height:93vh">
  


<?php require("../confige/header/header.php");?>




<style>
.text_list:hover{
cursor:pointer;
}



.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}



.bottom-btn:hover{
	cursor: pointer;
}




</style>

<nav class="navbar navbar-dark" style="color:#4a154bd9;white;height:7vh;padding:10px;top:8vh;background:white;border-bottom: 1px solid #ebeaeb;">
<div style="width:100%"><span style="float-left"><a class=" hover-bottom" href="/main/addcontact/" style="color:#4a154bd9;font-weight:600;">Return to dashboard</a></span>
<div class="float-right" onclick="getdata(click_Select_con)" style="height:100%;float:right;"><span class='text_list' style='font-weight:600;'>Add Contact In <?php echo $name_of_file;?></span></div></div>

</nav>


<div class="main-content" style="top:15vh;">

<div class="main-con-content container" style="">
<div class="row" style="padding:40px;">

<div class="card-hover card" onclick="window.location.href='../addconfile/';" id="addconfile" style="width: 18rem;">
 
<i class="fa-add fad fa-file-import" style="color:black;"></i> <div class="card-body">
    <h5 class="card-title">Import From File</h5>
    <p class="card-text">If you have .csv and .xls file and wish to add this contact select this Option.</p>
    
  </div>
</div>
<div class="card-hover card" onclick="window.location.href='../addconcopy/';" id="addconcopy" style="width: 18rem;margin:0 auto;">
  
 <i class="fa-add fad fa-copy" style="color:black;"></i> 
  <div class="card-body">
    <h5 class="card-title">Copy Data From file</h5>
    <p class="card-text">Copy .xls file content and paste in next input field automatically select email.</p>
    
  </div>
</div>

<div class="card-hover card" onclick="window.location.href='../emb/';"  id="addconemb" style="width: 18rem;">
   
<i class="fa-add fad fa-draw-circle" style="color:black;"></i>

 <div class="card-body">
    <h5 class="card-title">Connect ambaded System</h5>
    <p class="card-text">If you wish to connect your Google contact, google drive and other embeded System.</p>
  
  </div>
</div>
</div>
</div>
</div>

</div>
<nav class="navbar navbar-dark" style="background:white;height:7vh;border-top: 1px solid #c3c0c3;padding:10px;">
<div style="width:100%">
<div class="float-right click-on-opt"  style="height:100%;float:right;">

<button class="bottom-btn" style="Background:none;color:#4a154bd9" onclick="window.location.href='../../addcontact/';" >Not Yet</button></div>
</div>

</nav>

</body>
<div class="res">
</div>



  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>


  </script>
  <script>
  function getdata(path){
      
      ChangeUrl(path,"?path="+path);
      
      $(".con-hover").css("display","block");

$(".submit-form-contact").attr("id",path);
$(".main-content").load(path+".php", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success"){
      $(".con-hover").css("display","none");
      $(".click-on-opt").css("display","block");
$(".submit-form-contact").click(function(){

submitcon(path);


});

    }
    if(statusTxt == "error"){
      $(".con-hover").css("display","none");}
  });
      
      
      

  }
  function ChangeUrl(title, url) {
    if (typeof (history.pushState) != "undefined") {
        var obj = { Title: title, Url: url };
        history.pushState(obj, obj.Title, obj.Url);
    } else {
        alert("Browser does not support HTML5.");
    }
}
      </script>
  <script>


$("#subfileform").submit(function(event){
	event.preventDefault(); //prevent default action 
	var post_url = $(this).attr("action"); //get form action url
	var request_method = $(this).attr("method"); //get form GET/POST method
	var form_data = $(this).serialize(); //Encode form elements for submission
	
	$.ajax({
		url:post_url,
   method:"POST",
   data:new FormData(this),
   contentType:false,
   cache:false,
   processData:false,
   beforeSend: function () {
         $("#loadsendlink").css("display","inline-block");
      
        },
   
	}).done(function(response){ //
    if(response==1){
$("#normalres").html("<div class='card bg-warning text-white'><div class='card-body'>not able to create table</div></div>");
 $("#loadsendlink").css("display","none");
    }else if(response==2){
$("#normalres").html("<div class='card bg-warning text-white'><div class='card-body'>not enter same data sheet name</div></div>");
 $("#loadsendlink").css("display","none");
    }else if(response==3){
$("#normalres").html("<div class='card bg-warning text-white'><div class='card-body'>please select valid csv</div></div>");
 $("#loadsendlink").css("display","none");
    }else{
    $("#loadsendlink").css("display","none");
    location.reload();
        $(".modal-body").html(response);
    }
	});
});






</script>
  
  


<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>

