<?php
session_start();
require("../confige/fileconfige.php");
$newlistname=$_POST['nameofnewlist'];

$id=$_SESSION["id"];


if(isset($newlistname)){
	



      $filename=$id."^".base64_encode($newlistname);
      
       $tblsql = "CREATE TABLE `".$filename."`(
      email VARCHAR(50) NOT NULL,
        firstname VARCHAR(30) DEFAULT '',
        lastname VARCHAR(30) DEFAULT '',
        address VARCHAR(255) DEFAULT '',
        phone bigint(12) DEFAULT '0',
        birthdate DATE DEFAULT '0000-00-00',
        tag VARCHAR(255) DEFAULT '',
        substatus INT(2) DEFAULT '0',
        source VARCHAR(255),
        segment varchar(255) DEFAULT '',
        arch int(1),
        crt_date date,
        chg_date date,
        con_id int(10) AUTO_INCREMENT PRIMARY KEY,
        gender_pre varchar(2),
        age_pre varchar(2),
        usr_star int(2),
        Unique KEY (email)
        
        )";




if ($conn3->query($tblsql) === TRUE) {
	



      
      $insertfilename = "INSERT INTO filedetails (id, filename, extra) VALUES ('$id', '$filename', '0')";
if($conn2->query($insertfilename)==TRUE){



echo 1;
$_SESSION['listname']=$filename;
}


}else{
	

echo "Contact List Already Created";

}
}else{


echo "Please Enter Valid Name";

}

?>
