<?php


session_start();

if(isset($_SESSION['id'])){

$_SESSION['listname']=$_GET['requestoflist'];

echo 1;

}


$url_red=$_GET['red_data'];


header("location: ".$url_red);
?>