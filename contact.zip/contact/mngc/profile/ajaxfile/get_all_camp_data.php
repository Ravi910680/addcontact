<?php
session_start();

require("../../../confige/camp_confige.php");



$lst_name=$_SESSION['listname'];



function get_camp_ana_data($tbl_name,$id){

	require("../../../confige/email_camp_ana.php");

$data_of_camp=array();

$sql_query="select * from `$tbl_name` where id='$id' ORDER BY act_date DESC";

$result = $camp_ana_conn->query($sql_query);


while($row = $result->fetch_assoc()) {
    

array_push($data_of_camp, $row);

  }

return $data_of_camp;


}



function get_camp_sub_ln($conn,$camp_con_id){


$sel_sub="select * from camp_content_tbl where camp_id='$camp_con_id'";

$result = $conn->query($sel_sub);

$row = $result->fetch_assoc();

return $row['sub_fld'];

}



function get_all_camp_from_db($conn,$id,$lst_id){

$ret_arr=array();


$pro_id=$_SESSION['pro_id'];


$sel_query="select * from camp_name_tbl where id='$id' ORDER BY camp_shed_time DESC";


$result=$conn->query($sel_query);


$ret_data=array();

$i=0;

if ($result->num_rows > 0) {
  // output data of each row


  while($row = $result->fetch_assoc()) {




$db_name=$row['camp_contact_id']."#".$lst_id;


$sub_ln_camp=get_camp_sub_ln($conn,$row['camp_contact_id']);


  	$arr_camp_ana=get_camp_ana_data($db_name,$pro_id);

  	$ret_data['data'][$i]=$row;

    $ret_data['data'][$i]['subject']=$sub_ln_camp;


  	if(count($arr_camp_ana)>0){
array_unshift($arr_camp_ana, array('act'=>'1','act_date'=>$row['camp_shed_time']));
    $ret_data['data'][$i]['activity']=$arr_camp_ana;

}

    $i+=1;
  }
} 

$ret_data['camp_num']=$i;


return $ret_data;


}



$id=$_SESSION['id'];

print_r(json_encode(get_all_camp_from_db($camp_name_conn,$id,$lst_name)));



?>
