



<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];

    $lst_name=$_SESSION['listname'];

require("../../confige/userconnect.php");
require("../../confige/fileconfige.php");
require("../../confige/managetag.php");
require("../../confige/camp_confige.php");







?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">


<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">

 <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />


 <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">
<style>
.not-fd-data{
  text-align: center;
padding: 40px;
    background: white;
    border-radius: 4px;

}




.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}




.cbx {
  margin: auto;
  -webkit-user-select: none;
  user-select: none;
  cursor: pointer;
}
.cbx span {
  display: inline-block;
  vertical-align: middle;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child {
  position: relative;
  width: 18px;
  height: 18px;
  border-radius: 3px;
  transform: scale(1);
  vertical-align: middle;
  border: 1px solid #9098A9;
  transition: all 0.2s ease;
}
.cbx span:first-child svg {
  position: absolute;
  top: 3px;
  left: 2px;
  fill: none;
  stroke: #FFFFFF;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 16px;
  stroke-dashoffset: 16px;
  transition: all 0.3s ease;
  transition-delay: 0.1s;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child:before {
  content: "";
  width: 100%;
  height: 100%;
  background: #506EEC;
  display: block;
  transform: scale(0);
  opacity: 1;
  border-radius: 50%;
}
.cbx span:last-child {
  padding-left: 8px;
}
.cbx:hover span:first-child {
  border-color: #506EEC;
}

.inp-cbx:checked + .cbx span:first-child {
  background: #506EEC;
  border-color: #506EEC;
  animation: wave 0.4s ease;
}
.inp-cbx:checked + .cbx span:first-child svg {
  stroke-dashoffset: 0;
}
.inp-cbx:checked + .cbx span:first-child:before {
  transform: scale(3.5);
  opacity: 0;
  transition: all 0.6s ease;
}

@keyframes wave {
  50% {
    transform: scale(0.9);
  }
}



















@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(https://fonts.googleapis.com/css?family=Dosis);
.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
.upper-dir{



}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


















.select-wrapper {
        margin: auto;
        max-width: 600px;
        width: calc(100% - 40px);
      }

      .select-pure__select {
        align-items: center;
        background: white;
margin:10px;      
  border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        position: absolute;
        transition: 0.2s;
        width: 300px;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 220px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

  align-items: 'center';
       
  border-radius: 4px;
font-size:13px;
        color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }
























.con-of-data {
 max-width:80%;
  max-height: 20em;
  overflow: scroll;
  position: relative;
}

table {
    
  position: relative;
  border-collapse: collapse;
}
tr{
    outline: 1px solid rgb(222, 221, 220);
}
td,
th {
  padding: 0.25em;
}

thead th {
    
    
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  top: 0;
background: #ededf5ed;
    color: #090942;
 

 z-index: 1000;
}

thead th:first-child {
outline: 1px solid rgb(222, 221, 220); 
  left: 0;
  z-index: 1000000000;
}

tbody th {
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  left: 0;
  background: #FFF;
  
}
tbody tr th{
  outline:  1px solid rgb(222, 221, 220); 
    z-index: 1000;
    background: white;
}
.con-data{
min-width: 150px;
max-width: 200px;
overflow: scroll;
padding: 12px 24px;
height:49px;
}
th .email-con{


color:black;


}
.email-con{
overflow-x:scroll;
    width:200px;
 padding-left: 20px;
    margin-right: 20px;   
  
}
.email-con::-webkit-scrollbar {
  display: none;
}
.con-of-data{
margin:0px auto;

margin-bottom:60px;
  color: #090942; 
    outline: 1px solid rgb(222, 221, 220); 

font-size:15px;
}

th.email-con:hover {
    cursor: pointer;
}


.con-data::-webkit-scrollbar {
  display: none;
}



.row.con_of_opt {



transition: all 0.5s ease 0s;

    background: #5a297708;
    margin: 60px auto 0px auto;
    max-width: 80%;
    max-height: 20em;
    position: relative;
    font-weight: 900;
    color: #5a2977;
}
.bottom-btn {
    text-align: center;
    height: 40px;
    background: #5a297747;
    color: #5a2977;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    padding-left: 20px;
    padding-right: 20px;
}

.main_con_opt{
padding:20px;
}






.dropdown-menu{
    border-radius:0px;
    box-shadow:none;
    
    border:1px solid #dedddc;
overflow-y:scroll;   
}
.below-tit{
font-weight: 400;
    font-size: 18px;
    padding-top: 20px;
    color: #000000c7;
    font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    letter-spacing: 1px;
}
.color-fet{
padding-left:10px;
padding-right:10px;
font-weight:600;
}

.main-con-of-pro-dt {
    height: 80vh;
    margin: 0px 10vh;
    width: 100%;
  }

  .con-of-pro-txt-dt {
    
    width: 60%;
    display: inline-block;
    position: relative;
    float: left;

  }

  .con-of-ana-data {
    height: 80vh;
    width: 39%;
    display: inline-block;
    position: relative;
    float: left;

  }






























.steps {
  
  box-shadow: 0px 10px 15px -5px rgba(0, 0, 0, 0.3);
  background-color: #FFF;
  padding: 24px 0;
  position: relative;
  margin: auto;
  border-radius: 10px;
}

.steps::before {
  content: '';
  position: absolute;
  top: 0;
  height: 24px;
  width: 1px;
  
  left: calc(50px / 2);
  z-index: 1;
}

.steps::after {
  content: '';
  position: absolute;
  height: 13px;
  width: 13px;
  background-color: var(--primary-color);
  box-shadow: 0px 0px 5px 0px var(--primary-color);
  border-radius: 15px;
  left: calc(50px / 2);
  bottom: 24px;
  transform: translateX(-45%);
  z-index: 2;
}

.step {
    padding: 10px 20px 10px 50px;
    position: relative;
    transition: all 0.4s ease-in-out;
    background-color: #FFF;

  }
.step-open::before {
    content: '';
    position: absolute;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    left: calc(50px / 2);
    transform: translateX(-45%);
    z-index: 2;
    background: #9bd4bd;
    margin-top: 20px;
    border: 5px solid white;
  }
  

.step::after {
    content: '';
    position: absolute;
    height: 100%;
    width: 1px;
    background-color: #00008b3b;
    left: calc(50px / 2);
    top: 0;
    z-index: 1;

  }

.step.minimized {
  background-color: #FFF;
  transition: background-color 0.3s ease-in-out;
  cursor: pointer;
}

.header {
    user-select: none;
    font-size: 14px;
    color: rgba(0, 0, 0, 0.6);
    font-weight: 500;

  }
.subheader {
    user-select: none;
    font-size: 12px;
    color: rgba(0, 0, 0, 0.4);
    font-weight: 400;
  }

.step-content {
  transition: all 0.3s ease-in-out;
  overflow: hidden;
  position: relative;
}

.step.minimized > .step-content {
  height: 0px;
}

.step-content.one {
  height: 460px;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.05);
  border-radius: 4px;
  margin-top: 10px;
}

.step-content.two {
  height: 600px;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.05);
  border-radius: 4px;
  margin-top: 10px;
}

.step-content.three {
  height: 400px;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.05);
  border-radius: 4px;
  margin-top: 10px;
}

.next-btn {
  position: absolute;
  top: 50%;
  left: 50%;
  border: 0;
  padding: 10px 20px;
  border-radius: 4px;
  background-color: red;
  box-shadow: 0 5px 10px -3px rgba(0, 0, 0, 0.3);
  color: #FFF;
  transition: background-color 0.3s ease-in-out;
  cursor: pointer;
  transform: translate(-50%, -50%);
}

.close-btn {
  position: absolute;
  top: 50%;
  left: 50%;
  border: 0;
  padding: 10px 20px;
  border-radius: 4px;
  background-color: rgb(255, 0, 255);
  box-shadow: 0 5px 10px -3px rgba(0, 0, 0, 0.3);
  color: #FFF;
  transition: background-color 0.3s ease-in-out;
  cursor: pointer;
  transform: translate(-50%, -50%);
}

/* Irrelevant styling things */
.close-btn:hover {
  background-color: rgba(255, 0, 255, 0.6);
}

.close-btn:focus {
  outline: 0;
}

.next-btn:hover {
  background-color: rgba(255, 0, 0, 0.6);
}

.next-btn:focus {
  outline: 0;
}

.step.minimized:hover {
  background-color: rgba(0, 0, 0, 0.06);
}


.ico-that-act-pro {
    width: 20%;
    display: inline-block;
    color: #e01a4f;
  }

  .step-header {
    display: flex;
    margin-top: 25px;
    width: 100%;
  }


.ico-of-email-dt {
    height: 100px;
    width: 100px;
    border-radius: 50%;
    background: #dcd6d1;
    text-align: center;
    font-size: 50px;
    padding: 12px;
    color: #9e9c9b;
    margin-bottom: 20px;
  }


.txt-of-full-email {
    font-size: 20px;
    
    color: #453e39;
  }

  span.dt-con-of-hy {
    color: #9e9c9b;
    font-size: 13px;
  }


.status_span{
  display: inline-block;
    border-radius: 3px;
    padding: 5px 12px;
    font: 700 13px Lato,Arial,sans-serif;
    cursor: default;
}

.subscribe{
  background-color: #cbd598;
    color: #fff;
}


.card-init-count {
    width: 33%;
    display: inline-block !important;
    padding: 10px;
    text-align: center;

  }

  .coun_con {
    font-size: 24px;
    color: black;
    font-weight: 500;

  }

  .count_type {
    font-size: 13px;
    color: #241c15;
    padding: 10px 0px;

  }


.dt-fld-for-pro {
    width: 100%;
    padding-top: 50px;

  }

  tr {
    border-top: 1px solid #f1efed;
    outline: none;
  }

  td, th {
    padding: 0.25em;
    padding: 16px;
  }

  td.fld-name {
    color: #9e9c9b;
    font: 16px Lato,Arial,sans-serif;
    }
    td.fld-val {
    font: 16px Lato,Arial,sans-serif;
  }


  button.btn-of-edt-con {
    margin-right: 20px;
    background: no-repeat;
    border: none;

  }


.edt_save_btn{


  background: #4a154b !important;
    border-radius: 10px;
    padding: 5px 10px;
    color: white;
    font-size: 13px;
    font-weight: 700;
}


.header {
    width: 30%;
    user-select: none;
    font-size: 14px;
    color: rgb(0 0 0 / 89%);
    font-weight: 500;

    }

    .act-of-camp {
    width: 20%;
    user-select: none;
    font-size: 14px;
    color: rgba(0, 0, 0, 0.6);
    font-weight: 500;

  }

  .sub_of_camp {
    width: 40%;
    user-select: none;
    font-size: 14px;
    color: #4d7b69;
    font-weight: 500;

  }
</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->

</head>
<div id="c"></div>
<body class="" style="background:#fff">



<?php require("../../confige/header/header.php");?>

<?php require("../../ajaxfile/phpfile/top_of_mngc.php");?>



<div id='main-loader-containre' class="main-con-of-pro-data" style="
    width: 100%;
    padding-top: 20vh;
    display:flex;
">

    <div class="main-con-of-pro-dt">






<div class="container row marg-bot" style="margin:auto;margin-bottom:20px;padding: 0px;">

  <div class="container" style="width:100%;border: 1px solid;border-radius: 10px;">
    <div class="card-init-count" style="
    border-right: 1px solid;
">

    <div class="coun_con" id="tot_count_res">1</div>
    <div class="count_type">Total Response</div></div>


    <div class="card-init-count" style="
">

    <div class="coun_con" id="opn_count_res">0</div>
    <div class="count_type">Open Response</div></div>
    <div class="card-init-count" style="border-left: 1px solid;">

    <div class="coun_con" id="clck_count_res">1</div>
    <div class="count_type">Click Response</div></div>
    

    
    
</div>
</div>



















    
        <div class="con-of-pro-txt-dt">
        
<div class='fl-of-eml-and-lg'>

        <div class="ico-of-email-dt">

    R

</div>

<div class="txt-of-full-email">ravigorasiya65@gmail.com
<br>
    
    <span class="dt-con-of-hy">Added 20 minute Ago by API</span><br>

    <span class="status_span subscribe" style="
    background-color: #cbd598;
    color: #fff;
">Subscribe</span>

</div>
        </div>
        






<div class='dt-fld-for-pro'>

<h2 style="
    margin-bottom: 30px;
    color: #4a154b;
    font: 700 20px Lato,Arial,sans-serif;
    margin-left: 16px;
">Field Setting</h2>



<div class="ico-hod-edt-dlt" style="
    text-align: right;
    padding: 10px;
    width:80%;
">

<button class="btn-of-edt-con edt_btn_of_dt">

<img src='https://res.cloudinary.com/heptera/image/upload/v1606540655/addcontact/up-svg_y9jyxg.svg'>

</button><button class="btn-of-edt-con">

<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-trash" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
</svg>
</button>

</div>

<table style="width: 80%;">
  
  <tbody id='tb_bd_of_email_pro'>
    
  
</tbody></table>


</div>








        </div>
    
       <div class="con-of-ana-data">
        
    
    
    <div class="rnd-of-camp-ln">




      <div class="steps" id='all_camp_act_by_id'>
  <div class="step step-open">
    <div class="step-header">
      <div class="header" style="
">1 hour ago</div><div class="act-of-camp">Opened</div><div class="sub_of_camp">New Outlets is open in your area</div>
      
    </div>


    
  </div>
  
  
</div>


        
    </div>
    
    
    </div>
    
    
    
        
        
    
    
    </div>
    
    


</div>


































<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>

 <script src="../../select_opt/jsfile/bundel.min.js"></script>


<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-throttle-debounce/1.1/jquery.ba-throttle-debounce.min.js"></script>
            
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
 
  
  
</body>


<script type="text/javascript">


data_of_pro="";
data_of_camp="";


all_open_camp_cnt=0;
all_clk_camp_cnt=0;


$(document).ready(function(){


init_data_of_pro();

})



function init_data_of_pro() {
  
$.ajax({
                url : "./ajaxfile/select_contact_pro.php",
                type: "GET",
                data : "filt_tag=mk"
        }).done(function(response){ 

data_of_pro=response;


get_all_camp_data();




});





}


function get_all_camp_data(){


$.ajax({
                url : "./ajaxfile/get_all_camp_data.php",
                type: "GET",
                data : "filt_tag=mk"
        }).done(function(response){ 


data_of_camp=response;







str_init_tbl();


str_init_activity_data();

});



}











timeAgo = (date) => {
            var ms = (new Date()).getTime() - date.getTime();
            var seconds = Math.floor(ms / 1000);
            var minutes = Math.floor(seconds / 60);
        var hours = Math.floor(minutes / 60);
        var days = Math.floor(hours / 24);
        var months = Math.floor(days / 30);
        var years = Math.floor(months / 12);
    
        if (ms === 0) {
            return 'Just now';
        } if (seconds < 60) {
            return seconds + ' seconds Ago';
        } if (minutes < 60) {
            return minutes + ' minutes Ago';
        } if (hours < 24) {
            return hours + ' hours Ago';
        } if (days < 30) {
            return days + ' days Ago';
        } if (months < 12) {
            return months + ' months Ago';
        } else {
            return years + ' years Ago';
        }
    
    }







function str_of_app_act(dt_tm,act,sub){




str_of_app='<div class="step step-open"> <div class="step-header"> <div class="header" style=" ">'+dt_tm+'</div><div class="act-of-camp">'+act+'</div><div class="sub_of_camp">'+sub+'</div> </div> </div>';



return str_of_app;
}



function get_act_of_camp(act_id){


if(act_id>2){


all_clk_camp_cnt+=1;
 return "Click"


}else if(act_id>1){

  all_open_camp_cnt+=1;

  return "Opened";
}else if(act_id>0){
 
 return "Sended";
}


}



function str_init_activity_data(){


data_for_get=JSON.parse(data_of_camp)['data'];

console.log(data_for_get);

str_of_get_camp_act="";

for (var i = 0; i < data_for_get.length; i++) {
  

sub_ln=data_for_get[i]['subject'];

for (var j = 0; j < data_for_get[i]['activity'].length; j++) {



  console.log(data_for_get[i]['activity'][j]);


tm_dt_frm_db=timeAgo(new Date(data_for_get[i]['activity'][j]['act_date']));


act=get_act_of_camp(data_for_get[i]['activity'][j]['act']);

str_of_get_camp_act=str_of_app_act(tm_dt_frm_db,act,sub_ln)+str_of_get_camp_act;


  
};


};

$("#all_camp_act_by_id").html(str_of_get_camp_act);


}



function str_init_tbl(){




len_of_camp_arr=JSON.parse(data_of_camp)['camp_num'];

jsn_dec_data=JSON.parse(data_of_pro);




i=0;

console.log(jsn_dec_data);

len_of_arr=Object.keys(jsn_dec_data).length;

limit_of=len_of_arr-len_of_camp_arr;

str_ret="";


console.log(limit_of);

for (const [key, value] of Object.entries(jsn_dec_data)) {


if(i<limit_of-11){

  str_ret+="<tr><td class='fld-name'  id=''>"+key+"</td> <td trg-name='"+key+"' class='fld-val fld_js_trg' >"+value+"</td></tr>";

  i+=1;

}else{

break;

}

}



$("#tb_bd_of_email_pro").html(str_ret);




}





$(document).on('click','.edt_btn_of_dt',function(){


$('.fld_js_trg').map(function() {
   

ip_plc_hld=$(this).html();

$(this).empty();

$(this).html('<input class="ip-by-def-dsg"  type="text" style="padding-left:10px;height:40px;width:100%;" value="'+ip_plc_hld+'">');




});


$(this).html('save');
$(this).removeClass('edt_btn_of_dt');
$(this).addClass('edt_save_btn');


})

jsn_data_save={};


$(document).on('click','.edt_save_btn',function(){



$('.fld_js_trg').map(function() {
   
app_key=$(this).attr('trg-name');
app_val=$(this).children('.ip-by-def-dsg').val();

jsn_data_save[app_key]=app_val;

});

up_db_of_profile();




})


function up_db_of_profile(){


console.log(jsn_data_save);



$.ajax({
            url: './ajaxfile/update_pro_data.php',
            type: 'post',
            data: {data:JSON.stringify(jsn_data_save)}
        }).done(function(response){ 

console.log(response);


if(response==1){


init_data_of_pro();



$(".edt_save_btn").html("<img src='https://res.cloudinary.com/heptera/image/upload/v1606540655/addcontact/up-svg_y9jyxg.svg'>");
$(".edt_save_btn").addClass('edt_btn_of_dt');
$(".edt_save_btn").removeClass('edt_save_btn');


}else{



}

});


}


</script>




</html>











