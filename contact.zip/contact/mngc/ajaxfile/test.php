<?php



function get_src_str($geted_arr){
	

	$str_ret="";

for($i=0;$i<$geted_arr.length();$i++){
	
$str_ret+="'%".$geted_arr[i]."%'";


if($i==$geted_arr.length()){
	


}else{
	

$str_ret+=" or ";

}







}

return $str_ret;



}



session_start();


require("../../confige/fileconfige.php");

require("../../confige/managetag.php");

require("./../ajaxfile/get_tag_data.php");



$listname_api=$_SESSION['listname'];

$json_filt_data=$_POST['filt_tag'];

require("./../../ajaxfile/phpfile/get_tbl_col.php");



?>
