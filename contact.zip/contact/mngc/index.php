



<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];

require("../confige/fileconfige.php");
require("../confige/managetag.php");
require("../confige/camp_confige.php");









$lst_name=$_SESSION['listname'];
$get_camp_data="select * from camp_contact_tbl where list_id='$lst_name'";





$result = $camp_name_conn->query($get_camp_data);



$cnt_camp=$result->num_rows;


$array_of_tag = array();

$tag_tbl_name="tag".$id;
$select_tag = "select * from ".$tag_tbl_name;
$result = $mngtag->query($select_tag);


while($row = $result->fetch_assoc()) {
        $temp_array["label"]=$row["tag"];
        $temp_array["value"]=$row["id"];

        array_push($array_of_tag,$temp_array);
    }


$geted_tag_array=json_encode($array_of_tag);






function get_email_col($list_id){
require("../confige/fileconfige.php");


	$get_col_query="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='storefile' AND `TABLE_NAME`='".$list_id."'";

	$query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){


	$result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}








$get_col=get_email_col($_SESSION['listname']);

$get_col=array_slice($get_col,0,count($get_col)-$cnt_camp-8);

?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">





<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">

 <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />


 <link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">
<style>
.not-fd-data{
  text-align: center;
padding: 40px;
    background: white;
    border-radius: 4px;

}




.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}




.cbx {
  margin: auto;
  -webkit-user-select: none;
  user-select: none;
  cursor: pointer;
}
.cbx span {
  display: inline-block;
  vertical-align: middle;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child {
  position: relative;
  width: 18px;
  height: 18px;
  border-radius: 3px;
  transform: scale(1);
  vertical-align: middle;
  border: 1px solid #9098A9;
  transition: all 0.2s ease;
}
.cbx span:first-child svg {
  position: absolute;
  top: 3px;
  left: 2px;
  fill: none;
  stroke: #FFFFFF;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 16px;
  stroke-dashoffset: 16px;
  transition: all 0.3s ease;
  transition-delay: 0.1s;
  transform: translate3d(0, 0, 0);
}
.cbx span:first-child:before {
  content: "";
  width: 100%;
  height: 100%;
  background: #506EEC;
  display: block;
  transform: scale(0);
  opacity: 1;
  border-radius: 50%;
}
.cbx span:last-child {
  padding-left: 8px;
}
.cbx:hover span:first-child {
  border-color: #506EEC;
}

.inp-cbx:checked + .cbx span:first-child {
  background: #506EEC;
  border-color: #506EEC;
  animation: wave 0.4s ease;
}
.inp-cbx:checked + .cbx span:first-child svg {
  stroke-dashoffset: 0;
}
.inp-cbx:checked + .cbx span:first-child:before {
  transform: scale(3.5);
  opacity: 0;
  transition: all 0.6s ease;
}

@keyframes wave {
  50% {
    transform: scale(0.9);
  }
}



















@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(https://fonts.googleapis.com/css?family=Dosis);
.tablediv{
    padding:10%;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
.upper-dir{



}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


















.select-wrapper {
        margin: auto;
        max-width: 600px;
        width: calc(100% - 40px);
      }

      .select-pure__select {
        align-items: center;
        background: white;
margin:10px;      
  border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: none;
        box-sizing: border-box;
        color: #363b3e;
        cursor: pointer;
        display: flex;
        font-size: 16px;
        font-weight: 500;
        justify-content: left;
        min-height: 44px;
        padding: 5px 10px;
        position: absolute;
        transition: 0.2s;
        width: 300px;
      }

      .select-pure__options {
        border-radius: 4px;
        border: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: #363b3e;
        display: none;
        left: 0;
        max-height: 220px;
        overflow-y: scroll;
        position: absolute;
        top: 50px;
        width: 100%;
        z-index: 5;
      }

      .select-pure__select--opened .select-pure__options {
        display: block;
      }

      .select-pure__option {
        background: #fff;
        border-bottom: 1px solid #e4e4e4;
        box-sizing: border-box;
        height: 44px;
        line-height: 25px;
        padding: 10px;
      }

      .select-pure__option--selected {
        color: #e4e4e4;
        cursor: initial;
        pointer-events: none;
      }

      .select-pure__option--hidden {
        display: none;
      }

      .select-pure__selected-label {

  align-items: 'center';
       
  border-radius: 4px;
font-size:13px;
        color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
        cursor: initial;
        display: inline-flex;
        justify-content: 'center';
        margin: 5px 10px 5px 0;
        padding: 3px 7px;
      }

      .select-pure__selected-label:last-of-type {
        margin-right: 0;
      }

      .select-pure__selected-label i {
        cursor: pointer;
        display: inline-block;
        margin-left: 7px;
      }

      .select-pure__selected-label img {
        cursor: pointer;
        display: inline-block;
        height: 18px;
        margin-left: 7px;
        width: 14px;
      }

      .select-pure__selected-label i:hover {
        color: black;
      }

      .select-pure__autocomplete {
        background: #f9f9f8;
        border-bottom: 1px solid #e4e4e4;
        border-left: none;
        border-right: none;
        border-top: none;
        box-sizing: border-box;
        font-size: 16px;
        outline: none;
        padding: 10px;
        width: 100%;
      }

      .select-pure__placeholder--hidden {
        display: none;
      }
























.con-of-data {
 max-width:80%;
  max-height: 20em;
  overflow: scroll;
  position: relative;
}

table {
    
  position: relative;
  border-collapse: collapse;
}
tr{
    outline: 1px solid rgb(222, 221, 220);
}
td,
th {
  padding: 0.25em;
}

thead th {
    
    
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  top: 0;
background: #ededf5ed;
    color: #090942;
 

 z-index: 1000;
}

thead th:first-child {
outline: 1px solid rgb(222, 221, 220); 
  left: 0;
  z-index: 1000000000;
}

tbody th {
  position: -webkit-sticky; /* for Safari */
  position: sticky;
  left: 0;
  background: #FFF;
  
}
tbody tr th{
  outline:  1px solid rgb(222, 221, 220); 
    z-index: 1000;
    background: white;
}
.con-data{
min-width: 150px;
max-width: 200px;
overflow: scroll;
padding: 12px 24px;
height:49px;
}
th .email-con{


color:black;


}
.email-con{
overflow-x:scroll;
    width:200px;
 padding-left: 20px;
    margin-right: 20px;   
  
}
.email-con::-webkit-scrollbar {
  display: none;
}
.con-of-data{
margin:0px auto;

margin-bottom:60px;
  color: #090942; 
    outline: 1px solid rgb(222, 221, 220); 

font-size:15px;
}

th.email-con:hover {
    cursor: pointer;
}


.con-data::-webkit-scrollbar {
  display: none;
}



.row.con_of_opt {



transition: all 0.5s ease 0s;

    background: #5a297708;
    margin: 60px auto 0px auto;
    max-width: 80%;
    max-height: 20em;
    position: relative;
    font-weight: 900;
    color: #5a2977;
}
.bottom-btn {
    text-align: center;
    height: 40px;
    background: #5a297747;
    color: #5a2977;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    padding-left: 20px;
    padding-right: 20px;
}

.main_con_opt{
padding:20px;
}






.dropdown-menu{
    border-radius:0px;
    box-shadow:none;
    
    border:1px solid #dedddc;
overflow-y:scroll;   
}
.below-tit{
font-weight: 400;
    font-size: 18px;
    padding-top: 20px;
    color: #000000c7;
    font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    letter-spacing: 1px;
}
.color-fet{
padding-left:10px;
padding-right:10px;
font-weight:600;
}




</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->

</head>
<div id="c"></div>
<body class="" style="background:#fff">



<?php require("../confige/header/header.php");?>

<?php require("../ajaxfile/phpfile/top_of_mngc_2.php");?>




<div id='main-loader-containre'>

<div class="container" style="padding-top:120px;border-bottom:1px solid #e0dbdb;width:100%;">

<div class="cont-head-con" style="padding:30px;">
<div style="width:100%">
<span style="font-weight:1000;letter-spacing:2px;font-size:30px;color:black"><span style='color:#5a2977bd;'><?php

$filename=explode("^",$_SESSION['listname']);
         $name_of_file=base64_decode($filename[1]);
echo $name_of_file;
         ?></span></span>
</div>
<?php
$filename_of_enco=$_SESSION['listname'];
$selectsite="SELECT * FROM filedetails WHERE filename='$filename_of_enco'";
$selectedurl = $conn2->query($selectsite);
$row_select=$selectedurl->fetch_assoc()
?>
<div class='below-tit'>
<span>Audiance in</span><span class='color-fet' style='color:#5a2977bd;'><?php echo $name_of_file;?></span><span>is</span><span class='color-fet' style='color:#5a2977bd;'><?php echo $row_select['extra'];?> </span><span>contacts</span>
</div>


</div>

</div>


<div class='row con_of_opt' style=''>
    

<div id='not_select_val_con' style='display:inline-flex'>
<div class="dropdown1" id="dropdown3">
  <div class='main_con_opt'> Filter By Tag</div>
  <div class="dropdown1-content" id="dropdown3-content" style='height:auto;'>

<div id="tag_con_main" style='max-height:250px;overflow:scroll;'>
 

</div>

<div class="row tag_link_con" style="">
        
        <div class="link_hr" style="text-align: r;text-align: right;width:100%;padding:20px 0px 0px 0px;"><button type="button" class="btn btn-link" id="filt_img_nw">Filter<i class="fas fa-check" aria-hidden="true"></i></button></div>
    
    </div>

      </div>

  </div>
    

<div class="dropdown1" id="dropdown4">
  <div class='main_con_opt'>View Segment</div>
  <div class="dropdown1-content" id="dropdown4-content" style='min-width:300px;height:auto;'>



<div  style="">

<?php
require("../confige/segment_confige.php");

$sel_query="select * from segment_data where list_name='".$lst_name."'";

$result_seg = $seg_conn->query($sel_query);
$seg_cnt_camp=$result_seg->num_rows;
if($seg_cnt_camp==0){

?>
 

 <div class="seg_not_fnd" style="
">
    
    <div style="text-align: center;padding: 50px;"><img src="https://res.cloudinary.com/heptera/image/upload/v1590818871/segmentation_favn2x.png" height="80" style="
    "></div>
    
    </div>
<div class="crt_seg_btn" style="text-align:center;padding:20px;">

<button class="bottom-btn btn-link" onclick="window.location.href='../segment/'" style="color:#5a2977;"><i class="fas fa-plus" style="padding-right:10px;" aria-hidden="true"></i>Creat Segment</button>

</div>
    



<?php
}else{


	while($row = $result_seg->fetch_assoc()) {
		$seg_dec_name=$row['id'];
		$seg_en_name=explode("^",$seg_dec_name)[1];

?>





	<div class="get_seg_data" style="" id="<?php echo  $seg_dec_name;?>"><button type="button" class="btn btn-link" ><?php echo  $seg_en_name;?></button></div>
<?php

}
}
?>

        </div>
      </div>

  </div>
    <div onclick="window.location.href='../segment/'" class="main_con_opt">
         create Sagment
    </div>
</div>
<div id='select_val_con' style='display:none'>
<div class="dropdown1" id="dropdown1">
  <div class='main_con_opt'> Change Tag</div>
  <div class="dropdown1-content" id="dropdown1-content">


<span class="autocomplete-select"></span>
<div class="tag_ext_con" id='main_tag_con'>
    
    



</div>
<div class="row tag_link_con" style="">
        <div class="link_hr" style="
    float: left;
"><button type="button" class="btn btn-link">Manage Tag <i class="fas fa-arrow-right"></i></button></div>
        <div class="link_hr" style="text-align: r;text-align: right;"><button type="button" class="btn btn-link" id='save_tag_dt'>Save Tag <i class="fas fa-check"></i></button></div>
    
    </div>   
      </div>

  </div>

<div class="dropdown1" id="dropdown2">
  <div class='main_con_opt'>Manage Tag</div>
  <div class="dropdown1-content" id="dropdown2-content" style='min-width:200px;height:auto;'>




<div class="chg_stat_opt" style="">
        
        <div class="link_hr_for_stat" style=""><button type="button" class="btn btn-link save_stat_dt" id="sub_sata^2">Unsubscribe <i class="fas fa-arrow-right"></i></button></div>
<div class="link_hr_for_stat" style=""><button type="button" class="btn btn-link save_stat_dt"  id="sub_sata^4">Bounced<i class="fas fa-arrow-right"></i></button></div>
        <div class="link_hr_for_stat" style=""><button type="button" class="btn btn-link save_stat_dt"  id="sub_sata^1">Subscribe <i class="fas fa-arrow-right"></i></button></div>
       <div class="link_hr_for_stat" style=""><button type="button" class="btn btn-link save_stat_dt"  id="sub_sata^3">None-Subscribe<i class="fas fa-arrow-right"></i></button></div>
<div class="link_hr_for_stat" style=""><button type="button" class="btn btn-link save_stat_dt" id="sub_sata^5">VIP<img src="https://res.cloudinary.com/heptera/image/upload/v1589619572/sign_kxvmzy.png" height='20' style='margin-left:10px;'></button></div>
    </div>
      </div>

  </div>

<div class="main_con_opt" id="arch_con">MaKe It Archive</div>

</div>


<div id="seg_head_tbl" style="display:none;width:100%;background:black;color:white">


<div class="main_con_opt back_btn_seg" style="color:white"> <i class="fas fa-chevron-left"></i> Back</div>

<div class="main_con_opt" id="seg_name_def" style="color:white"> </div>


<div class="main_con_opt del_seg_btn" style="color:white;background:#00000061">DELET SEGMENT</div>





</div>



<div class="container not-fd-data" style="display:none;">

<img src="https://image.flaticon.com/icons/png/512/2879/2879478.png" height="64" style="
">
<div class="txt-not-fd">
You hnot Imported Any Contact.for Start Import contact Click Button.
  </div>

<button class="bottom-btn" data-toggle="modal" onclick="window.location.href='../contact/'" style="float:none;"><i class="fas fa-file-import" style="
    padding-right: 10px;
" aria-hidden="true"></i>Import Now</button>
</div>



</div>

<div class='con-of-data '>
  <table class='table-data-con'>
    <thead>

      <tr>


<th style='z-index:1000000;background: #5a2977;' > <div class='email-con' style='color:white;'>email</div> </th>

<?php

for($i=1;$i<count($get_col);$i++){


?>
        
        <th><div class='con-data'><?php echo $get_col[$i];?></div></th>
       	
       
<?php

}
?>
      </tr>

    </thead>
    <tbody>
      
    </tbody>
  </table>
</div>


</div>
<style>









.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid #fff;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #fff transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}


.tag_ext_con {
    height: 220px;
    margin-top: 58px;
padding:10px;
}

















.tag_filt_con{
margin:3px;
}
.tag_con_act{


color: #5a2977;
    background: rgba(90, 41, 119, 0.11);
}






.dropdown1 {
  position: relative;
  display: inline-block;
}

.dropdown1-content {
display:none;
height:350px;
  position: absolute;
  background-color: white;

border-radius: 0px 0px 10px 10px;
  min-width: 352px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 10000000;


}


.main_con_opt:hover{
cursor:pointer;
}


.row.tag_link_con {
    margin: 0px;
  height:50px;
}
.link_hr {
    width: 50%;
    font-size: 17px;
    padding:10px 0px;
    color: #5a2977;
}

.dropdown1:hover .dropdown1-content{
 
}
.btn-link:hover{
color:#5a2977;
background:rgba(90, 41, 119, 0.11);

}

.btn-link{
padding:5px;
border-radius:5px;
background: transparent;
    font-weight: 600;
    box-shadow: none;
transition:0.1s; 
   border: none;
}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.con_txt_for_mdl{

color:black;
padding-bottom:10px;


}
</style>









<div class="modal fade" id="confirm_arch_all" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Confirm archived</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

<div class="con_txt_for_mdl">
Enter <b>ARCHIVE</b> for archived all contact.


</div>
      <input class="modal-input" type="text" style="height: 40px;
    width: 100%;padding:10px;
    border: 1px solid rgba(36,28,21,0.3);" id="arch_inp_con">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="bottom-btn" style="background:none;" data-dismiss="modal">Close</button>
        <button type="button" class="bottom-btn" id="con_arch_btn"><div class="row">Confirm</div></button>
      </div>
    </div>
  </div>
</div>


































<div id='res4'></div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
 <script src="../select_opt/jsfile/bundel.min.js"></script>
<script>
  //      $(document).ready(function(){
    //     jQuery.get('ravi.html', function(data) {
//		$("#tbl-con").append(data);
//	 });
//jQuery.get('ravi1.html', function(data) {
  //              $(".sticky-wrap").append(data);
    //     });
	//	
//
//
//


crt_data_ver=[];
get_email_api="<?php echo $filename_of_enco;?>";

seg_ope_flg=0;




length_of_array=0;




function append_load(get_date){

$("#"+get_date).children(".row").append("<div class='lds-ring'  style=''><div></div><div></div><div></div><div></div></div>");

    }














$(document).on("click","#con_arch_btn",function(){

arr_of_data=[];

if($("#arch_inp_con").val()=="ARCHIVE"){

append_load("con_arch_btn");


for (var i = 0; i < length_of_array; i++) {
  arr_of_data.push(i);
};

console.log(length_of_array);
data_of_chg=get_arch_array(1);
$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_of_chg+"&get_stat_act="+"arch"
        }).done(function(response){ 

init_tbl_data();    


        });


}

});
























function init_tbl_data(){
$("#not_select_val_con").children(".back_btn_seg").remove();
$("#unarch_con").html("Make It Archive");

	$("#unarch_con").attr("id","arch_con");
$(".dropdown1-content").css("display","none");

	$(".table-data-con").children("tbody").empty();
arr_of_data=[];
	init_head_of_tbl();
	jQuery.get('rahul1.php?apicode_main='+get_email_api, function(data2) {

console.log(data2);

            get_tbl_enbl(data2);
	});

}






$(document).on('click',".save_stat_dt",function(){

change_stat_data={};	
        
stat_data=$(this).attr("id").split("^")[1];

for(j=0;j<arr_of_data.length;j++){


email_of_chg=crt_data_ver[arr_of_data[j]]["email"];
	
 change_stat_data[email_of_chg]= stat_data;
}


data_of_chg=JSON.stringify(change_stat_data);

console.log(data_of_chg);

$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_of_chg+"&get_stat_act="+"substatus"
        }).done(function(response){ 

init_tbl_data();		


        });








});

















id_data='<?php echo $lst_name;?>';

$(document).on("click",".get_seg_data",function(){



var get_id=$(this).attr("id");


$(".table-data-con").children("tbody").empty();
arr_of_data=[];
	init_head_of_tbl();



jQuery.get('./rahul1.php?apicode_main=seg_data&post_query_link='+get_id, function(data2) {
             get_tbl_enbl(data2);
$("#seg_name_def").html(get_id.split("^")[1]); 
 $("#seg_head_tbl").css("display","inline-flex");
$(".del_seg_btn").attr("id",get_id);	     
	     $("#not_select_val_con").css("display","none");
	      $("#select_val_con").css("display","none");
	     seg_ope_flg=1;
 })


})




	$(document).on("click",".back_btn_seg",function(){
		
		
		
		
		$("#seg_head_tbl").css("display","none");


$("#unarch_con").html("Make It Archive");

	$("#unarch_con").attr("id","arch_con");
seg_ope_flg=0;
init_tbl_data()


});



function get_seg_dt_str(get_seg_old,rem_seg){

return get_seg_old.replace(rem_seg+",","");


}


$(document).on("click",".del_seg_btn",function(){

console.log(length_of_array);
change_stat_data={};
val_of_tag=$(this).attr("id");

for(j=0;j<length_of_array;j++){


email_of_chg=crt_data_ver[j]["email"];
  geted_old_str=get_seg_dt_str(crt_data_ver[j]["segment"],val_of_tag);

final_tag_str=geted_old_str;
 change_stat_data[email_of_chg]= final_tag_str;

}

data_of_chg=JSON.stringify(change_stat_data);

console.log(data_of_chg);
json_req_for_tag(data_of_chg,val_of_tag);



setTimeout(function(){ location.reload(); }, 1000);



});



























function json_req_for_tag(data_json,seg_name){

	if(seg_name=="tag98"){
		status_of_act="tag";
		seg_name_dt="none";
	}else{

		status_of_act="segment";
		seg_name_dt=seg_name;
	}

$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_json+"&get_stat_act="+status_of_act+"&seg_name="+seg_name_dt
        }).done(function(response){ 

init_tbl_data();                
console.log(response);

        });





}







arr_of_all_tag=[];


$(document).on("click",".tag_filt_con",function(){

$(this).addClass("tag_con_act");

var get_val_data=$(this).attr("id").split("^")[1];

val_of_con=$(this).attr("tag_filt_flg");

if(val_of_con=="true"){


$(this).addClass("tag_con_act");
$(this).removeClass("link_hr_for_stat");


arr_of_all_tag.push(get_val_data);

$(this).attr("tag_filt_flg","false");
$("#tag_filt-"+get_val_data).attr("src","https://image.flaticon.com/icons/svg/860/860821.svg");


}else if(val_of_con=="false"){


$(this).addClass("link_hr_for_stat");
$(this).removeClass("tag_con_act");




arr_of_all_tag.splice( arr_of_all_tag.indexOf(get_val_data), 1 );

$(this).attr("tag_filt_flg","true");

$("#tag_filt-"+get_val_data).attr("src","https://image.flaticon.com/icons/svg/748/748113.svg");

}

console.log(arr_of_all_tag);

});



function unsub_function_data(){
sel_query_unsub_add="select * from `"+get_email_api+"` where substatus='2' and arch='0'";

jQuery.get("rahul1.php?apicode_main=query&post_query_link="+sel_query_unsub_add, function(data2) {

console.log(data2);

            get_tbl_enbl(data2);
  });




}





function get_arch_array(get_stat_data){
change_stat_data={};
for (var i = 0; i < arr_of_data.length; i++) {
  email_of_chg=crt_data_ver[arr_of_data[i]]["email"];
change_stat_data[email_of_chg]= get_stat_data;

};

data_of_chg=JSON.stringify(change_stat_data);

return data_of_chg;

}

$(document).on("click","#arch_con",function(){


data_of_chg=get_arch_array(1);

$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_of_chg+"&get_stat_act="+"arch"
        }).done(function(response){ 

init_tbl_data();    


        });




});






function arch_show_fun(){
$("#not_select_val_con").prepend("<div class='main_con_opt back_btn_seg' style='color:rgb(90, 41, 119)'> <i class='fas fa-chevron-left'></i> Back</div>");
	
	$("#arch_con").html("Unarchive");

	$("#arch_con").attr("id","unarch_con");


sel_query_unsub_add="select * from `"+get_email_api+"` where  arch='1'";

jQuery.get("rahul1.php?apicode_main=query&post_query_link="+sel_query_unsub_add, function(data2) {

console.log(data2);

            get_tbl_enbl(data2);
  });



}







$(document).on("click","#unarch_con",function(){


data_of_chg=get_arch_array(0);
console.log(data_of_chg);
$.ajax({
                url : "./ajaxfile/update_tag.php",
                type: "POST",
                data : "requestoflist="+data_of_chg+"&get_stat_act="+"arch"
        }).done(function(response){ 

sel_query_unsub_add="select * from `"+get_email_api+"` where  arch='1'";

jQuery.get("rahul1.php?apicode_main=query&post_query_link="+sel_query_unsub_add, function(data2) {




	location.reload();

});

 


        });




});

















flg_for_filt=0;

dp_dw_stat="";

tag_get=[];

function append_filt_tag_dt () {
	
	
	str_main="";
	for(i=0;i<json.length;i++){
	lable=json[i]["label"];

str_main+="<div class='link_hr_for_stat tag_filt_con' tag_filt_flg='true' style='' id='tag_get_filt^"+json[i]["value"]+"'><button type='button' class='btn btn-link'  style='width: 100%;text-align: left;'>"+lable+"<img src='https://image.flaticon.com/icons/svg/748/748113.svg' height='20' class='del_tag_dt' id='tag_filt-"+json[i]["value"]+"' style='float: right;'></button></div>";

}

$("#tag_con_main").append(str_main);

}














$(document).on("click","#filt_img_nw",function(){


data_of_chg=JSON.stringify(arr_of_all_tag);

$.ajax({
                url : "./ajaxfile/filter_tag.php",
                type: "POST",
                data : "filt_tag="+data_of_chg
        }).done(function(response){ 


if(arr_of_all_tag.length>0){
$(".table-data-con").children("tbody").empty();
arr_of_data=[];
	init_head_of_tbl();



get_tbl_enbl(response);
}else{


$(".table-data-con").children("tbody").empty();
arr_of_data=[];
	init_head_of_tbl();



init_tbl_data();

}

        });





});




















$(document).on("click",".dropdown1",function(){




dp_dw_stat=$(this).attr("id")+"-content";
console.log(dp_dw_stat);
if($("#"+dp_dw_stat).css("display")=="none"){
get_str_of_ext_tag();


}

if(dp_dw_stat=="dropdown3-content"){

if($("#"+dp_dw_stat).css("display")=="none" && flg_for_filt==0){

	append_filt_tag_dt();
	flg_for_filt=1;
}

}

$("#"+dp_dw_stat).css("display","block");

});





$(document).mouseup(function(e)
{
    var container = $("#"+dp_dw_stat);

    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0)
    {
        container.hide();
    }
});




ary=[];


function find_lable_from_val(val_of_tag,src_of_dt,tag_geted){

str_of_tag="";
for (i=0;i<val_of_tag.length;i++) {
	

var get_tag_val=ary[0][val_of_tag[i]];


if(src_of_dt=="add_tag"){

if(tag_get.indexOf(get_tag_val)==-1){

str_of_tag+=get_tag_val+",";

}
}else if(src_of_dt=="rem_tag"){


if(tag_geted !== get_tag_val){

str_of_tag+=get_tag_val+",";

console.log(tag_geted);

}




}





}
console.log(str_of_tag);



return str_of_tag;

}

function get_update_str_of_tag(){
str_of_tag="";

for (var i = 0; i < tag_get.length; i++) {
	str_of_tag+=tag_get[i]+",";
};
console.log(str_of_tag);

return str_of_tag;

}






$(document).on("click",".del_tag_dt",function(){


var removed_ele=$(this).attr("id").split("^")[1];
console.log(removed_ele);

val_of_tag=ary[0][removed_ele];

change_stat_data={};

for(j=0;j<arr_of_data.length;j++){


email_of_chg=crt_data_ver[arr_of_data[j]]["email"];
	geted_old_str=find_lable_from_val(crt_data_ver[arr_of_data[j]]["tag"],"rem_tag",val_of_tag);
console.log(geted_old_str.length);
if(geted_old_str.length==0){
        
geted_old_str=val_of_tag;
}
console.log(geted_old_str);

final_tag_str=geted_old_str;
 change_stat_data[email_of_chg]= final_tag_str;
}

data_of_chg=JSON.stringify(change_stat_data);

console.log(data_of_chg);

json_req_for_tag(data_of_chg,"tag98");
   
tag_get=[];

});














function remove_tag_str_dt(id_of_lst){

var tag_of_lst=crt_data_ver[id_of_lst]["tag"];
var new_tag_dt=[];
for (var i = 0; i < tag_of_lst.length; i++) {
	if(tag_get.indexOf(tag_of_lst[i])==-1){

new_tag_dt.push(tag_of_lst[i]);
	}
}


for (var i = 0; i < arr_of_data.length; i++) {
	var loc_dt_tag=crt_data_ver[arr_of_data[i]]["tag"];
for (var i = 0; i < new_tag_dt.length; i++) {
	
if(loc_dt_tag.indexOf(new_tag_dt[i])==-1){


new_tag_dt.splice( new_tag_dt.indexOf(new_tag_dt[i]), 1 );

break;


}

}







}
tag_get+=new_tag_dt;




}





$(document).on('click',"#save_tag_dt",function(){

change_stat_data={};	
        
for(j=0;j<arr_of_data.length;j++){


console.log("ravi");

email_of_chg=crt_data_ver[arr_of_data[j]]["email"];
if(crt_data_ver[arr_of_data[j]]["tag"].length>0){
	

	geted_old_str=find_lable_from_val(crt_data_ver[arr_of_data[j]]["tag"],"add_tag","0");
	
	
}else{
	geted_old_str="";
}
geted_new_str=get_update_str_of_tag();


final_tag_str=geted_old_str+geted_new_str;
 change_stat_data[email_of_chg]= final_tag_str;
}


data_of_chg=JSON.stringify(change_stat_data);
console.log(data_of_chg);


json_req_for_tag(data_of_chg,"tag98");






});




var data = '<?php echo $geted_tag_array; ?>';







json = JSON.parse(data);     



dict_of_tag={};
for(i=0;i<json.length;i++){
	lable=json[i]["label"];
val=json[i]["value"];	
dict_of_tag[lable]=val;

if(i==json.length-1){
ary.push(dict_of_tag);
}
}









console.log(json);
var autocomplete = new SelectPure(".autocomplete-select", {
        options: json,
        value: [],
        multiple: true,
        autocomplete: true,
        icon: "fa fa-times",
        onChange: value => { tag_get=value; },
        classNames: {
          select: "select-pure__select",
          dropdownShown: "select-pure__select--opened",
          multiselect: "select-pure__select--multiple",
          label: "select-pure__label",
          placeholder: "select-pure__placeholder",
          dropdown: "select-pure__options",
          option: "select-pure__option",
          autocompleteInput: "select-pure__autocomplete",
          selectedLabel: "select-pure__selected-label",
          selectedOption: "select-pure__option--selected",
          placeholderHidden: "select-pure__placeholder--hidden",
          optionHidden: "select-pure__option--hidden",
        }
      });


function append_tag(item, index){
	let op = json.filter(e=> e.value == item);
	
$("#tag_ver_con").append("<span class='select-pure__selected-label'>"+op[0]['label']+"</span>");


}




























deco_data=[];












arr_of_data=[];



function init_head_of_tbl(){





if(seg_ope_flg==0){

if(arr_of_data.length>0){
	
	$("#not_select_val_con").css("display","none");



	$("#select_val_con").css("display","inline-flex");
$(".con_of_opt").css("background","#5a2977");
$(".con_of_opt").css("color","#ffffff");


}else{
	
 $("#select_val_con").css("display","none");



        $("#not_select_val_con").css("display","inline-flex");
$(".con_of_opt").css("background","#5a297708");
$(".con_of_opt").css("color","#5a2977");


}

}



}








function get_tag_match(id_of_lst){

var loc_array_tag=[];
var tag_of_lst=crt_data_ver[id_of_lst]["tag"];
console.log(tag_of_lst);
if(tag_of_lst.length>0){
if(arr_of_data.length>0){
for(var i=0;i<tag_of_lst.length;i++){
if(tag_get.indexOf(tag_of_lst[i])>=0){

	loc_array_tag.push(tag_of_lst[i]);


}

}

}else{


loc_array_tag=tag_of_lst;

}
}
tag_get=loc_array_tag;
console.log(tag_get);



}











function get_str_of_ext_tag(){
	
	$("#main_tag_con").empty();
	console.log(tag_get);
var str_main="";
for (var i = 0;i < tag_get.length; i++) {
	str_main+="<div class='link_hr_for_stat' style=''><button type='button' class='btn btn-link'  style='width: 100%;text-align: left;'>"+tag_get[i]+"<img src='https://image.flaticon.com/icons/svg/1214/1214428.svg' height='20' class='del_tag_dt' id='tag_dt^"+tag_get[i]+"' style='float: right;'></button></div>";
}
console.log(str_main);
$("#main_tag_con").append(str_main);

}




$(document).on("click",".select_mail_lst",function(){


	val_of_mail=$(this).attr("id").split("^");
	
	
	get_tag_match(val_of_mail[1]);


	var val_of_id="#email_stat"+val_of_mail[1];
val_of_con=$(val_of_id).val();
if(val_of_con=="true"){
	
arr_of_data.push(val_of_mail[1]);

$(val_of_id).val("false");



}else if(val_of_con=="false"){
	
arr_of_data.splice( arr_of_data.indexOf(val_of_mail[1]), 1 );

$(val_of_id).val("true");



}

console.log(arr_of_data);

init_head_of_tbl();





});


























$(document).ready(function(){












id_now_path= window.location.href.split('#');
    console.log(id_now_path.length);
    for(i=0;i<id_now_path.length-1;i++){
           

    }

    if(id_now_path[i-1]=="unsub_add"){

                unsub_function_data();




      }else if(id_now_path[i-1]=="arch_show"){


arch_show_fun();

		 }else if(id_now_path[i-1]=="arch_all"){
		 
		 
		 $('#confirm_arch_all').modal();
		 init_tbl_data();
		 }else{


init_tbl_data();

                 }
});






function sub_stat_enco(sub_flg){

if(sub_flg==1){
                return "subscribe";
        }else if(sub_flg==2){
                return "un-subscribe";
        }else if(sub_flg==3){

                return "none-subscribe";
        }else if(sub_flg==4){
                return "bounced";

	}else if(sub_flg==5){
		return "VIP";
	}



}


function get_tag_html(geted_data){


get_res_tag="";
	
for(k=0;k<geted_data.length;k++){
get_res_tag+="<span class='badge badge-primary' style='margin:3px;'>"+geted_data[k]+"</span>";

}

return get_res_tag;

}






function get_tbl_enbl(geted_data){


$(".table-data-con").children("tbody").empty();



str_tbl_enbl="";
        crt_data_ver=JSON.parse(geted_data);
        length_of_array=crt_data_ver.length;

if(length_of_array>0){
var js_array = [<?php echo '"'.implode('","', $get_col).'"' ?>];

console.log(js_array);

console.log(crt_data_ver);


        for(i=0;i<length_of_array;i++){
        str_tbl_enbl+="<tr><th class='email-con' ><div class='row' style='width:280px;'><div><input class='inp-cbx' id='email_stat"+i.toString()+"'   value='true' type='checkbox' style='display: none' /><label class='cbx' for='email_stat"+i.toString()+"'><span class='select_mail_lst' id='"+crt_data_ver[i]["email"]+"^"+i.toString()+"'><svg width='12px' height='10px' viewbox='0 0 12 10'><polyline points='1.5 6 4.5 9 10.5 1'></polyline></svg></span><span> </span></label></div><div class='email-con com-for-lnk'   data-for-serv='0'  data-target-link='http://contact.sycista.com/contact/mngc/profile/confige/crt_ses_of_pro.php?pro_email_req="+crt_data_ver[i]["email"]+"&pro_id="+crt_data_ver[i]["con_id"]+"'>"+crt_data_ver[i]["email"]+"</div></div></th>"
		for (j=1;j<js_array.length-3;j++){

	console.log(crt_data_ver[i][js_array[j]]);
	
	
	
	str_tbl_enbl+="<td><div class='con-data'>"+crt_data_ver[i][js_array[j]]+"</div></td>";



}



console.log(crt_data_ver[i][js_array[j]]);


get_res_tag=get_tag_html(crt_data_ver[i][js_array[j]]);


str_tbl_enbl+="<td><div class='con-data' style='min-width:300px;'>"+get_res_tag+"</div></td>";
j+=1;

var get_sub_stat=sub_stat_enco(crt_data_ver[i][js_array[j]]);
str_tbl_enbl+="<td><div class='con-data sub_stat_con'><span class='badge badge-pill badge-success'>"+get_sub_stat+"</span></div></td>";
i
j+=1;
str_tbl_enbl+="<td><div class='con-data'>"+crt_data_ver[i][js_array[j]]+"</div></td>";






str_tbl_enbl+="</tr>";




dp_dw_stat="";

tag_get=[];
arr_of_data=[];


        }
$("#res4").html("klkl");
$(".not-fd-data").css("display","none");
$(".table-data-con").children("tbody").append(str_tbl_enbl);
$(".table-data-con").css("display","block");
}else{

$(".table-data-con").css("display","none");

$(".not-fd-data").css("display","block");
}

}





        </script>

<div id='res4'></div>

 <script src="./../../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="./../../assets/js/argon-dashboard1.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-throttle-debounce/1.1/jquery.ba-throttle-debounce.min.js"></script>
            
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>
  function getdata(path){
      $(".navlinksub").removeClass("active");
      ChangeUrl(path,"?path="+path);
      
      $("#loader").css("display","block");


$(".main-content").load(path+".php", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
      $("#loader").css("display","none");
    if(statusTxt == "error")
      $("#loader").css("display","none");
  });
      
      
      

  }
  function ChangeUrl(title, url) {
    if (typeof (history.pushState) != "undefined") {
        var obj = { Title: title, Url: url };
        history.pushState(obj, obj.Title, obj.Url);
    } else {
        alert("Browser does not support HTML5.");
    }
}
      </script>
  <script>


$(document).on("click",".opt_on_list",function(){
var type_opr=$(this).attr("id");
var define_opt1 = $(this).attr("class");
var define_opt=define_opt1.split(" ");
var final_opr=define_opt[1];  
  
      
      $("#loadsendlink").css("display","inline-block");

    $.ajax({
                url : "./../ajaxfile/crtseslist.php",
                type: "POST",
                data : "requestoflist="+type_opr
        }).done(function(response){ 
$("#res").html(response);
        if(response==1){

window.location = "./../"+final_opr+"/";


      }

        });
  
});



</script>
  
  
</body>

<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>


